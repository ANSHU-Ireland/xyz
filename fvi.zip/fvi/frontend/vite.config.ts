import { defineConfig, loadEnv } from "vite";

// Vite config tailored for a React + TypeScript dashboard.
// - Dev server proxies /api -> backend (default 127.0.0.1:8787)
// - Build outputs to frontend/dist (used by the bootstrap scripts)
// - No framework plugins required for plain React 18

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const backend = env.VITE_BACKEND_ORIGIN || "http://127.0.0.1:8787";

  return {
    server: {
      host: "127.0.0.1",
      port: 5173,
      strictPort: false,
      proxy: {
        // Forward API calls to FastAPI to avoid CORS in dev
        "/api": {
          target: backend,
          changeOrigin: true,
        },
      },
    },
    preview: {
      host: "127.0.0.1",
      port: 5173,
      strictPort: false,
    },
    build: {
      outDir: "dist",
      sourcemap: true,
      emptyOutDir: true,
      rollupOptions: {
        output: {
          manualChunks: undefined, // single bundle is fine for this dashboard
        },
      },
    },
    define: {
      // You can inject defaults here; client.ts already handles VITE_API_BASE
    },
    esbuild: {
      jsx: "automatic",
    },
  };
});

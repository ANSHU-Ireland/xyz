// frontend/src/api/client.ts
// Production-ready typed API client for the FVI backend.
// - Auto-discovers base URL (defaults to `${window.location.origin}/api`)
// - Supports VITE_API_BASE override
// - Timeouts, structured errors, and typed methods

export type ISO3 = string;

export type Filters = {
  regions?: ISO3[];
  year?: number | [number, number];
};

export type ScoresRequest = {
  scenario_id?: string | null;
  filters?: Filters;
  alpha?: Record<string, number> | null;
  submetric_weights?: Record<string, Record<string, number>> | null;
  normalization_overrides?: Record<string, any> | null;
};

export type SeriesPoint = { iso3: ISO3; year: number; value: number };

export type ScoreSeries = { score: string; series: SeriesPoint[] };

export type ScoresResponse = {
  scores: ScoreSeries[];
  fvi: SeriesPoint[];
  coverage: Record<string, number>;
  meta: { alpha: Record<string, number>; scores: string[] };
};

export type ExplainRequest = {
  scenario_id?: string | null;
  filters?: Filters;
  alpha?: Record<string, number> | null;
  submetric_weights?: Record<string, Record<string, number>> | null;
};

export type Contribution = { id: string; contribution: number };

export type ScoreBreakdown = {
  score: string;
  score_value: number;
  alpha: number;
  contributions: Contribution[];
};

export type ExplainResponse = {
  region: ISO3;
  year: number;
  fvi: number;
  scores: ScoreBreakdown[];
};

export type ClassifyRequest = {
  filters?: Filters;
  alpha?: Record<string, number> | null;
  submetric_weights?: Record<string, Record<string, number>> | null;
  normalization_overrides?: Record<string, any> | null;
};

export type ClassPoint = {
  iso3: ISO3;
  year: number;
  fvi: number;
  label: "sustainable" | "critical_transition" | "decommission" | "unknown";
  p_sustainable: number;
  p_critical_transition: number;
  p_decommission: number;
};

export type ClassifyResponse = {
  results: ClassPoint[];
  meta: Record<string, any>;
};

export type ScenarioMethod = {
  aggregation: "weighted_mean" | "geometric_mean" | "topsis" | string;
  normalization: "minmax" | "robust_minmax" | "zscore" | string;
};

export type ScenarioCreate = {
  persona?: string;
  filters?: Filters;
  alpha?: Record<string, number>;
  sub_weights?: Record<string, Record<string, number>>;
  method?: ScenarioMethod;
};

export type ScenarioPatch = {
  persona?: string;
  filters?: Filters;
  alpha?: Record<string, number>;
  sub_weights?: Record<string, Record<string, number>>;
  method?: ScenarioMethod;
};

export type ScenarioOut = {
  scenario_id: string;
  persona: string;
  filters: Filters;
  alpha: Record<string, number>;
  sub_weights: Record<string, Record<string, number>>;
  method: ScenarioMethod;
  created_at: number;
  updated_at: number;
  pending: Record<string, any>;
};

export type ProposalIn = {
  scope: "score" | "submetric";
  targets: { id: string; target_weight: number; rationale?: string }[];
};

export type ProposalOut = {
  change_id: string;
  scope: "score" | "submetric";
  preview: Record<string, any>;
};

export type CommitIn = { change_id: string };

export type ExportRequest = {
  filters?: Filters;
  alpha?: Record<string, number> | null;
  submetric_weights?: Record<string, Record<string, number>> | null;
  normalization_overrides?: Record<string, any> | null;
  format?: "csv" | "parquet";
  filename?: string | null;
};

export type ExportResponse = {
  filename: string;
  path: string;       // server-side absolute path
  size_bytes: number;
};

export type ChatRequest = {
  session_id: string;
  message: string;
  persona?: string | null;
  scenario_id?: string | null;
  filters?: Filters | null;
};

export type ChatResponse = {
  text: string;
  citations: any[];
  tool_calls: any[];
  tool_results: any[];
  state: any;
};

export class ApiError extends Error {
  status: number;
  detail?: any;
  constructor(message: string, status: number, detail?: any) {
    super(message);
    this.status = status;
    this.detail = detail;
  }
}

// ---- Low-level HTTP helper ----

const DEFAULT_TIMEOUT_MS = 30000;

function apiBase(): string {
  // Prefer VITE_API_BASE, else default to current origin + /api
  const env = (import.meta as any).env;
  const fromEnv = env && env.VITE_API_BASE ? env.VITE_API_BASE : undefined;
  const base = fromEnv || `${window.location.origin}/api`;
  return base.replace(/\/+$/, "");
}

async function request<T>(
  path: string,
  init?: RequestInit & { timeoutMs?: number }
): Promise<T> {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), init?.timeoutMs ?? DEFAULT_TIMEOUT_MS);

  try {
    const res = await fetch(`${apiBase()}${path}`, {
      method: init?.method || "GET",
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers || {}),
      },
      credentials: "same-origin",
      body: init?.body,
      signal: controller.signal,
    });

    const contentType = res.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");

    if (!res.ok) {
      const detail = isJson ? await res.json().catch(() => ({})) : await res.text().catch(() => "");
      throw new ApiError(`HTTP ${res.status} on ${path}`, res.status, detail);
    }

    if (isJson) {
      return (await res.json()) as T;
    }

    // For file downloads we might need to handle blobs elsewhere.
    // Here we assume JSON for all defined endpoints.
    // If needed, extend with blob handling.
    return (await res.json()) as T;
  } finally {
    clearTimeout(t);
  }
}

// ---- High-level API ----

export const api = {
  // Scores & Explain
  getScores: (req: ScoresRequest): Promise<ScoresResponse> =>
    request<ScoresResponse>("/scores", {
      method: "POST",
      body: JSON.stringify({
        scenario_id: req.scenario_id ?? null,
        filters: req.filters ?? {},
        alpha: req.alpha ?? null,
        submetric_weights: req.submetric_weights ?? null,
        normalization_overrides: req.normalization_overrides ?? null,
      }),
    }),

  explain: (req: ExplainRequest): Promise<ExplainResponse> =>
    request<ExplainResponse>("/scores/explain", {
      method: "POST",
      body: JSON.stringify({
        scenario_id: req.scenario_id ?? null,
        filters: req.filters ?? {},
        alpha: req.alpha ?? null,
        submetric_weights: req.submetric_weights ?? null,
      }),
    }),

  // Classification
  classify: (req: ClassifyRequest): Promise<ClassifyResponse> =>
    request<ClassifyResponse>("/classify", {
      method: "POST",
      body: JSON.stringify({
        filters: req.filters ?? {},
        alpha: req.alpha ?? null,
        submetric_weights: req.submetric_weights ?? null,
        normalization_overrides: req.normalization_overrides ?? null,
      }),
    }),

  // Scenario
  createScenario: (req: ScenarioCreate): Promise<ScenarioOut> =>
    request<ScenarioOut>("/scenario", {
      method: "POST",
      body: JSON.stringify({
        persona: req.persona ?? "regular_citizen",
        filters: req.filters ?? {},
        alpha: req.alpha ?? {},
        sub_weights: req.sub_weights ?? {},
        method: req.method ?? { aggregation: "weighted_mean", normalization: "minmax" },
      }),
    }),

  getScenario: (scenarioId: string): Promise<ScenarioOut> =>
    request<ScenarioOut>(`/scenario/${encodeURIComponent(scenarioId)}`),

  patchScenario: (scenarioId: string, req: ScenarioPatch): Promise<ScenarioOut> =>
    request<ScenarioOut>(`/scenario/${encodeURIComponent(scenarioId)}`, {
      method: "PATCH",
      body: JSON.stringify({
        persona: req.persona,
        filters: req.filters,
        alpha: req.alpha,
        sub_weights: req.sub_weights,
        method: req.method,
      }),
    }),

  proposeWeightUpdate: (scenarioId: string, req: ProposalIn): Promise<ProposalOut> =>
    request<ProposalOut>(`/scenario/${encodeURIComponent(scenarioId)}/propose_weight_update`, {
      method: "POST",
      body: JSON.stringify(req),
    }),

  commitWeightUpdate: (scenarioId: string, changeId: string): Promise<ScenarioOut> =>
    request<ScenarioOut>(`/scenario/${encodeURIComponent(scenarioId)}/commit_weight_update`, {
      method: "POST",
      body: JSON.stringify({ change_id: changeId }),
    }),

  // Chat (Gemini RAG)
  chat: (req: ChatRequest): Promise<ChatResponse> =>
    request<ChatResponse>("/chat", {
      method: "POST",
      body: JSON.stringify({
        session_id: req.session_id,
        message: req.message,
        persona: req.persona ?? null,
        scenario_id: req.scenario_id ?? null,
        filters: req.filters ?? null,
      }),
      timeoutMs: 60000,
    }),

  // Export
  exportScores: (req: ExportRequest): Promise<ExportResponse> =>
    request<ExportResponse>("/export/scores", {
      method: "POST",
      body: JSON.stringify({
        filters: req.filters ?? {},
        alpha: req.alpha ?? null,
        submetric_weights: req.submetric_weights ?? null,
        normalization_overrides: req.normalization_overrides ?? null,
        format: req.format ?? "csv",
        filename: req.filename ?? null,
      }),
    }),

  // Helper to construct download URL for /export/download
  exportDownloadUrl: (filepath: string): string => {
    const url = new URL(`${apiBase()}/export/download`, window.location.href);
    url.searchParams.set("filepath", filepath);
    return url.toString();
  },
};

// frontend/src/state/scenario.ts
// Production-grade, framework-free scenario store using useSyncExternalStore.
// - Centralized scenario state (persona, filters, weights, scenarioId)
// - Safe updates and subscribers for React components
// - Session-persistent (sessionStorage), ephemeral chat session id
// - No external dependencies (no Redux, no Zustand)

// React hook is imported where needed
import { useSyncExternalStore } from "react";
import type { Filters, ScenarioMethod } from "../api/client";

export type ScenarioState = {
  scenarioId: string | null;
  persona: "regular_citizen" | string;
  filters: Filters;
  alpha: Record<string, number>;
  subWeights: Record<string, Record<string, number>>;
  method: ScenarioMethod;
  // Ephemeral chat session id - resets per tab/session
  chatSessionId: string;
};

type ScenarioActions = {
  setScenarioId: (id: string | null) => void;
  setPersona: (p: ScenarioState["persona"]) => void;
  setFilters: (f: Filters) => void;
  setAlpha: (a: Record<string, number>) => void;
  setSubWeights: (w: Record<string, Record<string, number>>) => void;
  setMethod: (m: ScenarioMethod) => void;
  reset: () => void;
};

type Listener = () => void;

const KEY = "fvi:scenario";
const DEFAULT_STATE: ScenarioState = {
  scenarioId: null,
  persona: "regular_citizen",
  filters: {},
  alpha: {},
  subWeights: {},
  method: { aggregation: "weighted_mean", normalization: "minmax" },
  chatSessionId: createEphemeralId(),
};

// -------- persistence helpers --------

function createEphemeralId(): string {
  // URL-safe, short UUID-ish
  const rand = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(rand)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .slice(0, 24);
}

function loadPersisted(): ScenarioState {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_STATE, chatSessionId: createEphemeralId() };
    const obj = JSON.parse(raw);
    // ensure chatSessionId exists
    if (!obj.chatSessionId) obj.chatSessionId = createEphemeralId();
    return obj as ScenarioState;
  } catch {
    return { ...DEFAULT_STATE, chatSessionId: createEphemeralId() };
  }
}

function persist(state: ScenarioState) {
  try {
    const safe = { ...state, chatSessionId: state.chatSessionId }; // include for continuity within session
    sessionStorage.setItem(KEY, JSON.stringify(safe));
  } catch {
    // ignore quota errors
  }
}

// -------- minimal store implementation --------

class ScenarioStoreImpl {
  private state: ScenarioState = loadPersisted();
  private listeners: Set<Listener> = new Set();

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  getSnapshot(): ScenarioState {
    return this.state;
  }

  private set(partial: Partial<ScenarioState>) {
    this.state = { ...this.state, ...partial };
    persist(this.state);
    this.emit();
  }

  private emit() {
    for (const fn of this.listeners) {
      try {
        fn();
      } catch {
        // swallow listener errors
      }
    }
  }

  // ---- actions ----

  setScenarioId = (id: string | null) => this.set({ scenarioId: id });

  setPersona = (p: ScenarioState["persona"]) => this.set({ persona: p });

  setFilters = (f: Filters) => this.set({ filters: { ...f } });

  setAlpha = (a: Record<string, number>) => this.set({ alpha: { ...a } });

  setSubWeights = (w: Record<string, Record<string, number>>) =>
    this.set({ subWeights: { ...w } });

  setMethod = (m: ScenarioMethod) => this.set({ method: { ...m } });

  reset = () =>
    this.set({
      ...DEFAULT_STATE,
      chatSessionId: createEphemeralId(), // new ephemeral session
      scenarioId: null,
    });
}

const store = new ScenarioStoreImpl();

// ---- Public hook & actions ----

export function useScenarioStore(): ScenarioState & ScenarioActions {
  const snapshot = useSyncExternalStore(
    (fn) => store.subscribe(fn),
    () => store.getSnapshot(),
    () => store.getSnapshot()
  );

  // Bind actions to return stable identities (no re-creates)
  return {
    ...snapshot,
    setScenarioId: store.setScenarioId,
    setPersona: store.setPersona,
    setFilters: store.setFilters,
    setAlpha: store.setAlpha,
    setSubWeights: store.setSubWeights,
    setMethod: store.setMethod,
    reset: store.reset,
  };
}

// Also export imperative API for non-React callers (e.g., utility modules)
export const scenarioActions: ScenarioActions = {
  setScenarioId: store.setScenarioId,
  setPersona: store.setPersona,
  setFilters: store.setFilters,
  setAlpha: store.setAlpha,
  setSubWeights: store.setSubWeights,
  setMethod: store.setMethod,
  reset: store.reset,
};

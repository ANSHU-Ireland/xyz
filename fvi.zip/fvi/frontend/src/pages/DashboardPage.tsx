import React from "react";
import SummaryCard from "../components/SummaryCard";
import Map from "../components/Map";
import Trend from "../components/Trend";
import WeightSliders from "../components/WeightSliders";
import ChatPanel from "../components/ChatPanel";

export default function DashboardPage() {
  return (
    <div style={{ height: "100vh", display: "grid", gridTemplateRows: "auto 1fr", background: "#f9fafb" }}>
      {/* Top bar */}
      <div style={{ padding: "10px 16px", borderBottom: "1px solid #e5e7eb", background: "#ffffff" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ fontWeight: 700 }}>FVI – Coal Viability Dashboard</div>
          <div style={{ color: "#6b7280", fontSize: 12 }}>
            Higher score = more viable • Classes: sustainable / critical transition / decommission
          </div>
        </div>
      </div>

      {/* Main content */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "minmax(0,1fr) 380px",
          gap: 16,
          padding: 16,
        }}
      >
        {/* Left column */}
        <div style={{ display: "grid", gridTemplateRows: "260px 1fr 280px", gap: 16, minWidth: 0 }}>
          <SummaryCard />
          <Map />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, minHeight: 0 }}>
            <Trend />
            <WeightSliders />
          </div>
        </div>

        {/* Right column */}
        <div style={{ minHeight: 0 }}>
          <ChatPanel />
        </div>
      </div>

      {/* Small screens: stack columns */}
      <style>{`
        @media (max-width: 1100px) {
          div[style*="grid-template-columns: minmax(0,1fr) 380px"] {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}

import React, { useEffect, useMemo, useState } from "react";
import { api, ExplainResponse, ProposalOut, ScenarioOut, ScoresResponse } from "../api/client";
import { useScenarioStore } from "../state/scenario";

type LocalWeights = Record<string, number>;
type Tab = "score" | "submetric";

export default function WeightSliders() {
  const { scenarioId, setScenarioId, filters, alpha, setAlpha, subWeights, setSubWeights } = useScenarioStore();

  const [scoresMeta, setScoresMeta] = useState<{ names: string[]; alpha: LocalWeights }>({ names: [], alpha: {} });
  const [tab, setTab] = useState<Tab>("score");

  // Submetric editing state
  const [selectedScore, setSelectedScore] = useState<string | null>(null);
  const [submetricIds, setSubmetricIds] = useState<string[]>([]);
  const [localAlpha, setLocalAlpha] = useState<LocalWeights>({});
  const [localSubs, setLocalSubs] = useState<Record<string, number>>({});

  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // Ensure scenario exists
  useEffect(() => {
    (async () => {
      if (scenarioId) return;
      try {
        const scr = await api.getScores({ filters });
        const names = scr.meta?.scores || [];
        const a = scr.meta?.alpha || {};
        const sc: ScenarioOut = await api.createScenario({
          persona: "regular_citizen",
          filters,
          alpha: a,
          sub_weights: {},
          method: { aggregation: "weighted_mean", normalization: "minmax" },
        });
        setScenarioId(sc.scenario_id);
        setAlpha(sc.alpha);
        setSubWeights(sc.sub_weights);
      } catch (e: any) {
        // non-fatal; user can still browse
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]); // only when filters change significantly

  // Load meta for listing scores & current alpha
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const scr: ScoresResponse = await api.getScores({ filters });
        const names = scr.meta?.scores || [];
        const a = scr.meta?.alpha || {};
        if (!alive) return;
        setScoresMeta({ names, alpha: a });
        setLocalAlpha(a);
        if (!selectedScore && names.length) setSelectedScore(names[0]);
      } catch (e: any) {
        if (!alive) return;
        setErr(e?.message || "Failed to load scores meta");
      }
    })();
    return () => {
      alive = false;
    };
  }, [filters]); // refresh when filters change

  // Load submetric IDs for selected score using Explain API contributions
  useEffect(() => {
    let alive = true;
    (async () => {
      if (!selectedScore) return;
      try {
        const exp: ExplainResponse = await api.explain({ filters });
        const blk = exp.scores.find((s) => s.score === selectedScore);
        const ids = (blk?.contributions || []).map((c) => c.id);
        if (!alive) return;
        setSubmetricIds(ids);
        const current = subWeights[selectedScore] || {};
        const local: Record<string, number> = {};
        if (ids.length) {
          // If missing, start with uniform weights
          const uniform = 1 / ids.length;
          for (const id of ids) local[id] = current[id] ?? uniform;
        }
        setLocalSubs(local);
      } catch (e: any) {
        if (!alive) return;
        setErr(e?.message || "Failed to load submetrics");
      }
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedScore, filters, subWeights]);

  // Helpers
  const sumAlpha = useMemo(() => Object.values(localAlpha).reduce((a, b) => a + (b || 0), 0), [localAlpha]);
  const sumSubs = useMemo(() => Object.values(localSubs).reduce((a, b) => a + (b || 0), 0), [localSubs]);

  const updateAlpha = (name: string, v: number) => {
    setLocalAlpha((s) => ({ ...s, [name]: clamp01(v) }));
  };
  const updateSub = (id: string, v: number) => {
    setLocalSubs((s) => ({ ...s, [id]: clamp01(v) }));
  };

  const saveAlpha = async () => {
    if (!scenarioId) return;
    setBusy(true); setErr(null); setMsg(null);
    try {
      const targets = Object.entries(localAlpha).map(([id, w]) => ({ id, target_weight: w }));
      const p: ProposalOut = await api.proposeWeightUpdate(scenarioId, { scope: "score", targets });
      // Optional: inspect p.preview.alpha_diff
      const committed = await api.commitWeightUpdate(scenarioId, p.change_id);
      setAlpha(committed.alpha);
      setMsg("Score weights updated.");
    } catch (e: any) {
      setErr(e?.message || "Failed to update score weights");
    } finally {
      setBusy(false);
    }
  };

  const saveSubs = async () => {
    if (!scenarioId || !selectedScore) return;
    setBusy(true); setErr(null); setMsg(null);
    try {
      const targets = Object.entries(localSubs).map(([sub, w]) => ({
        id: `${selectedScore}.${sub}`,
        target_weight: w,
      }));
      const p: ProposalOut = await api.proposeWeightUpdate(scenarioId, { scope: "submetric", targets });
      const committed = await api.commitWeightUpdate(scenarioId, p.change_id);
      setSubWeights(committed.sub_weights);
      setMsg(`Submetric weights updated for ${selectedScore}.`);
    } catch (e: any) {
      setErr(e?.message || "Failed to update submetric weights");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ border: "1px solid #e5e7eb", borderRadius: 12, background: "#fff" }}>
      <div style={{ padding: "8px 12px", borderBottom: "1px solid #e5e7eb", background: "#fafafa", display: "flex", gap: 12 }}>
        <strong>Weight Editor</strong>
        <div style={{ display: "flex", gap: 8, fontSize: 13 }}>
          <TabButton label="Score weights (α)" active={tab === "score"} onClick={() => setTab("score")} />
          <TabButton label="Submetric weights" active={tab === "submetric"} onClick={() => setTab("submetric")} />
        </div>
      </div>

      {tab === "score" ? (
        <div style={{ padding: 12 }}>
          {scoresMeta.names.length === 0 ? (
            <div style={{ color: "#6b7280" }}>No scores available.</div>
          ) : (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 70px", gap: 10 }}>
                {scoresMeta.names.map((name) => (
                  <React.Fragment key={name}>
                    <SliderRow
                      label={pretty(name)}
                      value={localAlpha[name] ?? 0}
                      onChange={(v) => updateAlpha(name, v)}
                    />
                    <div style={{ textAlign: "right", fontVariantNumeric: "tabular-nums" }}>
                      {Math.round(100 * (localAlpha[name] ?? 0))}%
                    </div>
                  </React.Fragment>
                ))}
              </div>
              <div style={{ marginTop: 8, fontSize: 12, color: sumAlpha.toFixed(3) === "1.000" ? "#059669" : "#b91c1c" }}>
                Sum = {(sumAlpha * 100).toFixed(0)}% (the backend will normalize to 100% on save)
              </div>
              <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
                <button onClick={saveAlpha} disabled={busy} style={btnPrimary}>
                  {busy ? "Saving…" : "Save weights"}
                </button>
                {msg && <div style={{ color: "#065f46", fontSize: 12 }}>{msg}</div>}
                {err && <div style={{ color: "#b91c1c", fontSize: 12 }}>{err}</div>}
              </div>
            </>
          )}
        </div>
      ) : (
        <div style={{ padding: 12 }}>
          {/* Score selector */}
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}>
            <div style={{ fontSize: 13, color: "#374151" }}>Score:</div>
            <select
              value={selectedScore || ""}
              onChange={(e) => setSelectedScore(e.target.value || null)}
              style={{ padding: 6, borderRadius: 8, border: "1px solid #e5e7eb" }}
            >
              {(scoresMeta.names || []).map((n) => (
                <option key={n} value={n}>{pretty(n)}</option>
              ))}
            </select>
          </div>

          {selectedScore && submetricIds.length === 0 ? (
            <div style={{ color: "#6b7280" }}>No submetrics detected for this score.</div>
          ) : (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 70px", gap: 10 }}>
                {submetricIds.map((id) => (
                  <React.Fragment key={id}>
                    <SliderRow
                      label={pretty(id)}
                      value={localSubs[id] ?? 0}
                      onChange={(v) => updateSub(id, v)}
                    />
                    <div style={{ textAlign: "right", fontVariantNumeric: "tabular-nums" }}>
                      {Math.round(100 * (localSubs[id] ?? 0))}%
                    </div>
                  </React.Fragment>
                ))}
              </div>
              <div style={{ marginTop: 8, fontSize: 12, color: sumSubs ? "#6b7280" : "#b91c1c" }}>
                Sum = {(sumSubs * 100).toFixed(0)}% (the backend will normalize to 100% on save)
              </div>
              <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
                <button onClick={saveSubs} disabled={busy} style={btnPrimary}>
                  {busy ? "Saving…" : "Save submetric weights"}
                </button>
                {msg && <div style={{ color: "#065f46", fontSize: 12 }}>{msg}</div>}
                {err && <div style={{ color: "#b91c1c", fontSize: 12 }}>{err}</div>}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function SliderRow({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number; // 0..1
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div style={{ fontSize: 12, color: "#374151", marginBottom: 4 }}>{label}</div>
      <input
        type="range"
        min={0}
        max={100}
        value={Math.round((value || 0) * 100)}
        onChange={(e) => onChange((Number(e.target.value) || 0) / 100)}
        style={{ width: "100%" }}
      />
    </div>
  );
}

function TabButton({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{
        borderRadius: 999,
        padding: "4px 10px",
        border: `1px solid ${active ? "#10b981" : "#e5e7eb"}`,
        background: active ? "#ecfdf5" : "#ffffff",
        color: active ? "#065f46" : "#374151",
        cursor: "pointer",
        fontSize: 12,
      }}
    >
      {label}
    </button>
  );
}

const btnPrimary: React.CSSProperties = {
  borderRadius: 8,
  border: "1px solid #10b981",
  background: "#10b981",
  color: "#fff",
  padding: "8px 12px",
  cursor: "pointer",
};

function pretty(s: string) {
  return s.replace(/[_\-]+/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
}
function clamp01(n: number) {
  return Math.max(0, Math.min(1, n));
}

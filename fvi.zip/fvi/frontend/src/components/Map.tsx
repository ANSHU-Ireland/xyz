import React, { useEffect, useMemo, useRef, useState } from "react";
import { api } from "../api/client";
import { useScenarioStore } from "../state/scenario";

type GeoJSON = {
  type: "FeatureCollection";
  features: {
    type: "Feature";
    geometry: { type: "Polygon" | "MultiPolygon"; coordinates: number[][][] | number[][][][] };
    properties: Record<string, any>;
  }[];
};

type FviByIso = Record<string, number>;

function isoFromProps(props: Record<string, any>): string | null {
  const cand =
    props.iso3 ??
    props.ISO3 ??
    props.ISO_A3 ??
    props.ADM0_A3 ??
    props.ADM0_A3_US ??
    props.SOV_A3;
  if (!cand) return null;
  const iso = String(cand).toUpperCase().trim();
  // filter out non-ISO (e.g., -99 from some datasets)
  if (iso === "-99" || iso.length !== 3) return null;
  return iso;
}

function nameFromProps(props: Record<string, any>): string {
  return (
    props.name ??
    props.NAME ??
    props.ADMIN ??
    props.COUNTRY ??
    props.SOVEREIGNT ??
    "Unknown"
  );
}

// Linear color mix between two hex colors
function mix(a: string, b: string, t: number): string {
  const pa = parseInt(a.replace("#", ""), 16);
  const pb = parseInt(b.replace("#", ""), 16);
  const ar = (pa >> 16) & 255,
    ag = (pa >> 8) & 255,
    ab = pa & 255;
  const br = (pb >> 16) & 255,
    bg = (pb >> 8) & 255,
    bb = pb & 255;
  const r = Math.round(ar + (br - ar) * t);
  const g = Math.round(ag + (bg - ag) * t);
  const b2 = Math.round(ab + (bb - ab) * t);
  return `#${r.toString(16).padStart(2, "0")}${g
    .toString(16)
    .padStart(2, "0")}${b2.toString(16).padStart(2, "0")}`;
}

// Equirectangular projection (lon/lat in degrees -> x/y in [0..W],[0..H])
function project(lon: number, lat: number, W: number, H: number): [number, number] {
  const x = ((lon + 180) / 360) * W;
  const y = ((90 - lat) / 180) * H;
  return [x, y];
}

function pathFromPolygon(coords: number[][], W: number, H: number): string {
  // coords: array of [lon,lat]
  if (!coords.length) return "";
  let d = "";
  coords.forEach((pt, i) => {
    const [x, y] = project(pt[0], pt[1], W, H);
    d += (i === 0 ? "M" : "L") + x.toFixed(2) + "," + y.toFixed(2);
  });
  return d + "Z";
}

function pathFromGeometry(
  geometry: GeoJSON["features"][number]["geometry"],
  W: number,
  H: number
): string {
  if (geometry.type === "Polygon") {
    const rings = geometry.coordinates as number[][][];
    return rings.map((ring) => pathFromPolygon(ring, W, H)).join(" ");
  }
  if (geometry.type === "MultiPolygon") {
    const polys = geometry.coordinates as number[][][][];
    return polys
      .map((poly) => poly.map((ring) => pathFromPolygon(ring, W, H)).join(" "))
      .join(" ");
  }
  return "";
}

export default function Map({
  width = 960,
  height = 520,
}: {
  width?: number;
  height?: number;
}) {
  const { filters, setFilters } = useScenarioStore();

  const [geo, setGeo] = useState<GeoJSON | null>(null);
  const [fvi, setFvi] = useState<FviByIso>({});
  const [hover, setHover] = useState<{ iso3: string; name: string; fvi?: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // Load geojson once
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await fetch("/api/geo/regions");
        if (!res.ok) throw new Error(`Geo fetch failed ${res.status}`);
        const data = (await res.json()) as GeoJSON;
        if (alive) setGeo(data);
      } catch (e: any) {
        if (alive) setErr(e?.message || "Failed to load geojson");
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  // Load FVI for current filters; take latest year
  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      try {
        const scores = await api.getScores({ filters });
        // choose latest year per iso3
        const byIso: FviByIso = {};
        for (const p of scores.fvi) {
          const key = `${p.iso3}`;
          const prev = byIso[key];
          // keep the latest year
          if (prev === undefined) {
            byIso[key] = p.value;
          } else {
            // We don't track year; approximate by replacing if later.
            // Build a map of latest-year values properly:
          }
        }
        // Better: compute latest year then only take those points
        const latestYear =
          scores.fvi.length > 0
            ? scores.fvi.reduce((m, p) => (p.year > m ? p.year : m), scores.fvi[0].year)
            : undefined;
        const byIsoLatest: FviByIso = {};
        if (latestYear !== undefined) {
          for (const p of scores.fvi) {
            if (p.year === latestYear) byIsoLatest[p.iso3] = p.value;
          }
        }
        if (alive) setFvi(byIsoLatest);
      } catch (e: any) {
        if (alive) setErr(e?.message || "Failed to load FVI");
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [filters]);

  const colors = useMemo(() => {
    // Palette: low FVI -> light gray; high FVI -> green
    const scale = (v: number) => {
      const t = Math.max(0, Math.min(1, v)); // FVI is 0..1
      // mix from light gray to green
      return mix("#e5e7eb", "#10b981", t);
    };
    return { scale, stroke: "#9ca3af", noData: "#f3f4f6" };
  }, []);

  const selectedIso = Array.isArray(filters.regions) && filters.regions.length === 1 ? filters.regions[0] : null;

  // Tooltip position
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [tooltipPos, setTooltipPos] = useState<{ x: number; y: number } | null>(null);

  const onMouseMove = (e: React.MouseEvent) => {
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return;
    setTooltipPos({ x: e.clientX - rect.left + 12, y: e.clientY - rect.top + 12 });
  };

  const onCountryClick = (iso: string, shiftKey: boolean) => {
    if (shiftKey) {
      // clear selection
      setFilters({ ...filters, regions: undefined });
      return;
    }
    setFilters({ ...filters, regions: [iso] });
  };

  return (
    <div style={{ border: "1px solid #e5e7eb", borderRadius: 12, background: "#fff" }}>
      <div style={{ padding: "8px 12px", borderBottom: "1px solid #e5e7eb", background: "#fafafa" }}>
        <strong>Country FVI Map</strong>{" "}
        <span style={{ color: "#6b7280", fontSize: 12 }}>
          Latest year • Click a country to filter • Shift+Click to clear
        </span>
      </div>

      <div style={{ position: "relative" }}>
        <svg
          ref={svgRef}
          width={width}
          height={height}
          viewBox={`0 0 ${width} ${height}`}
          onMouseMove={onMouseMove}
          style={{ display: "block" }}
        >
          {/* Ocean */}
          <rect x={0} y={0} width={width} height={height} fill="#eef2ff" />

          {/* Countries */}
          {geo?.features.map((f, idx) => {
            const iso = isoFromProps(f.properties);
            if (!iso) return null;
            const val = fvi[iso]; // 0..1
            const fill = typeof val === "number" ? colors.scale(val) : colors.noData;
            const d = pathFromGeometry(f.geometry, width, height);
            const isSelected = selectedIso === iso;

            return (
              <path
                key={idx}
                d={d}
                fill={fill}
                stroke={isSelected ? "#111827" : colors.stroke}
                strokeWidth={isSelected ? 1.2 : 0.5}
                onMouseEnter={() =>
                  setHover({ iso3: iso, name: nameFromProps(f.properties), fvi: val })
                }
                onMouseLeave={() => setHover(null)}
                onClick={(e) => onCountryClick(iso, e.shiftKey)}
                style={{ cursor: "pointer" }}
              />
            );
          })}

          {/* Selected outline atop */}
          {geo?.features.map((f, idx) => {
            const iso = isoFromProps(f.properties);
            if (!iso || iso !== selectedIso) return null;
            const d = pathFromGeometry(f.geometry, width, height);
            return <path key={`sel-${idx}`} d={d} fill="none" stroke="#111827" strokeWidth={1.6} pointerEvents="none" />;
          })}
        </svg>

        {/* Tooltip */}
        {hover && tooltipPos && (
          <div
            style={{
              position: "absolute",
              left: tooltipPos.x,
              top: tooltipPos.y,
              transform: "translate(0, 0)",
              background: "#111827",
              color: "#fff",
              padding: "6px 8px",
              borderRadius: 6,
              fontSize: 12,
              pointerEvents: "none",
              boxShadow: "0 1px 3px rgba(0,0,0,0.25)",
            }}
          >
            <div style={{ fontWeight: 600 }}>{hover.name} ({hover.iso3})</div>
            <div>FVI: {typeof hover.fvi === "number" ? (hover.fvi * 100).toFixed(1) : "—"}/100</div>
          </div>
        )}
      </div>

      {err && (
        <div style={{ padding: 10, color: "#b91c1c", fontSize: 12, borderTop: "1px solid #fee2e2", background: "#fef2f2" }}>
          {err}
        </div>
      )}
    </div>
  );
}

import React, { useEffect, useMemo, useRef, useState } from "react";
import { api, ScoresResponse } from "../api/client";
import { useScenarioStore } from "../state/scenario";

type Pt = { year: number; value: number };

export default function Trend({
  height = 220,
}: {
  height?: number;
}) {
  const { filters } = useScenarioStore();
  const iso = Array.isArray(filters.regions) && filters.regions.length === 1 ? filters.regions[0] : null;

  const [data, setData] = useState<Pt[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [width, setWidth] = useState<number>(720);

  // Resize observer for responsive width
  useEffect(() => {
    if (!wrapRef.current) return;
    const ro = new ResizeObserver((entries) => {
      for (const e of entries) setWidth(Math.max(320, e.contentRect.width));
    });
    ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, []);

  // Fetch FVI over all years for selected ISO
  useEffect(() => {
    let alive = true;
    (async () => {
      setErr(null);
      setData([]);
      if (!iso) return;
      setLoading(true);
      try {
        // Request with only region filter; omit year to receive all available years
        const res: ScoresResponse = await api.getScores({ filters: { regions: [iso] } });
        const series = res.fvi
          .filter((p) => p.iso3 === iso)
          .sort((a, b) => a.year - b.year)
          .map((p) => ({ year: p.year, value: p.value }));
        if (!alive) return;
        setData(series);
      } catch (e: any) {
        if (!alive) return;
        setErr(e?.message || "Failed to load trend");
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [iso]);

  const bbox = useMemo(() => {
    if (data.length === 0) return { minY: 0, maxY: 1, minX: 0, maxX: 1 };
    const minY = Math.max(0, Math.min(...data.map((d) => d.value)));
    const maxY = Math.min(1, Math.max(...data.map((d) => d.value)));
    const minX = Math.min(...data.map((d) => d.year));
    const maxX = Math.max(...data.map((d) => d.year));
    return { minY, maxY, minX, maxX };
  }, [data]);

  // Scales
  const padL = 40;
  const padR = 12;
  const padT = 16;
  const padB = 28;
  const W = width;
  const H = height;
  const innerW = Math.max(10, W - padL - padR);
  const innerH = Math.max(10, H - padT - padB);

  const x = (year: number) =>
    padL + ((year - bbox.minX) / Math.max(1, bbox.maxX - bbox.minX)) * innerW;
  const y = (val: number) =>
    padT + (1 - (val - bbox.minY) / Math.max(0.0001, bbox.maxY - bbox.minY)) * innerH;

  const path = useMemo(() => {
    if (data.length === 0) return "";
    return data.map((d, i) => `${i === 0 ? "M" : "L"}${x(d.year).toFixed(2)},${y(d.value).toFixed(2)}`).join(" ");
  }, [data, bbox, width, height]);

  const ticksY = [0, 0.25, 0.5, 0.75, 1];
  const ticksX = useMemo(() => {
    if (data.length <= 1) return data.map((d) => d.year);
    const years = data.map((d) => d.year);
    const step = Math.ceil(years.length / 6);
    const picked: number[] = [];
    for (let i = 0; i < years.length; i += step) picked.push(years[i]);
    if (!picked.includes(years[years.length - 1])) picked.push(years[years.length - 1]);
    return picked;
  }, [data]);

  // Hover state
  const [hover, setHover] = useState<Pt | null>(null);

  return (
    <div ref={wrapRef} style={{ border: "1px solid #e5e7eb", borderRadius: 12, background: "#fff" }}>
      <div style={{ padding: "8px 12px", borderBottom: "1px solid #e5e7eb", background: "#fafafa" }}>
        <strong>FVI Trend</strong>{" "}
        <span style={{ color: "#6b7280", fontSize: 12 }}>
          {iso ? `Country: ${iso}` : "Select a country on the map to view trend"}
        </span>
      </div>

      {loading ? (
        <div style={{ padding: 12, color: "#6b7280" }}>Loading…</div>
      ) : err ? (
        <div style={{ padding: 12, color: "#b91c1c" }}>{err}</div>
      ) : !iso ? (
        <div style={{ padding: 12, color: "#6b7280" }}>No country selected.</div>
      ) : data.length === 0 ? (
        <div style={{ padding: 12, color: "#6b7280" }}>No time-series available.</div>
      ) : (
        <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} style={{ display: "block" }}>
          {/* Axes */}
          {/* Y grid */}
          {ticksY.map((t, i) => {
            const yy = y(t);
            return (
              <g key={i}>
                <line x1={padL} y1={yy} x2={W - padR} y2={yy} stroke="#f3f4f6" />
                <text x={padL - 8} y={yy + 3} textAnchor="end" fontSize={11} fill="#6b7280">
                  {(t * 100).toFixed(0)}
                </text>
              </g>
            );
          })}
          {/* X ticks */}
          {ticksX.map((yr) => (
            <g key={yr}>
              <line x1={x(yr)} y1={H - padB} x2={x(yr)} y2={padT} stroke="#f9fafb" />
              <text x={x(yr)} y={H - 8} textAnchor="middle" fontSize={11} fill="#6b7280">
                {yr}
              </text>
            </g>
          ))}

          {/* Line */}
          <path d={path} fill="none" stroke="#2563eb" strokeWidth={2} />

          {/* Points & hover */}
          {data.map((d) => (
            <circle
              key={d.year}
              cx={x(d.year)}
              cy={y(d.value)}
              r={3}
              fill="#1d4ed8"
              onMouseEnter={() => setHover(d)}
              onMouseLeave={() => setHover(null)}
            />
          ))}

          {/* Hover tooltip */}
          {hover && (
            <g>
              <circle cx={x(hover.year)} cy={y(hover.value)} r={5} fill="none" stroke="#111827" />
              <rect
                x={x(hover.year) + 10}
                y={y(hover.value) - 28}
                width={120}
                height={40}
                rx={6}
                fill="#111827"
                opacity={0.92}
              />
              <text x={x(hover.year) + 16} y={y(hover.value) - 12} fill="#fff" fontSize={12}>
                {hover.year}
              </text>
              <text x={x(hover.year) + 16} y={y(hover.value) + 4} fill="#fff" fontSize={12}>
                FVI {(hover.value * 100).toFixed(1)}/100
              </text>
            </g>
          )}
        </svg>
      )}
    </div>
  );
}

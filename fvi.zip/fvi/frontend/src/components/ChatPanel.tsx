import React, { useCallback, useMemo, useRef, useState } from "react";
import { api, ApiError } from "../api/client";
import { useScenarioStore } from "../state/scenario";

type Msg = {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  citations?: { id?: any; title?: string; score?: number }[];
  toolCalls?: any[];
  toolResults?: any[];
};

function uid() {
  return Math.random().toString(36).slice(2, 11);
}

export default function ChatPanel() {
  const {
    chatSessionId,
    scenarioId,
    persona,
    filters,
  } = useScenarioStore();

  const [messages, setMessages] = useState<Msg[]>([
    {
      id: uid(),
      role: "system",
      text:
        "Ask about coal viability in a country. I can compute FVI, explain drivers, and adjust weights per your scenario.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement | null>(null);

  const canSend = useMemo(
    () => !!input.trim() && !loading,
    [input, loading]
  );

  const scrollToBottom = useCallback(() => {
    requestAnimationFrame(() => endRef.current?.scrollIntoView({ behavior: "smooth" }));
  }, []);

  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text) return;

    const userMsg: Msg = { id: uid(), role: "user", text };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await api.chat({
        session_id: chatSessionId,
        message: text,
        persona,
        scenario_id: scenarioId ?? undefined,
        filters,
      });

      const bot: Msg = {
        id: uid(),
        role: "assistant",
        text: res.text || "(no response)",
        citations: res.citations || [],
        toolCalls: res.tool_calls || [],
        toolResults: res.tool_results || [],
      };
      setMessages((m) => [...m, bot]);
      scrollToBottom();
    } catch (e) {
      const err = e as ApiError;
      const bot: Msg = {
        id: uid(),
        role: "assistant",
        text:
          err?.detail?.detail ||
          err?.detail?.message ||
          err?.message ||
          "Sorry—something went wrong.",
      };
      setMessages((m) => [...m, bot]);
    } finally {
      setLoading(false);
      scrollToBottom();
    }
  }, [chatSessionId, persona, scenarioId, filters, input, scrollToBottom]);

  const handleKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (canSend) void handleSend();
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", border: "1px solid #e5e7eb", borderRadius: 8 }}>
      {/* Header */}
      <div style={{ padding: "10px 12px", borderBottom: "1px solid #e5e7eb", background: "#fafafa" }}>
        <strong>Chat</strong>{" "}
        <span style={{ color: "#6b7280" }}>Session: {chatSessionId.slice(0, 8)}</span>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: 12 }}>
        {messages.map((m) => (
          <MessageBubble key={m.id} msg={m} />
        ))}
        <div ref={endRef} />
      </div>

      {/* Composer */}
      <div style={{ borderTop: "1px solid #e5e7eb", padding: 10 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask about a country (e.g., 'Explain India's FVI and key drivers for 2024')"
            rows={2}
            style={{
              flex: 1,
              resize: "vertical",
              padding: 10,
              borderRadius: 8,
              border: "1px solid #d1d5db",
              font: "inherit",
            }}
          />
          <button
            onClick={handleSend}
            disabled={!canSend}
            style={{
              minWidth: 90,
              borderRadius: 8,
              border: "1px solid #10b981",
              background: canSend ? "#10b981" : "#9ca3af",
              color: "white",
              padding: "8px 12px",
              cursor: canSend ? "pointer" : "not-allowed",
            }}
            title={scenarioId ? `Scenario: ${scenarioId}` : "No scenario selected"}
          >
            {loading ? "Sending…" : "Send"}
          </button>
        </div>
        <div style={{ marginTop: 6, color: "#6b7280", fontSize: 12 }}>
          The model uses your <em>persona</em> and <em>filters</em> to fetch scores, adjust weights, and classify.
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ msg }: { msg: Msg }) {
  const isUser = msg.role === "user";
  const isSystem = msg.role === "system";
  const bg = isSystem ? "#f3f4f6" : isUser ? "#e0f2fe" : "#f9fafb";
  const align = isUser ? "flex-end" : "flex-start";
  const border = isSystem ? "#e5e7eb" : isUser ? "#93c5fd" : "#e5e7eb";

  return (
    <div style={{ display: "flex", justifyContent: align, margin: "8px 0" }}>
      <div
        style={{
          maxWidth: 760,
          whiteSpace: "pre-wrap",
          background: bg,
          border: `1px solid ${border}`,
          borderRadius: 10,
          padding: "10px 12px",
          color: "#111827",
          fontSize: 14,
        }}
      >
        {!isSystem && (
          <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 4, color: "#6b7280" }}>
            {isUser ? "You" : "Assistant"}
          </div>
        )}
        <div>{msg.text}</div>

        {/* Citations */}
        {!!msg.citations?.length && (
          <div style={{ marginTop: 8, fontSize: 12, color: "#6b7280" }}>
            <div style={{ fontWeight: 600, marginBottom: 4 }}>Citations</div>
            <ul style={{ margin: 0, paddingLeft: 18 }}>
              {msg.citations!.slice(0, 6).map((c, i) => (
                <li key={i}>
                  {c.title || "doc"} {typeof c.score === "number" ? `(score ${c.score.toFixed(3)})` : ""}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Tool calls (debug aid) */}
        {!!msg.toolCalls?.length && (
          <details style={{ marginTop: 6 }}>
            <summary style={{ cursor: "pointer", fontSize: 12, color: "#6b7280" }}>Details</summary>
            <pre style={{ whiteSpace: "pre-wrap", overflowX: "auto", fontSize: 12 }}>
              {JSON.stringify({ toolCalls: msg.toolCalls, toolResults: msg.toolResults }, null, 2)}
            </pre>
          </details>
        )}
      </div>
    </div>
  );
}

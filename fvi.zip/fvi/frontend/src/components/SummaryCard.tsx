import React, { useEffect, useMemo, useState } from "react";
import { api, ClassifyResponse, ScoresResponse } from "../api/client";
import { useScenarioStore } from "../state/scenario";

// Label colors
const LABELS: Record<string, { bg: string; fg: string; text: string }> = {
  sustainable: { bg: "#ecfdf5", fg: "#065f46", text: "Sustainable" },
  critical_transition: { bg: "#fffbeb", fg: "#92400e", text: "Critical Transition Needed" },
  decommission: { bg: "#fef2f2", fg: "#991b1b", text: "Decommission" },
  unknown: { bg: "#f3f4f6", fg: "#374151", text: "Unknown" },
};

type TargetPoint = { iso3: string; year: number; fvi: number; label: keyof typeof LABELS };

export default function SummaryCard() {
  const { filters, alpha } = useScenarioStore();
  const [scoresRes, setScoresRes] = useState<ScoresResponse | null>(null);
  const [classRes, setClassRes] = useState<ClassifyResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      setErr(null);
      try {
        const [s, c] = await Promise.all([
          api.getScores({ filters, alpha }),
          api.classify({ filters, alpha }),
        ]);
        if (!alive) return;
        setScoresRes(s);
        setClassRes(c);
      } catch (e: any) {
        if (!alive) return;
        setErr(e?.message || "Failed to load summary");
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [filters, alpha]);

  const target: TargetPoint | null = useMemo(() => {
    if (!scoresRes) return null;
    const pts = scoresRes.fvi;
    if (!pts || pts.length === 0) return null;

    // If a single region & explicit year provided, pick that
    const hasSingleRegion = Array.isArray(filters.regions) && filters.regions.length === 1;
    const explicitYear = typeof filters.year === "number";

    let chosen = null as TargetPoint | null;

    if (hasSingleRegion && explicitYear) {
      const [r] = filters.regions!;
      const y = filters.year as number;
      const p = pts.find((x) => x.iso3 === r && x.year === y);
      if (p) {
        chosen = { iso3: p.iso3, year: p.year, fvi: p.value, label: "unknown" };
      }
    }

    // Otherwise: select latest year, highest FVI
    if (!chosen) {
      const latestYear = pts.reduce((m, p) => (p.year > m ? p.year : m), pts[0].year);
      const latest = pts.filter((p) => p.year === latestYear);
      const best = latest.reduce((a, b) => (a.value >= b.value ? a : b));
      chosen = { iso3: best.iso3, year: best.year, fvi: best.value, label: "unknown" };
    }

    // Attach classification label if available
    if (classRes?.results?.length) {
      const match = classRes.results.find((r) => r.iso3 === chosen!.iso3 && r.year === chosen!.year);
      if (match) chosen!.label = (match.label as any) || "unknown";
    }

    return chosen;
  }, [scoresRes, classRes, filters]);

  const alphaPairs = useMemo(() => {
    const a = scoresRes?.meta?.alpha || {};
    return Object.entries(a).sort(([, av], [, bv]) => (bv as number) - (av as number));
  }, [scoresRes]);

  const coveragePairs = useMemo(() => {
    const cov = scoresRes?.coverage || {};
    return Object.entries(cov).sort(([, av], [, bv]) => (bv as number) - (av as number));
  }, [scoresRes]);

  return (
    <div style={{ border: "1px solid #e5e7eb", borderRadius: 12, padding: 16, background: "#ffffff" }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 12 }}>
        <div>
          <div style={{ fontSize: 14, color: "#6b7280" }}>Future Viability Index</div>
          {loading ? (
            <div style={{ marginTop: 6, color: "#6b7280" }}>Loading…</div>
          ) : target ? (
            <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginTop: 4 }}>
              <div style={{ fontSize: 32, fontWeight: 700 }}>
                {(target.fvi * 100).toFixed(1)}
                <span style={{ fontSize: 16, color: "#6b7280", marginLeft: 4 }}>/ 100</span>
              </div>
              <div style={{ color: "#6b7280" }}>
                {target.iso3} • {target.year}
              </div>
            </div>
          ) : err ? (
            <div style={{ marginTop: 6, color: "#b91c1c" }}>{err}</div>
          ) : (
            <div style={{ marginTop: 6, color: "#6b7280" }}>No data</div>
          )}
        </div>

        {/* Label pill */}
        <div>
          {target && (
            <span
              style={{
                display: "inline-block",
                padding: "6px 10px",
                borderRadius: 999,
                fontSize: 12,
                fontWeight: 600,
                background: LABELS[target.label].bg,
                color: LABELS[target.label].fg,
                border: `1px solid ${shade(LABELS[target.label].bg)}`,
              }}
            >
              {LABELS[target.label].text}
            </span>
          )}
        </div>
      </div>

      {/* Weights */}
      <section style={{ marginTop: 14 }}>
        <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 6 }}>Score Weights (α)</div>
        {alphaPairs.length === 0 ? (
          <div style={{ color: "#9ca3af", fontSize: 12 }}>Weights not set yet.</div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 60px", gap: 6 }}>
            {alphaPairs.map(([name, w]) => (
              <React.Fragment key={name}>
                <BarLabel label={name} value={w as number} />
                <div style={{ textAlign: "right", color: "#374151", fontVariantNumeric: "tabular-nums" }}>
                  {((w as number) * 100).toFixed(0)}%
                </div>
              </React.Fragment>
            ))}
          </div>
        )}
      </section>

      {/* Coverage */}
      <section style={{ marginTop: 14 }}>
        <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 6 }}>Data Coverage</div>
        {coveragePairs.length === 0 ? (
          <div style={{ color: "#9ca3af", fontSize: 12 }}>No coverage info.</div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 60px", gap: 6 }}>
            {coveragePairs.map(([name, pct]) => (
              <React.Fragment key={name}>
                <BarLabel label={name} value={(pct as number) / 100} barColor="#6366f1" />
                <div style={{ textAlign: "right", color: "#374151", fontVariantNumeric: "tabular-nums" }}>
                  {(pct as number).toFixed(0)}%
                </div>
              </React.Fragment>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function BarLabel({
  label,
  value,
  barColor = "#10b981",
}: {
  label: string;
  value: number; // 0..1
  barColor?: string;
}) {
  return (
    <div>
      <div style={{ fontSize: 12, color: "#374151", marginBottom: 4, textTransform: "capitalize" }}>{pretty(label)}</div>
      <div style={{ position: "relative", background: "#f3f4f6", border: "1px solid #e5e7eb", height: 8, borderRadius: 999 }}>
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            bottom: 0,
            width: `${Math.max(0, Math.min(100, value * 100))}%`,
            background: barColor,
            borderRadius: 999,
          }}
        />
      </div>
    </div>
  );
}

function pretty(s: string) {
  return s.replace(/[_\-]+/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
}

function shade(hex: string) {
  // crude border color from bg hex
  try {
    const h = hex.replace("#", "");
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    const f = (x: number) => Math.max(0, Math.min(255, Math.round(x * 0.85)));
    return `rgb(${f(r)}, ${f(g)}, ${f(b)})`;
  } catch {
    return "#e5e7eb";
  }
}

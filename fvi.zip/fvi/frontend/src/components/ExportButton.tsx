import React, { useState } from "react";
import { api } from "../api/client";
import { useScenarioStore } from "../state/scenario";

export default function ExportButton() {
  const { filters, alpha } = useScenarioStore();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const doExport = async (fmt: "csv" | "parquet") => {
    setBusy(true); setErr(null);
    try {
      const res = await api.exportScores({
        filters,
        alpha,
        format: fmt,
        filename: `fvi_${Date.now()}`,
      });
      const url = api.exportDownloadUrl(res.path);
      // Trigger download
      const a = document.createElement("a");
      a.href = url;
      a.download = res.filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (e: any) {
      setErr(e?.message || "Export failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
      <button
        onClick={() => void doExport("csv")}
        disabled={busy}
        style={btn}
        title="Export scores + FVI as CSV"
      >
        {busy ? "Exporting…" : "Export CSV"}
      </button>
      <button
        onClick={() => void doExport("parquet")}
        disabled={busy}
        style={btnSecondary}
        title="Export scores + FVI as Parquet"
      >
        {busy ? "Exporting…" : "Export Parquet"}
      </button>
      {err && <span style={{ color: "#b91c1c", fontSize: 12 }}>{err}</span>}
    </div>
  );
}

const btn: React.CSSProperties = {
  borderRadius: 8,
  border: "1px solid #10b981",
  background: "#10b981",
  color: "#fff",
  padding: "6px 10px",
  cursor: "pointer",
  fontSize: 13,
};

const btnSecondary: React.CSSProperties = {
  ...btn,
  border: "1px solid #374151",
  background: "#374151",
};

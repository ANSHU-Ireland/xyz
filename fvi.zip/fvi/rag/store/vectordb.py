# rag/store/vectordb.py
from __future__ import annotations

import json
import logging
import os
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import faiss  # type: ignore
import numpy as np

try:
    import google.generativeai as genai
except Exception as e:
    raise RuntimeError("google-generativeai is required. Install it and set GEMINI_API_KEY.") from e


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


@dataclass(frozen=True)
class VectorDBConfig:
    index_dir: Path
    embed_model: str = os.getenv("GEMINI_EMBED_MODEL", "text-embedding-004")
    api_key: str = os.getenv("GEMINI_API_KEY", "")
    batch_size: int = 64
    normalize: bool = True  # cosine similarity via normalized vectors

    @staticmethod
    def default() -> "VectorDBConfig":
        base = Path(__file__).resolve().parents[2]  # repo root
        idx = Path(os.getenv("INDEX_DIR", base / "runtime" / "indexes"))
        return VectorDBConfig(index_dir=idx)


class VectorDB:
    """
    FAISS + SQLite-backed vector store for RAG.
    - Vectors persisted at {index_dir}/faiss.index
    - Metadata persisted at {index_dir}/meta.db (SQLite, table 'docs')
    - Uses Gemini embeddings (text-embedding-004 by default)
    """

    def __init__(self, cfg: Optional[VectorDBConfig] = None):
        self.cfg = cfg or VectorDBConfig.default()
        if not self.cfg.api_key:
            raise RuntimeError("GEMINI_API_KEY not set; cannot initialize embeddings.")
        genai.configure(api_key=self.cfg.api_key)

        self.index_path = self.cfg.index_dir / "faiss.index"
        self.meta_path = self.cfg.index_dir / "meta.db"
        self.cfg.index_dir.mkdir(parents=True, exist_ok=True)

        self._dim: Optional[int] = None
        self._index: Optional[faiss.Index] = None
        self._idmap: Optional[faiss.IndexIDMap2] = None
        self._conn: Optional[sqlite3.Connection] = None

        self._open_or_init()

    # ---------- Public API ----------

    def add_texts(self, texts: Sequence[str], metadatas: Sequence[Dict[str, Any]]) -> List[int]:
        """
        Add documents to the store.
        Returns list of integer IDs assigned in FAISS.
        'metadatas' should include lightweight fields like:
          {"title": "...", "source": "path", "region": "IND", "year": 2024, ...}
        """
        if len(texts) != len(metadatas):
            raise ValueError("texts and metadatas must be the same length")

        if not texts:
            return []

        # Embed in batches
        embs = self._embed_batch(texts)
        if self.cfg.normalize:
            faiss.normalize_L2(embs)

        # Generate monotonically increasing ids
        start_id = self._next_doc_id()
        ids = np.arange(start_id, start_id + len(texts), dtype=np.int64)

        # Add to FAISS
        self._idmap.add_with_ids(embs, ids)  # type: ignore

        # Insert metadata
        self._insert_metadata(ids.tolist(), texts, metadatas)

        # Persist to disk
        self._persist()
        logger.info("Added %d docs. Total ntotal=%d", len(texts), self._idmap.ntotal)  # type: ignore
        return ids.tolist()

    def search(self, query: str, k: int = 6, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search the index and return top-k hits with metadata.
        Filters (optional): e.g., {"region": "IND"} or {"year": 2024} or {"year": [2018,2024]}
        Filter is applied on metadata post-retrieval with an oversampled pool.
        """
        if self._idmap.ntotal == 0:  # type: ignore
            return []

        q = self._embed_query(query)
        if self.cfg.normalize:
            faiss.normalize_L2(q)

        # Oversample to allow for filter pruning
        pool_k = min(max(k * 5, k), int(self._idmap.ntotal))  # type: ignore

        scores, ids = self._idmap.search(q, pool_k)  # type: ignore
        scores = scores[0].tolist()
        ids = ids[0].tolist()

        # Load metadata/texts
        rows = self._load_by_ids(ids)
        out: List[Dict[str, Any]] = []
        for sc, doc in zip(scores, rows):
            if filters and not _meta_passes(doc["meta"], filters):
                continue
            out.append(
                {
                    "id": int(doc["id"]),
                    "title": doc.get("title") or doc["meta"].get("title") or doc["meta"].get("source") or "doc",
                    "text": doc["text"],
                    "snippet": _make_snippet(doc["text"]),
                    "score": float(sc),
                    "meta": doc["meta"],
                }
            )
            if len(out) >= k:
                break
        return out

    def count(self) -> int:
        return int(self._idmap.ntotal)  # type: ignore

    # ---------- Lifecycle ----------

    def close(self) -> None:
        try:
            if self._conn:
                self._conn.commit()
                self._conn.close()
        finally:
            self._conn = None

    # ---------- Internals ----------

    def _open_or_init(self):
        # SQLite meta
        self._conn = sqlite3.connect(self.meta_path)
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS docs (
              id INTEGER PRIMARY KEY,
              text TEXT NOT NULL,
              title TEXT,
              meta TEXT NOT NULL
            )
            """
        )
        self._conn.commit()

        # FAISS index: use IndexFlatIP (+ normalization) for cosine
        if self.index_path.exists():
            self._idmap = faiss.read_index(str(self.index_path))  # type: ignore
            # Best-effort dimension inference: not always exposed directly
            try:
                self._dim = faiss.downcast_Index(self._idmap.index).d  # type: ignore
            except Exception:
                self._dim = None
            logger.info("Loaded FAISS index from %s (ntotal=%d)", self.index_path, self._idmap.ntotal)  # type: ignore
        else:
            # Defer dimension until first embedding is computed
            self._dim = None
            # Build a placeholder empty map; will be replaced once we know dim
            base = faiss.IndexFlatIP(1)
            self._idmap = faiss.IndexIDMap2(base)  # type: ignore

    def _ensure_index_dim(self, dim: int):
        if self._dim == dim and self._idmap is not None:
            return
        # Create a new IDMap with correct dimension; if current ntotal>0 and mismatch, it's an error
        if self._idmap and self._idmap.ntotal > 0 and self._dim and self._dim != dim:  # type: ignore
            raise RuntimeError(f"Embedding dimension changed from {self._dim} to {dim}; rebuild the index.")
        base = faiss.IndexFlatIP(dim)
        self._idmap = faiss.IndexIDMap2(base)  # type: ignore
        self._dim = dim

    def _persist(self):
        # Persist FAISS index
        assert self._idmap is not None
        faiss.write_index(self._idmap, str(self.index_path))  # type: ignore
        # SQLite commits happen on writes
        self._conn.commit()  # type: ignore

    def _embed_batch(self, texts: Sequence[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, self._dim or 1), dtype=np.float32)
        # Google embeddings API returns {"embedding": {"values": [...]}}
        model = self.cfg.embed_model
        out_vecs: List[List[float]] = []
        # Batch loop
        for i in range(0, len(texts), self.cfg.batch_size):
            chunk = list(texts[i : i + self.cfg.batch_size])
            resp = genai.embed_content(model=model, content=chunk)
            # Newer SDKs support batching; fall back to per-item if needed
            if isinstance(resp, dict) and "embedding" in resp:
                # Single item mode
                vec = resp["embedding"]["values"]
                out_vecs.append(vec)
            else:
                # Expected: {"embeddings":[{"values":[..]}, ...]}
                emb_list = resp.get("embeddings") or []
                for e in emb_list:
                    out_vecs.append(e["values"])
        arr = np.array(out_vecs, dtype=np.float32)
        if arr.ndim != 2:
            raise RuntimeError("Unexpected embedding output shape.")
        # Ensure FAISS index dimension
        self._ensure_index_dim(arr.shape[1])
        return arr

    def _embed_query(self, query: str) -> np.ndarray:
        model = self.cfg.embed_model
        resp = genai.embed_content(model=model, content=query)
        if isinstance(resp, dict) and "embedding" in resp:
            vec = np.array(resp["embedding"]["values"], dtype=np.float32)[None, :]
        else:
            # Newer SDK: {"embedding": {...}} or {"embeddings":[...]}
            emb_list = resp.get("embeddings") or []
            if not emb_list:
                raise RuntimeError("No embedding vector returned for query.")
            vec = np.array(emb_list[0]["values"], dtype=np.float32)[None, :]
        # Ensure index dim
        self._ensure_index_dim(vec.shape[1])
        return vec

    # ---- Metadata ----

    def _next_doc_id(self) -> int:
        cur = self._conn.execute("SELECT MAX(id) FROM docs")  # type: ignore
        row = cur.fetchone()
        start = int(row[0] or 0) + 1
        return start

    def _insert_metadata(self, ids: List[int], texts: Sequence[str], metas: Sequence[Dict[str, Any]]) -> None:
        rows = []
        for i, t, m in zip(ids, texts, metas):
            title = m.get("title") or m.get("source")
            rows.append((i, t, title, json.dumps(m, ensure_ascii=False, separators=(",", ":"))))
        self._conn.executemany("INSERT OR REPLACE INTO docs(id, text, title, meta) VALUES(?,?,?,?)", rows)  # type: ignore
        self._conn.commit()  # type: ignore

    def _load_by_ids(self, ids: List[int]) -> List[Dict[str, Any]]:
        if not ids:
            return []
        qmarks = ",".join("?" for _ in ids)
        cur = self._conn.execute(f"SELECT id, text, title, meta FROM docs WHERE id IN ({qmarks})", ids)  # type: ignore
        out: List[Dict[str, Any]] = []
        for row in cur.fetchall():
            meta = json.loads(row[3]) if row[3] else {}
            out.append({"id": int(row[0]), "text": row[1], "title": row[2], "meta": meta})
        # Maintain original order
        order = {v: i for i, v in enumerate(ids)}
        out.sort(key=lambda r: order.get(r["id"], 1e12))
        return out


# ---------- helpers ----------

def _meta_passes(meta: Dict[str, Any], filters: Dict[str, Any]) -> bool:
    for k, v in (filters or {}).items():
        mv = meta.get(k)
        if isinstance(v, (list, tuple)) and len(v) == 2 and all(isinstance(x, (int, float)) for x in v):
            lo, hi = v
            try:
                val = float(mv)
            except Exception:
                return False
            if not (lo <= val <= hi):
                return False
        else:
            if mv != v:
                return False
    return True


def _make_snippet(text: str, max_len: int = 400) -> str:
    t = " ".join(text.split())
    return t[: max_len - 1] + "…" if len(t) > max_len else t

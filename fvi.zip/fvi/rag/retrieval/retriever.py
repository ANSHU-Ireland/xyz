# rag/retrieval/retriever.py
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from rag.store.vectordb import VectorDB, VectorDBConfig

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

BASE_DIR = Path(__file__).resolve().parents[2]
RETRIEVAL_CFG = BASE_DIR / "config" / "retrieval.yaml"

_DEFAULTS = {
    "top_k": 6,
    "oversample": 5,        # handled inside VectorDB.search
    "filters": {},          # optional static filters
}


def _load_cfg() -> Dict[str, Any]:
    if RETRIEVAL_CFG.exists():
        try:
            with open(RETRIEVAL_CFG, "r", encoding="utf-8") as f:
                cfg = yaml.safe_load(f) or {}
            return {**_DEFAULTS, **cfg}
        except Exception as e:
            logger.warning("Failed to read retrieval.yaml: %s", e)
    return dict(_DEFAULTS)


# Public API used by services/rag_agent.py
def retrieve(query: str, k: int = 6, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """
    Retrieve top-k documents for the given query, applying optional metadata filters.
    Returns a list of dicts with: id, title, snippet, score, meta, text (full).
    """
    cfg = _load_cfg()
    top_k = k or int(cfg.get("top_k", 6))
    eff_filters = (cfg.get("filters") or {}) | (filters or {})

    # Initialize VectorDB (will raise if GEMINI_API_KEY missing)
    vdb = VectorDB(VectorDBConfig.default())

    if vdb.count() == 0:
        logger.info("Vector index is empty (runtime/indexes). Returning no RAG context.")
        return []

    docs = vdb.search(query=query, k=top_k, filters=eff_filters)
    # You could add a cross-encoder reranker here if needed.
    return docs

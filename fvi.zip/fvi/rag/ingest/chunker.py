# rag/ingest/chunker.py
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable, List


@dataclass(frozen=True)
class ChunkParams:
    target_chars: int = 1200   # aim for ~1–2k chars per chunk
    overlap_chars: int = 150   # overlap between consecutive chunks
    min_sentence_chars: int = 30  # avoid tiny fragments


_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9(])")


def normalize_whitespace(text: str) -> str:
    """Collapse excessive whitespace/newlines; keep paragraph breaks."""
    # Preserve double newlines as paragraph breaks; collapse others.
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Replace 3+ newlines with 2
    text = re.sub(r"\n{3,}", "\n\n", text)
    # Collapse runs of spaces/tabs
    text = re.sub(r"[ \t]{2,}", " ", text)
    # Strip trailing spaces on lines
    text = "\n".join(line.strip() for line in text.split("\n"))
    return text.strip()


def _split_sentences(text: str) -> List[str]:
    text = normalize_whitespace(text)
    # Fast path for short texts
    if len(text) <= 2000:
        return [text]
    parts = _SENTENCE_SPLIT_RE.split(text)
    # Re-join very short "sentences" to avoid fragments
    merged: List[str] = []
    buf = ""
    for s in parts:
        s = s.strip()
        if not s:
            continue
        if len(s) < 10 and buf:
            buf += " " + s
            continue
        if len(buf) + len(s) + 1 <= 400:  # small threshold to merge micro-sentences
            buf = (buf + " " + s).strip()
        else:
            if buf:
                merged.append(buf)
            buf = s
    if buf:
        merged.append(buf)
    return merged


def chunk_text(text: str, params: ChunkParams = ChunkParams()) -> List[str]:
    """
    Sentence-aware greedy chunking with controlled overlap.
    Returns a list of chunk strings.
    """
    sentences = _split_sentences(text)
    chunks: List[str] = []
    cur: List[str] = []
    cur_len = 0
    tgt = params.target_chars
    for s in sentences:
        s = s.strip()
        if not s:
            continue
        if cur_len + len(s) + 1 <= tgt or cur_len < params.min_sentence_chars:
            cur.append(s)
            cur_len += len(s) + 1
        else:
            # flush
            if cur:
                chunks.append(" ".join(cur).strip())
            # start new with overlap tail
            if chunks and params.overlap_chars > 0:
                tail = chunks[-1][-params.overlap_chars :]
                cur = [tail, s]
                cur_len = len(tail) + len(s) + 1
            else:
                cur = [s]
                cur_len = len(s)
    if cur:
        chunks.append(" ".join(cur).strip())

    # final cleanup of chunks
    out = [normalize_whitespace(c) for c in chunks if c and len(c.strip()) >= params.min_sentence_chars]
    return out

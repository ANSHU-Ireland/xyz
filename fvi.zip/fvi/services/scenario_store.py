# services/scenario_store.py
from __future__ import annotations

import json
import os
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple

from scoring.normalization import renorm_weights

BASE_DIR = Path(__file__).resolve().parents[1]
RUNTIME_DIR = Path(os.getenv("RUNTIME_DIR", BASE_DIR / "runtime"))
SCENARIO_PATH = RUNTIME_DIR / "scenarios.json"

Scope = Literal["score", "submetric"]


@dataclass
class Scenario:
    scenario_id: str
    persona: str = "regular_citizen"
    filters: Dict[str, Any] = field(default_factory=dict)  # {"regions":[...], "year": 2024 or [y0,y1]}
    alpha: Dict[str, float] = field(default_factory=dict)  # score weights
    sub_weights: Dict[str, Dict[str, float]] = field(default_factory=dict)  # score -> {submetric: weight}
    method: Dict[str, Any] = field(default_factory=lambda: {"aggregation": "weighted_mean", "normalization": "minmax"})
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    # Pending proposals: change_id -> payload
    pending: Dict[str, Dict[str, Any]] = field(default_factory=dict)


class ScenarioStore:
    """
    Thread-safe scenario storage with JSON persistence under ./runtime/scenarios.json.
    - Scenarios persist across app restarts.
    - Weight updates are renormalized and validated.
    - Proposals are stored as pending diffs until committed.
    """

    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else SCENARIO_PATH
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._scenarios: Dict[str, Scenario] = {}
        self._load()

    # ---------------- CRUD ----------------

    def create(self, persona: str, filters: Dict[str, Any], alpha: Dict[str, float], sub_weights: Dict[str, Dict[str, float]], method: Dict[str, Any]) -> Scenario:
        sid = str(uuid.uuid4())
        alpha_norm = renorm_weights(_to_series(alpha)).to_dict()
        sub_norm = {s: renorm_weights(_to_series(w)).to_dict() for s, w in (sub_weights or {}).items()}
        sc = Scenario(scenario_id=sid, persona=persona or "regular_citizen", filters=filters or {}, alpha=alpha_norm, sub_weights=sub_norm, method=method or {"aggregation": "weighted_mean", "normalization": "minmax"})
        with self._lock:
            self._scenarios[sid] = sc
            self._save()
        return sc

    def get(self, scenario_id: str) -> Optional[Scenario]:
        with self._lock:
            return self._scenarios.get(scenario_id)

    def update(self, scenario_id: str, *, persona: Optional[str] = None, filters: Optional[Dict[str, Any]] = None, alpha: Optional[Dict[str, float]] = None, sub_weights: Optional[Dict[str, Dict[str, float]]] = None, method: Optional[Dict[str, Any]] = None) -> Scenario:
        with self._lock:
            sc = self._require(scenario_id)
            if persona:
                sc.persona = persona
            if filters is not None:
                sc.filters = filters
            if alpha is not None:
                sc.alpha = renorm_weights(_to_series(alpha)).to_dict()
            if sub_weights is not None:
                sc.sub_weights = {s: renorm_weights(_to_series(w)).to_dict() for s, w in sub_weights.items()}
            if method is not None:
                sc.method = method
            sc.updated_at = time.time()
            self._save()
            return sc

    def delete(self, scenario_id: str) -> None:
        with self._lock:
            if scenario_id in self._scenarios:
                del self._scenarios[scenario_id]
                self._save()

    # ------------- Propose / Commit weights -------------

    def propose_weight_update(self, scenario_id: str, scope: Scope, targets: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        scope = "score" or "submetric"
        targets for score scope: [{"id": "<score_name>", "target_weight": 0.2, "rationale": "..."}]
        targets for submetric scope: [{"id": "<score_name>.<submetric_id>", "target_weight": 0.3, "rationale": "..."}]
        Returns a proposal with normalized new vectors and a change_id.
        """
        with self._lock:
            sc = self._require(scenario_id)

            if scope == "score":
                cur = _to_series(sc.alpha)
                updates = {t["id"]: float(t["target_weight"]) for t in targets}
                proposed = cur.copy()
                for k, v in updates.items():
                    proposed.loc[k] = _clip01(v)
                proposed = renorm_weights(proposed)
                diff = _diff_vector(cur, proposed)
                preview = {"alpha_new": proposed.to_dict(), "alpha_diff": diff, "sub_weights_new": None}
            elif scope == "submetric":
                # targets refer to "<score>.<sub>"
                groups: Dict[str, Dict[str, float]] = {}
                for t in targets:
                    sid = t["id"]
                    if "." not in sid:
                        raise ValueError(f"submetric scope requires id format '<score>.<submetric>', got {sid}")
                    score, sub = sid.split(".", 1)
                    groups.setdefault(score, {})
                    groups[score][sub] = _clip01(float(t["target_weight"]))

                new_sw: Dict[str, Dict[str, float]] = {}
                diff_sw: Dict[str, Dict[str, float]] = {}
                for score, ups in groups.items():
                    curw = _to_series(sc.sub_weights.get(score, {}))
                    prop = curw.copy()
                    for sub, w in ups.items():
                        prop.loc[sub] = w
                    prop = renorm_weights(prop) if len(prop) else prop
                    new_sw[score] = prop.to_dict()
                    diff_sw[score] = _diff_vector(curw, prop)
                preview = {"alpha_new": None, "alpha_diff": None, "sub_weights_new": new_sw, "sub_weights_diff": diff_sw}
            else:
                raise ValueError(f"Unknown scope: {scope}")

            change_id = str(uuid.uuid4())
            sc.pending[change_id] = {"scope": scope, "targets": targets, "preview": preview, "created_at": time.time()}
            sc.updated_at = time.time()
            self._save()
            return {"change_id": change_id, "preview": preview, "scope": scope}

    def commit_weight_update(self, scenario_id: str, change_id: str) -> Scenario:
        with self._lock:
            sc = self._require(scenario_id)
            prop = sc.pending.get(change_id)
            if not prop:
                raise KeyError(f"change_id not found: {change_id}")
            prev = prop["preview"]
            if prev.get("alpha_new"):
                sc.alpha = dict(prev["alpha_new"])
            if prev.get("sub_weights_new"):
                sc.sub_weights = dict(prev["sub_weights_new"])
            sc.updated_at = time.time()
            del sc.pending[change_id]
            self._save()
            return sc

    # ---------------- Internals ----------------

    def _require(self, sid: str) -> Scenario:
        sc = self._scenarios.get(sid)
        if not sc:
            raise KeyError(f"scenario not found: {sid}")
        return sc

    def _load(self) -> None:
        if not self.path.exists():
            self._scenarios = {}
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            self._scenarios = {k: Scenario(**v) for k, v in raw.items()}
        except Exception:
            # Corrupt file: backup and reset
            backup = self.path.with_suffix(".bak")
            try:
                self.path.replace(backup)
            except Exception:
                pass
            self._scenarios = {}

    def _save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        data = {k: asdict(v) for k, v in self._scenarios.items()}
        tmp.write_text(json.dumps(data, separators=(",", ":"), ensure_ascii=False), encoding="utf-8")
        tmp.replace(self.path)


# ---------------- Utilities ----------------

def _to_series(d: Dict[str, float]) -> "pd.Series":
    import pandas as pd
    return pd.Series(d, dtype=float)

def _clip01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))

def _diff_vector(a: "pd.Series", b: "pd.Series") -> Dict[str, float]:
    a = a.reindex(b.index).fillna(0.0)
    d = (b - a).to_dict()
    # round small noise
    return {k: float(v) if abs(float(v)) >= 1e-12 else 0.0 for k, v in d.items()}

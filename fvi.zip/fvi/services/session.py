# services/session.py
from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

__all__ = ["SessionStore", "get_session_store"]


class SessionStore:
    """
    Minimal interface for ephemeral per-session state:
      - get(session_id) -> dict | None
      - set(session_id, state: dict) -> None
      - delete(session_id) -> None
      - purge() -> None
    """

    def get(self, session_id: str) -> Optional[Dict[str, Any]]:  # pragma: no cover - interface
        raise NotImplementedError

    def set(self, session_id: str, state: Dict[str, Any]) -> None:  # pragma: no cover
        raise NotImplementedError

    def delete(self, session_id: str) -> None:  # pragma: no cover
        raise NotImplementedError

    def purge(self) -> None:  # pragma: no cover
        pass


# ---------------- In-memory TTL store ----------------

@dataclass
class _Entry:
    state: Dict[str, Any]
    expires_at: float


class InMemorySessionStore(SessionStore):
    """
    Thread-safe, process-local session store with TTL and capacity limit.
    Suitable for single-process deployments; use Redis for multi-instance.
    """

    def __init__(self, ttl_seconds: int = 7200, capacity: int = 5000):
        self.ttl = float(ttl_seconds)
        self.capacity = int(capacity)
        self._lock = threading.Lock()
        self._map: Dict[str, _Entry] = {}

    def get(self, session_id: str) -> Optional[Dict[str, Any]]:
        now = time.time()
        with self._lock:
            ent = self._map.get(session_id)
            if not ent:
                return None
            if ent.expires_at < now:
                self._map.pop(session_id, None)
                return None
            return ent.state

    def set(self, session_id: str, state: Dict[str, Any]) -> None:
        exp = time.time() + self.ttl
        with self._lock:
            self._map[session_id] = _Entry(state=state, expires_at=exp)
            # Simple capacity control: purge oldest expired first, else random pop
            if len(self._map) > self.capacity:
                self.purge()
                if len(self._map) > self.capacity:
                    # If still over capacity, drop the earliest expiring entry
                    oldest_sid = min(self._map.items(), key=lambda kv: kv[1].expires_at)[0]
                    self._map.pop(oldest_sid, None)

    def delete(self, session_id: str) -> None:
        with self._lock:
            self._map.pop(session_id, None)

    def purge(self) -> None:
        now = time.time()
        with self._lock:
            for sid in list(self._map.keys()):
                if self._map[sid].expires_at < now:
                    self._map.pop(sid, None)


# ---------------- Redis-backed store ----------------

class RedisSessionStore(SessionStore):
    """
    Redis-backed session store; requires REDIS_URL or UPSTASH_REDIS_REST_URL.
    Values are stored as JSON strings under key prefix.
    """

    def __init__(self, url: str, ttl_seconds: int = 7200, prefix: str = "fvi:session:"):
        try:
            import redis  # type: ignore
        except Exception as e:
            raise RuntimeError("redis-py is required for RedisSessionStore. Install `redis`.") from e

        self.r = redis.from_url(url, decode_responses=True)
        # Validate connection early
        self.r.ping()
        self.ttl = int(ttl_seconds)
        self.prefix = prefix

    def _k(self, sid: str) -> str:
        return f"{self.prefix}{sid}"

    def get(self, session_id: str) -> Optional[Dict[str, Any]]:
        raw = self.r.get(self._k(session_id))
        if not raw:
            return None
        try:
            return json.loads(raw)
        except Exception:
            return None

    def set(self, session_id: str, state: Dict[str, Any]) -> None:
        self.r.set(self._k(session_id), json.dumps(state, ensure_ascii=False, separators=(",", ":")), ex=self.ttl)

    def delete(self, session_id: str) -> None:
        self.r.delete(self._k(session_id))

    def purge(self) -> None:
        # TTL expiry handled by Redis; no-op.
        return


# ---------------- Factory ----------------

_singleton: Optional[SessionStore] = None

def get_session_store(ttl_seconds: int = 7200) -> SessionStore:
    """
    Returns a singleton SessionStore.
    - If REDIS_URL / UPSTASH_REDIS_REST_URL is set, uses RedisSessionStore.
    - Else uses InMemorySessionStore.
    """
    global _singleton
    if _singleton is not None:
        return _singleton

    url = os.getenv("REDIS_URL") or os.getenv("UPSTASH_REDIS_REST_URL")
    if url:
        try:
            _singleton = RedisSessionStore(url=url, ttl_seconds=ttl_seconds)
            return _singleton
        except Exception as e:
            # Fall back to in-memory if Redis is unavailable
            import logging
            logging.getLogger(__name__).warning("Redis unavailable (%s); falling back to in-memory session store.", e)

    cap = int(os.getenv("SESSION_CAPACITY", "5000"))
    _singleton = InMemorySessionStore(ttl_seconds=ttl_seconds, capacity=cap)
    return _singleton

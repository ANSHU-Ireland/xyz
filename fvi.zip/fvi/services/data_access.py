# services/data_access.py
from __future__ import annotations

import logging
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

import numpy as np
import pandas as pd

from scoring.compute_scores import DataProvider

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

BASE_DIR = Path(__file__).resolve().parents[1]
STATIC_DIR = BASE_DIR / "data" / "static"

# Heuristics to find ISO3 and year columns across diverse files
ISO3_CANDIDATES = [
    "iso3", "iso3_code", "iso", "country_iso3", "reporteriso", "reporter_iso",
    "country_code", "iso_3", "iso_3_code"
]
YEAR_CANDIDATES = ["year", "refyear", "ref_year", "refperiodid", "ref_period_id"]

# Optional alternative column name canonicalization map
CANON_MAP = {
    "reporteriso": "iso3",
    "reporter_iso": "iso3",
    "iso3_code": "iso3",
    "refyear": "year",
    "ref_year": "year",
    "refperiodid": "year",
    "ref_period_id": "year",
}


class DataAccess(DataProvider):
    """
    DataProvider implementation that reads static CSV/XLSX files from data/static/**,
    performs light canonicalization, and returns submetric series aligned to (iso3, year).
    Designed for country-level analysis.
    """

    def __init__(self, root: Optional[Path] = None) -> None:
        self.root = Path(root) if root else STATIC_DIR
        if not self.root.exists():
            raise FileNotFoundError(f"Static data directory not found: {self.root}")

    # --------- Public API (required by ScoreEngine) ---------

    def submetric_series(
        self,
        score_name: str,
        submetric_id: str,
        cfg: Mapping[str, Any],
        filters: Mapping[str, Any],
    ) -> pd.Series:
        """
        Return a numeric Series indexed by MultiIndex (iso3, year).
        cfg fields used: source (relative file key or folder), column (optional), transform (optional).
        """
        source_key = cfg.get("source")
        if not source_key:
            raise ValueError(f"Submetric '{submetric_id}' under score '{score_name}' lacks 'source' in config.")

        df = self._load_source(source_key)

        # Canonicalize column names
        df.columns = [CANON_MAP.get(c.lower(), c.lower()) for c in df.columns]

        iso_col = self._detect_iso3(df)
        year_col = self._detect_year(df)

        if iso_col is None or year_col is None:
            raise ValueError(
                f"Cannot detect iso3/year columns in source '{source_key}'. "
                f"Found columns: {list(df.columns)[:20]}"
            )

        # Apply optional transform or use column
        series = self._compute_series(df, iso_col, year_col, cfg)

        # Filters: regions and year
        if "regions" in (filters or {}):
            regions = set(filters["regions"])
            series = series[series.index.get_level_values(0).isin(regions)]
        if "year" in (filters or {}):
            yr = filters["year"]
            if isinstance(yr, (list, tuple)) and len(yr) == 2:
                lo, hi = int(yr[0]), int(yr[1])
                series = series[(series.index.get_level_values(1) >= lo) & (series.index.get_level_values(1) <= hi)]
            else:
                series = series[series.index.get_level_values(1) == int(yr)]

        # Ensure float dtype
        series = series.astype(float)
        series.name = submetric_id
        return series

    # --------- Internals ---------

    def _compute_series(
        self,
        df: pd.DataFrame,
        iso_col: str,
        year_col: str,
        cfg: Mapping[str, Any],
    ) -> pd.Series:
        """
        Compute final series given transform or column. Aggregates to (iso3, year) with mean by default.
        """
        if "transform" in cfg and cfg["transform"]:
            # Safe expression evaluator on DataFrame columns
            s = _eval_expression_rowwise(df, cfg["transform"])
        else:
            col = cfg.get("column")
            if not col:
                raise ValueError(f"No 'column' or 'transform' provided in submetric cfg: {cfg}")
            col = col.lower()
            if col not in df.columns:
                # Try softer match (remove non-word)
                alt = _soft_find(col, df.columns)
                if alt is None:
                    raise ValueError(f"Column '{col}' not found in source; available: {list(df.columns)[:20]}")
                col = alt
            s = df[col]

        out = pd.DataFrame({
            "iso3": df[iso_col].astype(str).str.upper(),
            "year": df[year_col].astype(int),
            "_val": pd.to_numeric(s, errors="coerce"),
        })

        # Aggregate duplicates at (iso3, year)
        grouped = out.groupby(["iso3", "year"], as_index=True)["_val"].mean()
        grouped.index = pd.MultiIndex.from_tuples(grouped.index, names=["iso3", "year"])
        return grouped.sort_index()

    @staticmethod
    def _detect_iso3(df: pd.DataFrame) -> Optional[str]:
        for c in df.columns:
            lc = c.lower()
            if lc in ISO3_CANDIDATES:
                return lc
        # try soft
        alt = _soft_find("iso3", df.columns)
        return alt

    @staticmethod
    def _detect_year(df: pd.DataFrame) -> Optional[str]:
        for c in df.columns:
            lc = c.lower()
            if lc in YEAR_CANDIDATES:
                return lc
        # Common cases: "refyear" inside mixed strings or "year" tail
        for c in df.columns:
            if re.search(r"year", c.lower()):
                return c
        return None

    @lru_cache(maxsize=128)
    def _load_source(self, source_key: str) -> pd.DataFrame:
        """
        Load a dataset identified by `source_key`. We support:
         - A file stem under the score directory (e.g., 'annual-co2-emission')
         - A relative path under data/static (e.g., 'emissions/annual-co2-emission.csv')
        """
        # Normalize
        key = source_key.strip().lstrip("/")

        # Direct relative path
        candidate = self.root / key
        if candidate.is_file():
            return _read_tabular(candidate)

        # Try with CSV/XLSX suffixes
        for ext in (".csv", ".xlsx", ".xls", ".parquet"):
            p = (self.root / key).with_suffix(ext)
            if p.is_file():
                return _read_tabular(p)

        # Try under immediate score folder inferred from key first token
        parts = key.split("/")
        if len(parts) == 1:
            # Search subfolders for a matching stem
            for sub in self.root.iterdir():
                if not sub.is_dir():
                    continue
                p = sub / f"{key}.csv"
                if p.is_file():
                    return _read_tabular(p)
                # try xlsx
                for ext in (".xlsx", ".xls"):
                    p = sub / f"{key}{ext}"
                    if p.is_file():
                        return _read_tabular(p)

        raise FileNotFoundError(f"Could not resolve source '{source_key}' under {self.root}")


# ---------- helpers ----------

def _soft_find(target: str, columns: list[str] | pd.Index) -> Optional[str]:
    """
    Fuzzy-ish lookup for a column name: case-insensitive, remove non-word characters.
    """
    norm_t = re.sub(r"\W+", "", target.lower())
    for c in columns:
        if re.sub(r"\W+", "", str(c).lower()) == norm_t:
            return c
    return None


def _read_tabular(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(path)
    elif suffix in (".xlsx", ".xls"):
        # Prefer first sheet by default
        df = pd.read_excel(path, engine="openpyxl" if suffix == ".xlsx" else None)
    elif suffix == ".parquet":
        df = pd.read_parquet(path)
    else:
        raise ValueError(f"Unsupported file type: {path.suffix}")
    logger.info("Loaded %s rows from %s", len(df), path.relative_to(BASE_DIR))
    return df


SAFE_FUNCS = {
    "min": np.minimum,
    "max": np.maximum,
    "log": np.log,
    "log1p": np.log1p,
    "exp": np.exp,
    "sqrt": np.sqrt,
    "abs": np.abs,
    "where": np.where,
    "clip": np.clip,
}

def _eval_expression_rowwise(df: pd.DataFrame, expr: str) -> pd.Series:
    """
    Safely evaluate a numeric expression against columns of df using pandas eval with a restricted env.
    Example transform: "value / country_area_km2"
    """
    # Build env with columns
    env: Dict[str, Any] = {c: pd.to_numeric(df[c], errors="coerce") for c in df.columns}
    env.update(SAFE_FUNCS)
    try:
        out = pd.eval(expr, local_dict=env, engine="python")
    except Exception as e:
        raise ValueError(f"Failed to evaluate transform '{expr}': {e}") from e
    return pd.to_numeric(out, errors="coerce")

# services/rag_agent.py
from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import google.generativeai as genai  # pip install google-generativeai

from rag.retrieval.retriever import retrieve
from services.session import get_session_store
from api.routers.scores import get_scores_for_agent, get_explanation_for_agent
from api.routers.classify import classify_for_agent

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# ---- Configuration ----
# Default to Flash; allow overriding to the exact Flash 2.0 variant via env.
MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
MAX_RAG_DOCS = int(os.getenv("RAG_TOP_K", "6"))
MAX_CONTEXT_CHARS = int(os.getenv("RAG_CONTEXT_CHARS", "12000"))
SESSION_TTL_SEC = int(os.getenv("CHAT_SESSION_TTL_SEC", "7200"))  # 2h session retention


@dataclass
class AgentRequest:
    session_id: str
    message: str
    persona: str = "regular_citizen"
    scenario_id: Optional[str] = None
    filters: Optional[Dict[str, Any]] = None


@dataclass
class AgentResponse:
    text: str
    citations: List[Dict[str, Any]]
    tool_calls: List[Dict[str, Any]]
    tool_results: List[Dict[str, Any]]
    state: Dict[str, Any]


def _init_gemini():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not set.")
    genai.configure(api_key=api_key)
    # You can add safety settings here if needed
    return genai.GenerativeModel(
        model_name=MODEL_NAME,
        system_instruction=_read_system_instruction(),
    )


def _read_system_instruction() -> str:
    from pathlib import Path
    base = Path(__file__).resolve().parents[1]
    path = base / "config" / "agent" / "system_prompt.md"
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        # Minimal fallback
        return (
            "You are the FVI (Future Viability Index) assistant. "
            "Use provided tool results and RAG context. "
            "FVI and all component scores are 0–1 (0..100 in UI). Higher = more viable. "
            "Classes: sustainable, critical_transition_needed, decommission."
        )


def _summarize_docs(docs: List[Dict[str, Any]], max_chars: int) -> Tuple[str, List[Dict[str, Any]]]:
    """Build a bounded-length concatenation of retrieved docs + citation metadata."""
    if not docs:
        return "", []
    combined: List[str] = []
    citations: List[Dict[str, Any]] = []
    chars = 0
    for i, d in enumerate(docs, start=1):
        snippet = d.get("snippet") or (d.get("text") or "")[:400]
        block = (
            f"[DOC {i}] title: {d.get('title','doc')}\n"
            f"source: {d.get('meta',{}).get('source','unknown')}\n"
            f"{snippet}\n"
        )
        if chars + len(block) > max_chars:
            break
        combined.append(block)
        citations.append(
            {
                "id": d.get("id"),
                "title": d.get("title"),
                "score": d.get("score"),
                "meta": d.get("meta"),
            }
        )
        chars += len(block)
    return "\n".join(combined), citations


def _maybe_detect_country(query: str) -> Optional[str]:
    """
    Lightweight ISO3 detection from queries like 'India', 'USA', 'IN', 'CHN', etc.
    Prefer explicit ISO3 (A-Z length 3).
    """
    # Explicit ISO3 token
    m = re.search(r"\b([A-Z]{3})\b", query.upper())
    if m:
        return m.group(1)
    # Simple country name hints (extend if you need more)
    name_to_iso = {
        "INDIA": "IND", "CHINA": "CHN", "UNITED STATES": "USA", "USA": "USA", "U.S.": "USA",
        "GERMANY": "DEU", "FRANCE": "FRA", "JAPAN": "JPN", "AUSTRALIA": "AUS", "SOUTH AFRICA": "ZAF",
        "RUSSIA": "RUS", "CANADA": "CAN", "INDONESIA": "IDN", "VIETNAM": "VNM", "POLAND": "POL",
    }
    q = query.upper()
    for k, v in name_to_iso.items():
        if k in q:
            return v
    return None


def _tool_scores(filters: Dict[str, Any]) -> Dict[str, Any]:
    return get_scores_for_agent({"filters": filters})


def _tool_explain(filters: Dict[str, Any]) -> Dict[str, Any]:
    return get_explanation_for_agent({"filters": filters})


def _tool_classify(filters: Dict[str, Any]) -> Dict[str, Any]:
    return classify_for_agent({"filters": filters})


def chat(req: AgentRequest) -> AgentResponse:
    """
    Main agent entrypoint:
    - Retrieves RAG context (config + dataset summaries).
    - Calls scores/explain/classify tools for the current filters.
    - Composes a structured prompt for Gemini (Flash).
    - Maintains ephemeral per-session message memories in a TTL store.
    """
    # 1) Session state (ephemeral)
    store = get_session_store(ttl_seconds=SESSION_TTL_SEC)
    state = store.get(req.session_id) or {"history": []}

    # 2) Derive filters (prefer explicit filters; else infer ISO3 from the message)
    filters = dict(req.filters or {})
    if not filters.get("regions"):
        iso3 = _maybe_detect_country(req.message)
        if iso3:
            filters["regions"] = [iso3]

    # 3) Fetch tool data
    tool_calls: List[Dict[str, Any]] = []
    tool_results: List[Dict[str, Any]] = []

    # Scores
    tool_calls.append({"tool": "get_scores", "args": {"filters": filters}})
    scores_payload = _tool_scores(filters)
    tool_results.append({
        "tool": "get_scores",
        "result": {
            "coverage": scores_payload.get("coverage"),
            "meta": scores_payload.get("meta"),
            "sample": (scores_payload.get("fvi") or [])[:5],
        },
    })

    # Explain (contributions for a single target (iso3,year))
    tool_calls.append({"tool": "get_explanation", "args": {"filters": filters}})
    explain_payload = _tool_explain(filters)
    tool_results.append({
        "tool": "get_explanation",
        "result": {
            "region": explain_payload.get("region"),
            "year": explain_payload.get("year"),
            "fvi": explain_payload.get("fvi"),
        },
    })

    # Classify (first point)
    tool_calls.append({"tool": "classify", "args": {"filters": filters}})
    classify_payload = _tool_classify(filters)
    tool_results.append({"tool": "classify", "result": classify_payload})

    # 4) Retrieve RAG context
    docs = retrieve(query=req.message, k=MAX_RAG_DOCS, filters=None)
    rag_text, citations = _summarize_docs(docs, max_chars=MAX_CONTEXT_CHARS)

    # 5) Build prompt (tools first; RAG for narrative context only)
    prompt = f"""
# USER ASK
{req.message}

# FILTERS IN EFFECT
{filters}

# SCORES (STRUCTURED)
{scores_payload}

# EXPLANATION (ONE REGION/YEAR)
{explain_payload}

# CLASSIFICATION
{classify_payload}

# RAG CONTEXT (EXTERNAL DOC EXCERPTS)
{rag_text}

# INSTRUCTIONS
Answer succinctly and quantitatively:
- Use the score/explanation/classification data above as ground truth for numbers.
- If filters include a single ISO3 and year, center your answer on that; otherwise summarize latest-year highlights and top/bottom countries where possible.
- Explain which submetrics and weights (α and within-score) are most influential for this case.
- Provide class label probabilities if available.
- If data coverage is low, say so explicitly and advise the user to adjust filters or weights.
- FVI and component scores are 0..1 (displayed as /100). Higher = more viable.
- Classes: sustainable, critical_transition_needed, decommission.
"""

    # 6) Call Gemini
    model = _init_gemini()
    history_for_model = [
        {"role": "user", "parts": h["user"]} if "user" in h else {"role": "model", "parts": h["assistant"]}
        for h in (state.get("history") or [])[-6:]
    ]
    try:
        resp = model.generate_content(
            contents=history_for_model + [{"role": "user", "parts": prompt}],
            generation_config={"temperature": 0.2, "top_p": 0.9, "max_output_tokens": 1024},
        )
        text = resp.text or "(no response)"
    except Exception as e:
        logger.exception("Gemini call failed")
        text = f"Sorry—model error. ({e})"

    # 7) Update session (ephemeral)
    hist = state.get("history", [])
    hist.append({"user": req.message})
    hist.append({"assistant": text})
    state["history"] = hist[-20:]  # cap memory
    store.set(req.session_id, state)

    return AgentResponse(
        text=text,
        citations=citations,
        tool_calls=tool_calls,
        tool_results=tool_results,
        state={"filters": filters, "session_messages": len(state.get("history", []))},
    )

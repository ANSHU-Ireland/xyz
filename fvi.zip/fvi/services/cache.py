# services/cache.py
from __future__ import annotations

import json
import os
import time
import hashlib
import logging
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Optional, Tuple

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# ---------- Key building ----------

def scenario_hash(payload: dict) -> str:
    """
    Stable short hash for caching: sorts keys and dumps JSON.
    payload can include filters, alpha, submetric_weights, normalization_overrides, etc.
    """
    try:
        data = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    except Exception:
        # Last resort: str()
        data = str(payload)
    return hashlib.sha256(data.encode("utf-8")).hexdigest()[:16]


# ---------- Cache interface ----------

class CacheStore:
    def get(self, key: str) -> Optional[Any]:  # pragma: no cover - interface
        raise NotImplementedError

    def set(self, key: str, value: Any, ttl_seconds: Optional[int] = None) -> None:  # pragma: no cover
        raise NotImplementedError

    def delete(self, key: str) -> None:  # pragma: no cover
        raise NotImplementedError

    def purge(self) -> None:  # pragma: no cover
        pass


# ---------- In-memory TTL LRU cache ----------

@dataclass
class _Entry:
    value: Any
    expires_at: float


class InMemoryTTLCache(CacheStore):
    """
    Process-local TTL LRU cache.
    - capacity: max number of entries (evicts LRU)
    - ttl_seconds: default TTL for entries
    """
    def __init__(self, capacity: int = 512, ttl_seconds: int = 300):
        self.capacity = capacity
        self.default_ttl = ttl_seconds
        self._map: OrderedDict[str, _Entry] = OrderedDict()

    def get(self, key: str) -> Optional[Any]:
        ent = self._map.get(key)
        if not ent:
            return None
        if ent.expires_at and time.time() > ent.expires_at:
            self._map.pop(key, None)
            return None
        # move to end (recent)
        self._map.move_to_end(key)
        return ent.value

    def set(self, key: str, value: Any, ttl_seconds: Optional[int] = None) -> None:
        exp = time.time() + float(ttl_seconds or self.default_ttl)
        self._map[key] = _Entry(value=value, expires_at=exp)
        self._map.move_to_end(key)
        # evict LRU
        while len(self._map) > self.capacity:
            self._map.popitem(last=False)

    def delete(self, key: str) -> None:
        self._map.pop(key, None)

    def purge(self) -> None:
        now = time.time()
        for k in list(self._map.keys()):
            if self._map[k].expires_at < now:
                self._map.pop(k, None)


# ---------- Redis cache ----------

class RedisCache(CacheStore):
    def __init__(self, url: str, prefix: str = "fvi:cache:", default_ttl: int = 300):
        try:
            import redis  # type: ignore
        except Exception as e:  # pragma: no cover
            raise RuntimeError("redis-py is required for RedisCache. Install `redis`.") from e
        self.r = redis.from_url(url, decode_responses=True)
        try:
            self.r.ping()
        except Exception as e:
            raise RuntimeError(f"Cannot connect to Redis at {url}: {e}") from e
        self.prefix = prefix
        self.default_ttl = int(default_ttl)

    def _k(self, key: str) -> str:
        return f"{self.prefix}{key}"

    def get(self, key: str) -> Optional[Any]:
        raw = self.r.get(self._k(key))
        if not raw:
            return None
        try:
            return json.loads(raw)
        except Exception:
            return None

    def set(self, key: str, value: Any, ttl_seconds: Optional[int] = None) -> None:
        ttl = int(ttl_seconds or self.default_ttl)
        self.r.set(self._k(key), json.dumps(value, separators=(",", ":"), ensure_ascii=False), ex=ttl)

    def delete(self, key: str) -> None:
        self.r.delete(self._k(key))

    def purge(self) -> None:
        # Redis handles TTL expiry; no-op.
        return


# ---------- Factory ----------

def get_cache() -> CacheStore:
    """
    Returns a cache instance based on REDIS_URL, else in-memory LRU.
    """
    url = os.getenv("REDIS_URL") or os.getenv("UPSTASH_REDIS_REST_URL")
    ttl = int(os.getenv("CACHE_TTL_SEC", "300"))
    if url:
        try:
            cache = RedisCache(url, default_ttl=ttl)
            logger.info("Using RedisCache at %s", url)
            return cache
        except Exception as e:
            logger.warning("Redis unavailable (%s); falling back to InMemoryTTLCache", e)
    cap = int(os.getenv("CACHE_CAPACITY", "512"))
    logger.info("Using InMemoryTTLCache (capacity=%d, ttl=%ds)", cap, ttl)
    return InMemoryTTLCache(capacity=cap, ttl_seconds=ttl)

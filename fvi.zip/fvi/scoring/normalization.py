# scoring/normalization.py
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal, Optional

import numpy as np
import pandas as pd


Direction = Literal["higher_is_better", "lower_is_better"]
NormMethod = Literal["minmax", "robust_minmax", "zscore"]


@dataclass(frozen=True)
class NormConfig:
    method: NormMethod = "minmax"
    hard_min: Optional[float] = None
    hard_max: Optional[float] = None
    p_low: float = 0.01      # for robust_minmax (1st percentile)
    p_high: float = 0.99     # for robust_minmax (99th percentile)
    clip: bool = True        # clip after scaling to [0,1] for minmax/robust; [-3,3] for zscore


def _orient(values: pd.Series, direction: Direction) -> pd.Series:
    """
    Ensure 'higher = more viable' orientation.
    If the raw metric is 'lower_is_better', flip it by multiplying by -1 before normalization
    or, for scaled 0..1 values, by (1 - x). Here we simply flip sign pre-normalization.
    """
    if direction == "lower_is_better":
        return -values
    return values


def _minmax(series: pd.Series, mn: float, mx: float) -> pd.Series:
    denom = (mx - mn)
    if denom == 0 or not np.isfinite(denom):
        return pd.Series(0.5, index=series.index)  # all equal → neutral mid
    return (series - mn) / denom


def _robust_bounds(series: pd.Series, p_low: float, p_high: float) -> tuple[float, float]:
    lo, hi = np.nanpercentile(series.values.astype(float), [p_low * 100, p_high * 100])
    if not np.isfinite(hi - lo) or (hi - lo) == 0:
        return float(series.min()), float(series.max())
    return float(lo), float(hi)


def normalize_series(
    series: pd.Series,
    direction: Direction = "higher_is_better",
    cfg: Optional[NormConfig] = None,
) -> pd.Series:
    """
    Normalize a numeric series to 0..1 scale (interpretable as 'higher = more viable').
    - If direction == 'lower_is_better', the series is sign-flipped before scaling.
    - Methods:
        * minmax: uses either hard_min/max if provided, else data min/max.
        * robust_minmax: uses robust percentiles (p_low, p_high) for bounds.
        * zscore: returns a logistic-rescaled z-score to (0,1) with center at 0.
    """
    cfg = cfg or NormConfig()
    s = _orient(series.astype(float), direction).copy()

    # Drop all-NaN short circuit
    if s.dropna().empty:
        return pd.Series(np.nan, index=series.index)

    if cfg.method == "zscore":
        mu = float(np.nanmean(s.values))
        sd = float(np.nanstd(s.values))
        if not np.isfinite(sd) or sd == 0:
            z = pd.Series(0.0, index=s.index)
        else:
            z = (s - mu) / sd
        if cfg.clip:
            z = z.clip(lower=-3.0, upper=3.0)
        # Map z∈(-inf,inf) to (0,1) via logistic
        return 1.0 / (1.0 + np.exp(-z))

    if cfg.method == "robust_minmax":
        lo, hi = _robust_bounds(s, cfg.p_low, cfg.p_high)
        if cfg.hard_min is not None:
            lo = min(lo, cfg.hard_min)
        if cfg.hard_max is not None:
            hi = max(hi, cfg.hard_max)
        out = _minmax(s, lo, hi)
        return out.clip(0.0, 1.0) if cfg.clip else out

    # default: minmax
    lo = float(s.min()) if cfg.hard_min is None else cfg.hard_min
    hi = float(s.max()) if cfg.hard_max is None else cfg.hard_max
    out = _minmax(s, lo, hi)
    return out.clip(0.0, 1.0) if cfg.clip else out


def weighted_mean(values: pd.DataFrame, weights: pd.Series) -> pd.Series:
    """
    values: DataFrame with columns = submetric ids, rows indexed by (region,year)
    weights: Series with index aligned to columns, sums to 1.
    Returns a Series aligned to index with weighted average, skipping NaNs row-wise.
    """
    w = weights.reindex(values.columns).fillna(0.0)
    total_w = np.where(values.notna(), w.values, 0.0)
    # Avoid division by zero: if a row has zero available weight (all NaN), return NaN.
    num = np.nansum(values.values * total_w, axis=1)
    den = np.nansum(total_w, axis=1)
    out = np.divide(num, den, out=np.full_like(num, np.nan, dtype=float), where=den > 0)
    return pd.Series(out, index=values.index, name="weighted_mean")


def renorm_weights(raw: pd.Series) -> pd.Series:
    """Clip to [0,1], renormalize to sum 1. If all zeros, return uniform."""
    v = raw.fillna(0.0).astype(float).clip(0.0, 1.0)
    s = float(v.sum())
    if s <= 0:
        if len(v) == 0:
            return v
        return pd.Series(np.full(len(v), 1.0 / len(v)), index=v.index)
    return v / s

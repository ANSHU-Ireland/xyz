# scoring/compute_scores.py
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple

import numpy as np
import pandas as pd
import yaml

from scoring.normalization import (
    Direction,
    NormConfig,
    normalize_series,
    renorm_weights,
    weighted_mean,
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Paths
BASE_DIR = Path(__file__).resolve().parents[1]
FORMULAS_DIR = BASE_DIR / "config" / "formulas"
WEIGHTS_PATH = BASE_DIR / "config" / "weights.yaml"


# ---- Data Provider Interface -------------------------------------------------

class DataProvider:
    """
    Abstract interface to fetch submetric raw series as pd.Series indexed by (iso3, year).
    Implement in services.data_access.DataAccess and inject into ScoreEngine.
    """

    def submetric_series(
        self, score_name: str, submetric_id: str, cfg: Mapping[str, Any], filters: Mapping[str, Any]
    ) -> pd.Series:  # pragma: no cover - interface
        raise NotImplementedError


# ---- Config Models -----------------------------------------------------------

@dataclass(frozen=True)
class SubmetricCfg:
    id: str
    direction: Direction
    source: Optional[str] = None
    column: Optional[str] = None
    transform: Optional[str] = None
    weight_default: float = 1.0


@dataclass(frozen=True)
class ScoreCfg:
    score: str
    normalization: str = "minmax"
    aggregation: str = "weighted_mean"
    submetrics: Tuple[SubmetricCfg, ...] = ()
    bounds: Optional[Mapping[str, Any]] = None


# ---- Loaders ----------------------------------------------------------------

@lru_cache(maxsize=64)
def load_score_cfg(score_name: str) -> ScoreCfg:
    path = FORMULAS_DIR / f"{score_name}.yaml"
    if not path.exists():
        raise FileNotFoundError(f"Score config not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    subs = []
    for sm in raw.get("submetrics", []):
        subs.append(
            SubmetricCfg(
                id=sm["id"],
                direction=sm.get("direction", "higher_is_better"),
                source=sm.get("source"),
                column=sm.get("column"),
                transform=sm.get("transform"),
                weight_default=float(sm.get("weight_default", 1.0)),
            )
        )
    return ScoreCfg(
        score=raw["score"],
        normalization=str(raw.get("normalization", "minmax")),
        aggregation=str(raw.get("aggregation", "weighted_mean")),
        submetrics=tuple(subs),
        bounds=raw.get("bounds"),
    )


@lru_cache(maxsize=1)
def load_default_weights() -> Dict[str, Any]:
    if not WEIGHTS_PATH.exists():
        # Minimal safe default: uniform across known scores at runtime
        return {"personas": {"regular_citizen": {"alpha": {}}}}
    with open(WEIGHTS_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ---- Engine -----------------------------------------------------------------

class ScoreEngine:
    """
    Deterministic, explainable engine:
      submetrics -> normalized submetrics (0..1, higher=more viable)
      -> per-score S_k -> overall FVI (weights alpha)
    """

    def __init__(self, provider: DataProvider):
        self.provider = provider

    # ---- Public API ----

    def compute_scores(
        self,
        score_names: Iterable[str],
        filters: Mapping[str, Any],
        submetric_weights: Optional[Mapping[str, Mapping[str, float]]] = None,
        normalization_overrides: Optional[Mapping[str, Any]] = None,
    ) -> Dict[str, pd.Series]:
        """
        Returns dict {score_name: S_k series (index by MultiIndex (iso3, year))}.
        """
        out: Dict[str, pd.Series] = {}
        for score_name in score_names:
            cfg = load_score_cfg(score_name)
            sm_weights = self._collect_sub_weights(cfg, submetric_weights)
            norm_cfg = self._norm_cfg_for_score(cfg, normalization_overrides)

            # Fetch raw submetric series and normalize to 0..1 (higher=more viable)
            sm_norm: Dict[str, pd.Series] = {}
            for sm in cfg.submetrics:
                raw = self.provider.submetric_series(score_name, sm.id, cfg=self._sub_cfg_dict(sm), filters=filters)
                norm = normalize_series(
                    raw,
                    direction=sm.direction,
                    cfg=norm_cfg,
                )
                sm_norm[sm.id] = norm

            # Align indexes and aggregate
            df = self._align_columns(sm_norm)
            if df.empty:
                logger.warning("No data for score '%s' under filters=%s", score_name, json.dumps(filters, default=str))
                out[score_name] = pd.Series(dtype=float)
                continue

            w = renorm_weights(pd.Series(sm_weights, name="w"))
            s_k = weighted_mean(df, w)
            s_k.name = score_name
            out[score_name] = s_k
        return out

    def compute_fvi(
        self,
        scores: Mapping[str, pd.Series],
        alpha: Mapping[str, float],
    ) -> pd.Series:
        """
        Compute overall FVI = Σ_k alpha_k * S_k, returning a series aligned to the common index.
        alpha will be renormalized to sum 1 over provided score keys.
        """
        if not scores:
            return pd.Series(dtype=float)

        # Align indexes
        idx = None
        for s in scores.values():
            idx = s.index if idx is None else idx.intersection(s.index)
        if idx is None or len(idx) == 0:
            return pd.Series(dtype=float)

        # Matrix of scores
        cols = list(scores.keys())
        X = np.vstack([scores[c].reindex(idx).values for c in cols]).T
        a = renorm_weights(pd.Series(alpha)).reindex(cols).fillna(0.0).values
        fvi = X.dot(a)
        out = pd.Series(fvi, index=idx, name="FVI")
        return out

    # ---- Helpers ----

    @staticmethod
    def _sub_cfg_dict(sm: SubmetricCfg) -> Dict[str, Any]:
        return {
            "id": sm.id,
            "direction": sm.direction,
            "source": sm.source,
            "column": sm.column,
            "transform": sm.transform,
        }

    @staticmethod
    def _align_columns(series_dict: Mapping[str, pd.Series]) -> pd.DataFrame:
        if not series_dict:
            return pd.DataFrame()
        # Inner join on index
        common_idx = None
        for s in series_dict.values():
            common_idx = s.index if common_idx is None else common_idx.intersection(s.index)
        if common_idx is None or len(common_idx) == 0:
            return pd.DataFrame()
        cols = {}
        for k, s in series_dict.items():
            cols[k] = s.reindex(common_idx)
        return pd.DataFrame(cols, index=common_idx)

    @staticmethod
    def _collect_sub_weights(cfg: ScoreCfg, overrides: Optional[Mapping[str, Mapping[str, float]]]) -> Dict[str, float]:
        if overrides and cfg.score in overrides:
            base = dict(overrides[cfg.score])
        else:
            base = {}
        # Fill defaults for any missing submetric weight
        for sm in cfg.submetrics:
            base.setdefault(sm.id, float(sm.weight_default))
        return base

    @staticmethod
    def _norm_cfg_for_score(cfg: ScoreCfg, overrides: Optional[Mapping[str, Any]]) -> NormConfig:
        b = cfg.bounds or {}
        meth = cfg.normalization
        if overrides and "normalization" in overrides:
            # Allow per-score override if provided like {"normalization": {"method":"robust_minmax",...}}
            o = overrides["normalization"]
            meth = o.get("method", meth)
            b = {**b, **{k: v for k, v in o.items() if k != "method"}}
        return NormConfig(
            method=meth if meth in ("minmax", "robust_minmax", "zscore") else "minmax",
            hard_min=b.get("hard_min"),
            hard_max=b.get("hard_max"),
            p_low=float(b.get("p_low", 0.01)),
            p_high=float(b.get("p_high", 0.99)),
            clip=bool(b.get("clip", True)),
        )


# ---- Public convenience functions -------------------------------------------

def compute_scores_and_fvi(
    provider: DataProvider,
    score_names: Iterable[str],
    filters: Mapping[str, Any],
    alpha: Mapping[str, float],
    submetric_weights: Optional[Mapping[str, Mapping[str, float]]] = None,
    normalization_overrides: Optional[Mapping[str, Any]] = None,
) -> Tuple[Dict[str, pd.Series], pd.Series]:
    """
    Utility wrapper returning (scores_dict, fvi_series)
    """
    engine = ScoreEngine(provider)
    scores = engine.compute_scores(
        score_names=score_names,
        filters=filters,
        submetric_weights=submetric_weights,
        normalization_overrides=normalization_overrides,
    )
    fvi = engine.compute_fvi(scores, alpha=alpha)
    return scores, fvi

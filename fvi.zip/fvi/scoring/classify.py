# scoring/classify.py
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd
import yaml

from scoring.compute_scores import DataProvider, compute_scores_and_fvi

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Path to your classification config
BASE_DIR = Path(__file__).resolve().parents[1]
CLASS_PATH = BASE_DIR / "config" / "classification.yaml"


class Classifier:
    """
    Rule-based 3-class classifier on FVI, with optional model override.
    Config in config/classification.yaml:
      rule_based:
        sustainable: {max: 0.33}
        critical_transition: {min:0.33, max:0.67}
        decommission: {min:0.67}
      model: {...}  # optional model parameters
    """

    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path or CLASS_PATH
        if not self.config_path.exists():
            raise FileNotFoundError(f"Classification config not found: {self.config_path}")
        with open(self.config_path, "r", encoding="utf-8") as f:
            self.cfg = yaml.safe_load(f)

        # Extract thresholds
        rb = self.cfg.get("rule_based", {})
        self.t_sust = float(rb.get("sustainable", {}).get("max", 0.33))
        self.t_decom = float(rb.get("decommission", {}).get("min", 0.67))

    def label(self, fvi: float) -> str:
        """
        Returns one of: "sustainable", "critical_transition", "decommission"
        """
        if np.isnan(fvi):
            return "unknown"
        if fvi <= self.t_sust:
            return "sustainable"
        if fvi >= self.t_decom:
            return "decommission"
        return "critical_transition"

    def probabilities(self, fvi: float) -> Dict[str, float]:
        """
        Simple triangular probabilities around thresholds.
        (E.g., linear interpolation within the mid band.)
        """
        if np.isnan(fvi):
            return {"sustainable": 0.0, "critical_transition": 0.0, "decommission": 0.0}
        if fvi <= self.t_sust:
            return {"sustainable": 1.0, "critical_transition": 0.0, "decommission": 0.0}
        if fvi >= self.t_decom:
            return {"sustainable": 0.0, "critical_transition": 0.0, "decommission": 1.0}
        # between t_sust and t_decom
        span = self.t_decom - self.t_sust
        p_ct = (fvi - self.t_sust) / span
        p_su = 1.0 - p_ct
        # decommission probability 0 in middle band
        return {"sustainable": p_su, "critical_transition": p_ct, "decommission": 0.0}


def classify_series(
    provider: DataProvider,
    score_names: list[str],
    filters: Dict[str, Any],
    alpha: Dict[str, float],
    submetric_weights: Optional[Dict[str, Dict[str, float]]] = None,
    normalization_overrides: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:
    """
    Compute scores & FVI, then classify each (iso3, year).
    Returns DataFrame with columns: iso3, year, fvi, label, p_sustainable, p_critical_transition, p_decommission
    """
    # Compute raw scores and FVI
    scores_dict, fvi = compute_scores_and_fvi(
        provider=provider,
        score_names=score_names,
        filters=filters,
        alpha=alpha,
        submetric_weights=submetric_weights,
        normalization_overrides=normalization_overrides,
    )
    clf = Classifier()
    records = []
    for (iso3, year), val in fvi.items():
        lbl = clf.label(val)
        probs = clf.probabilities(val)
        records.append({
            "iso3": iso3,
            "year": int(year),
            "fvi": float(val),
            "label": lbl,
            "p_sustainable": float(probs["sustainable"]),
            "p_critical_transition": float(probs["critical_transition"]),
            "p_decommission": float(probs["decommission"]),
        })
    return pd.DataFrame.from_records(records).set_index(["iso3", "year"])

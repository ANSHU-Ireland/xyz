#!/usr/bin/env bash
# scripts/bootstrap_mac.sh
set -euo pipefail

# ----- Paths & logging -----
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUNTIME_DIR="${REPO_ROOT}/runtime"
LOG_DIR="${RUNTIME_DIR}/logs"
mkdir -p "${LOG_DIR}" "${RUNTIME_DIR}/indexes" "${RUNTIME_DIR}/duckdb" "${RUNTIME_DIR}/cache"
LOG_FILE="${LOG_DIR}/bootstrap_mac.log"

exec > >(tee -a "${LOG_FILE}") 2>&1
echo "== FVI Bootstrap (macOS) =="

# Ensure we clean up on exit
cleanup() {
  if [[ -n "${BACKEND_PID:-}" ]]; then
    kill "${BACKEND_PID}" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

# ----- Helpers -----
fail() { echo "[ERROR] $*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

pick_port() {
  local p=8787
  while [[ $p -le 8799 ]]; do
    if ! lsof -iTCP -sTCP:LISTEN -P | awk '{print $9}' | grep -q ":${p}$"; then
      echo "$p"; return 0
    fi
    p=$((p+1))
  done
  return 1
}

read_env_from_file() {
  local key="$1"; local file="$2"
  [[ -f "$file" ]] || { echo ""; return 0; }
  local line
  line="$(grep -E "^${key}=" "$file" || true)"
  [[ -n "$line" ]] && echo "${line#*=}" || echo ""
}

# ----- 1) Python -----
PYTHON_BIN=""
if have python3; then PYTHON_BIN="python3"
elif have python; then PYTHON_BIN="python"
else fail "Python 3 is required. Install Xcode CLT & Python (e.g., via python.org or Homebrew)."
fi
echo "[OK] Python: $(${PYTHON_BIN} -V)"

# ----- 2) Create venv & install deps -----
VENV_DIR="${REPO_ROOT}/.venv"
if [[ ! -d "${VENV_DIR}" ]]; then
  "${PYTHON_BIN}" -m venv "${VENV_DIR}"
fi
# shellcheck source=/dev/null
source "${VENV_DIR}/bin/activate"

python -m pip install -U pip setuptools wheel

REQ_FILE="${REPO_ROOT}/requirements.txt"
PYPROJECT="${REPO_ROOT}/pyproject.toml"

if [[ -f "${REQ_FILE}" ]]; then
  pip install -r "${REQ_FILE}"
elif [[ -f "${PYPROJECT}" ]]; then
  # Editable install for PEP 517 projects; fallback to explicit deps
  if ! pip install -e "${REPO_ROOT}"; then
    pip install \
      fastapi "uvicorn[standard]" python-dotenv \
      google-generativeai \
      pandas numpy pyyaml \
      duckdb faiss-cpu openpyxl \
      pydantic python-multipart
  fi
else
  pip install \
    fastapi "uvicorn[standard]" python-dotenv \
    google-generativeai \
    pandas numpy pyyaml \
    duckdb faiss-cpu openpyxl \
    pydantic python-multipart
fi

# ----- 3) Frontend (optional) -----
FRONTEND_DIR="${REPO_ROOT}/frontend"
DIST_DIR="${FRONTEND_DIR}/dist"
if have npm; then
  echo "[OK] Node detected. Building frontend…"
  pushd "${FRONTEND_DIR}" >/dev/null
  if [[ -f package-lock.json ]]; then npm ci; else npm install; fi
  npm run build
  popd >/dev/null
else
  echo "[WARN] Node not found. API will run; build the frontend later for full UI."
fi

# ----- 4) GEMINI_API_KEY -----
ENV_FILE="${REPO_ROOT}/.env"
if [[ -z "${GEMINI_API_KEY:-}" ]]; then
  GEMINI_API_KEY="$(read_env_from_file GEMINI_API_KEY "${ENV_FILE}")"
fi
if [[ -z "${GEMINI_API_KEY}" ]]; then
  echo
  echo "GEMINI_API_KEY not found in environment or .env."
  read -r -s -p "Paste your GEMINI API Key: " GEMINI_API_KEY
  echo
  [[ -n "${GEMINI_API_KEY}" ]] || fail "GEMINI_API_KEY is required to run the chat agent."
  # Persist to .env (append or create)
  if [[ -f "${ENV_FILE}" ]]; then
    printf "\nGEMINI_API_KEY=%s\n" "${GEMINI_API_KEY}" >> "${ENV_FILE}"
  else
    printf "GEMINI_API_KEY=%s\n" "${GEMINI_API_KEY}" > "${ENV_FILE}"
  fi
fi
export GEMINI_API_KEY
echo "[OK] GEMINI_API_KEY is set."

# ----- 5) Port selection -----
PORT="$(pick_port)" || fail "No free port found between 8787–8799."
HOST="127.0.0.1"
export PORT HOST
export FRONTEND_DIST="${DIST_DIR}"
echo "[OK] Using http://${HOST}:${PORT}"

# ----- 6) Build RAG index (optional) -----
BUILD_INDEX="${REPO_ROOT}/scripts/build_index.py"
if [[ -f "${BUILD_INDEX}" ]]; then
  echo "[i] Building RAG index…"
  python "${BUILD_INDEX}"
else
  echo "[i] No scripts/build_index.py found; skipping index build."
fi

# ----- 7) Start backend -----
echo "[i] Starting backend (Uvicorn) …"
python -m uvicorn api.main:app --host "${HOST}" --port "${PORT}" --log-level info &
BACKEND_PID=$!
sleep 1

# Open default browser
if have open; then
  open "http://${HOST}:${PORT}/"
else
  echo "[i] Open your browser at: http://${HOST}:${PORT}/"
fi

echo "=== Running. Close this terminal to stop the server. ==="
wait "${BACKEND_PID}"

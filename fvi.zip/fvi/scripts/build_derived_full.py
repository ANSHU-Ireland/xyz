# scripts/build_derived_full.py
from __future__ import annotations

import math
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

# ------------------------------- Paths ---------------------------------------

BASE_DIR = Path(__file__).resolve().parents[1]
STATIC = BASE_DIR / "data" / "static"
DERIVED = BASE_DIR / "data" / "derived"
DERIVED.mkdir(parents=True, exist_ok=True)

# --------------------------- Utilities & mapping -----------------------------

def norm_iso3(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.upper()

def year_from_datetime(s: pd.Series, colname: str) -> pd.Series:
    # accepts 'YYYY-mm-dd HH:MM:SS' or 'YYYY' formats
    vals = pd.to_datetime(s, errors="coerce")
    y = vals.dt.year.astype("Int64")
    # fallback if parse failed but already looks like YYYY
    mask = y.isna() & s.astype(str).str.fullmatch(r"\d{4}")
    y.loc[mask] = s[mask].astype("Int64")
    return y

def slope_linear(y: Iterable[float], x: Optional[Iterable[float]] = None) -> float:
    arr = np.array(list(y), dtype=float)
    n = arr.size
    if n < 2 or np.all(~np.isfinite(arr)):
        return np.nan
    if x is None:
        x = np.arange(n, dtype=float)
    xv = np.array(list(x), dtype=float)
    mask = np.isfinite(arr) & np.isfinite(xv)
    if mask.sum() < 2:
        return np.nan
    X = xv[mask]
    Y = arr[mask]
    # slope = cov(X,Y)/var(X)
    v = np.var(X)
    if v <= 0:
        return np.nan
    return float(np.cov(X, Y, ddof=0)[0, 1] / v)

def pct_rank_by_year(df: pd.DataFrame, valcol: str, bycols: List[str]) -> pd.Series:
    out = []
    for _, g in df.groupby(bycols):
        r = g[valcol].rank(pct=True, method="average")
        out.append(r)
    return pd.concat(out).sort_index()

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

# ISO3 mapping: auto-derive from emissions (Entity->Code) + extras
def build_iso3_map() -> Dict[str, str]:
    # Primary mapping from annual CO2 (covers most countries)
    co2_path = STATIC / "emissions" / "annual-co2-emission.csv"
    co2 = pd.read_csv(co2_path, usecols=["Entity", "Code"]).dropna()
    m = {str(a).strip(): str(b).strip().upper() for a, b in co2.drop_duplicates().values}
    # Common aliases
    extras = {
        "United States": "USA",
        "United Kingdom": "GBR",
        "Congo (Kinshasa)": "COD",
        "Congo (Brazzaville)": "COG",
        "Côte d'Ivoire": "CIV",
        "Cote d'Ivoire": "CIV",
        "Czech Republic": "CZE",
        "Russian Federation": "RUS",
        "Vietnam": "VNM",
        "South Korea": "KOR",
        "North Korea": "PRK",
        "Laos": "LAO",
        "Eswatini": "SWZ",
        "Swaziland": "SWZ",
        "Myanmar": "MMR",
        "East Timor": "TLS",
        "Vatican": "VAT",
        "Macedonia": "MKD",
        "Bolivia": "BOL",
        "Venezuela": "VEN",
        "Iran": "IRN",
        "Syria": "SYR",
        "Palestine": "PSE",
        "Taiwan": "TWN",
        "Hong Kong": "HKG",
        "Moldova": "MDA"
    }
    m.update(extras)
    return m

ISO3_MAP = build_iso3_map()

def name_to_iso3(name: str) -> Optional[str]:
    if not name or not isinstance(name, str):
        return None
    s = name.strip()
    if s in ISO3_MAP:
        return ISO3_MAP[s]
    # try case-insensitive match
    for k, v in ISO3_MAP.items():
        if k.lower() == s.lower():
            return v
    # simple punctuation-insensitive contains
    q = re.sub(r"[^A-Za-z0-9 ]+", "", s).lower().strip()
    for k, v in ISO3_MAP.items():
        kk = re.sub(r"[^A-Za-z0-9 ]+", "", k).lower().strip()
        if kk == q:
            return v
    return None

# ----------------------------- ETL Builders ----------------------------------

def build_artificial_support():
    # 1) Policy strength: coal-phase-out-timeline.csv
    src = STATIC / "artificial_support" / "coal-phase-out-timeline.csv"
    df = pd.read_csv(src)
    df = df.rename(columns={"Entity":"country","Code":"iso3","Year":"year","Coal Exit Timeline (Beyond Coal)":"timeline"})
    df["iso3"] = norm_iso3(df["iso3"])

    def map_policy(t: str) -> float:
        s = str(t).strip().lower()
        if s == "" or s == "nan":
            return 0.4
        if "coal free" in s:
            return 1.0
        if "phase" in s or "exit" in s or "pledge" in s or "commit" in s:
            return 0.8
        if "consider" in s or "discussion" in s or "planning" in s:
            return 0.6
        if "no" in s or "unknown" in s or "none" in s:
            return 0.3
        # neutral default
        return 0.5

    df["policy_strength_index"] = df["timeline"].map(map_policy).astype(float)
    outdir = DERIVED / "artificial_support"; ensure_dir(outdir)
    (df[["iso3","year","policy_strength_index"]]
       .dropna(subset=["iso3","year"])
       .astype({"year":"Int64"})
       .to_csv(outdir / "policy_strength_index.csv", index=False))

    # 2) Emissions-weighted factor: coal-mining_country_emissions_v4_4_0.csv
    src2 = STATIC / "artificial_support" / "coal-mining_country_emissions_v4_4_0.csv"
    d2 = pd.read_csv(src2, low_memory=False)
    # rename and extract year
    d2 = d2.rename(columns={"iso3_country":"iso3"})
    d2["iso3"] = norm_iso3(d2["iso3"])
    d2["year"] = year_from_datetime(d2["start_time"], "start_time")
    d2["emissions_quantity"] = pd.to_numeric(d2["emissions_quantity"], errors="coerce")
    # Filter coal-mining and annual where available
    if "subsector" in d2.columns:
        d2 = d2[d2["subsector"].astype(str).str.lower().eq("coal-mining")]
    grp = d2.groupby(["iso3","year"], dropna=True)["emissions_quantity"].sum().reset_index(name="emissions_tco2e")
    # Normalize per year to 0..1 (higher = more support risk); we'll keep as-is and set direction = lower_is_better in YAML
    # Keep raw; also provide per-year minmax normalized
    grp["emissions_tco2e"] = pd.to_numeric(grp["emissions_tco2e"], errors="coerce").fillna(0.0)

    def per_year_minmax(g: pd.DataFrame) -> pd.DataFrame:
        mn = g["emissions_tco2e"].min()
        mx = g["emissions_tco2e"].max()
        if not np.isfinite(mx - mn) or (mx - mn) <= 0:
            g["emissions_norm"] = 0.5
        else:
            g["emissions_norm"] = (g["emissions_tco2e"] - mn) / (mx - mn)
        return g

    grp = grp.groupby("year", group_keys=False).apply(per_year_minmax)
    grp = grp.dropna(subset=["iso3","year"])
    grp.to_csv(outdir / "mining_emissions_norm.csv", index=False)

def build_ecological():
    src = STATIC / "ecological" / "global_mining_area_per_country_v1.csv"
    df = pd.read_csv(src)
    # Normalize headers, keep snapshot year, compute normalized intensity
    df = df.rename(columns={"ISO3_CODE":"iso3","AREA":"area_km2"})
    df["iso3"] = norm_iso3(df["iso3"])
    df["year"] = 2024  # snapshot
    # normalise area across countries as proxy for LDI (no country area km2 available)
    mn, mx = df["area_km2"].min(), df["area_km2"].max()
    if mx - mn > 0:
        df["ldi_norm"] = (df["area_km2"] - mn) / (mx - mn)
    else:
        df["ldi_norm"] = 0.5
    outdir = DERIVED / "ecological"; ensure_dir(outdir)
    df[["iso3","year","area_km2","ldi_norm"]].to_csv(outdir / "mining_area_ldinorm.csv", index=False)

def build_emissions():
    src = STATIC / "emissions" / "annual-co2-emission.csv"
    df = pd.read_csv(src)
    df = df.rename(columns={"Entity":"country","Code":"iso3","Year":"year","Annual CO₂ emissions from coal":"co2_mt"})
    df["iso3"] = norm_iso3(df["iso3"])
    df["co2_mt"] = pd.to_numeric(df["co2_mt"], errors="coerce")
    df = df.dropna(subset=["iso3","year"])
    # per-year global share
    g = df.groupby("year", as_index=False)["co2_mt"].sum().rename(columns={"co2_mt":"world"})
    merged = df.merge(g, on="year", how="left")
    merged["co2_share"] = np.where(merged["world"] > 0, merged["co2_mt"] / merged["world"], np.nan)
    # cumulative per country up to each year
    merged = merged.sort_values(["iso3","year"])
    merged["co2_cum"] = merged.groupby("iso3")["co2_mt"].cumsum()
    # normalize cumulative per year across countries
    def norm_by_year(h: pd.DataFrame) -> pd.DataFrame:
        mn = h["co2_cum"].min()
        mx = h["co2_cum"].max()
        h["co2_cum_norm"] = 0.5 if not np.isfinite(mx - mn) or (mx - mn) <= 0 else (h["co2_cum"] - mn) / (mx - mn)
        return h
    merged = merged.groupby("year", group_keys=False).apply(norm_by_year)
    outdir = DERIVED / "emissions"; ensure_dir(outdir)
    merged[["iso3","year","co2_mt","co2_share","co2_cum","co2_cum_norm"]].to_csv(outdir / "coal_co2_timeseries.csv", index=False)

def build_infrastructure():
    src = STATIC / "infrastructure" / "global_coal_plant_tracker_data.csv"
    df = pd.read_csv(src, low_memory=False)
    # country name -> iso3 via mapping
    cname = None
    for c in ["country_area", "country", "Country"]:
        if c in df.columns:
            cname = c; break
    if cname is None:
        raise RuntimeError("No country column found in plant tracker.")
    df["iso3"] = df[cname].apply(name_to_iso3)
    df["start_year"] = pd.to_numeric(df.get("start_year"), errors="coerce")
    # Choose scoring years: for each plant, we emit IR1 per year it operated (bounded)
    # Practical simplification: evaluate IR1 at plant 'operating_year' if present, else at start_year
    df["operating_year"] = pd.to_numeric(df.get("operating_year"), errors="coerce")
    df["ref_year"] = df["operating_year"].fillna(df["start_year"])
    df = df.dropna(subset=["iso3","ref_year"])
    # Typical lifetime
    L = 40.0
    df["age"] = np.maximum(0.0, (df["ref_year"] - df["start_year"]).fillna(0.0))
    df["ir1_age_to_lifetime"] = np.clip(df["age"] / L, 0.0, 1.0)
    # Aggregate to (iso3, year)
    ser = df.groupby(["iso3","ref_year"])["ir1_age_to_lifetime"].mean().reset_index()
    ser = ser.rename(columns={"ref_year":"year"})
    outdir = DERIVED / "infrastructure"; ensure_dir(outdir)
    ser.to_csv(outdir / "ir1_age_to_lifetime.csv", index=False)

def build_economic():
    # Trade EC3
    trade = STATIC / "economic" / "TradeData_7_25_2025_0_51_17.csv"
    t = pd.read_csv(trade, low_memory=False)
    t.columns = [c.lower() for c in t.columns]
    t["reporteriso"] = norm_iso3(t["reporteriso"])
    t["fobvalue"] = pd.to_numeric(t["fobvalue"], errors="coerce").fillna(0.0)
    coal_mask = t["cmdcode"].astype(str).str.startswith(("2701","2702","2704"))
    export_mask = t["flowdesc"].str.lower().eq("export")
    coal = t[coal_mask & export_mask]
    tot  = t[export_mask]
    g_coal = coal.groupby(["reporteriso","refyear"], as_index=False)["fobvalue"].sum().rename(columns={"fobvalue":"coal_exp_usd"})
    g_tot  = tot.groupby(["reporteriso","refyear"],  as_index=False)["fobvalue"].sum().rename(columns={"fobvalue":"tot_exp_usd"})
    merged = pd.merge(g_tot, g_coal, on=["reporteriso","refyear"], how="left").fillna({"coal_exp_usd":0.0})
    merged["coal_export_share_pct"] = 100.0 * merged["coal_exp_usd"] / merged["tot_exp_usd"].replace(0, np.nan)
    econ_dir = DERIVED / "economic"; ensure_dir(econ_dir)
    econ_ec3 = merged.rename(columns={"reporteriso":"iso3","refyear":"year"})[["iso3","year","coal_export_share_pct"]]
    econ_ec3.to_csv(econ_dir / "coal_export_share.csv", index=False)

    # GDP per capita EC1 (optional, if population present in Necessity Data)
    gdp_xls = STATIC / "economic" / "GDP_WDI.xlsx"
    df_gdp = pd.read_excel(gdp_xls, sheet_name="Data")
    df_gdp = df_gdp[(df_gdp["Indicator Code"] == "NY.GDP.MKTP.CD")]
    gdp_long = df_gdp.melt(id_vars=["Country Code","Country Name","Indicator Name","Indicator Code"], var_name="year", value_name="gdp_usd")
    gdp_long = gdp_long.rename(columns={"Country Code":"iso3"})
    gdp_long["iso3"] = norm_iso3(gdp_long["iso3"])
    # year columns are numeric strings
    gdp_long = gdp_long[gdp_long["year"].astype(str).str.fullmatch(r"\d{4}")]
    gdp_long["year"] = gdp_long["year"].astype(int)
    # population from Necessity Energy Fulfillment.xlsx if present
    ne_path = STATIC / "necessity" / "Necessity Energy Fulfillment.xlsx"
    df_ne = pd.read_excel(ne_path, sheet_name="Data")
    df_ne = df_ne.rename(columns={"iso_code":"iso3","year":"year","population":"pop"})
    df_ne["iso3"] = norm_iso3(df_ne["iso3"])
    df_ne = df_ne.dropna(subset=["iso3","year"])
    pop = df_ne[["iso3","year","pop"]].dropna()
    merged_pc = gdp_long.merge(pop, on=["iso3","year"], how="inner")
    merged_pc["gdp_pc_usd"] = pd.to_numeric(merged_pc["gdp_usd"], errors="coerce") / pd.to_numeric(merged_pc["pop"], errors="coerce")
    merged_pc = merged_pc.replace([np.inf, -np.inf], np.nan).dropna(subset=["gdp_pc_usd"])
    merged_pc[["iso3","year","gdp_pc_usd"]].to_csv(econ_dir / "gdp_pc_usd.csv", index=False)

def build_necessity():
    outdir = DERIVED / "necessity"; ensure_dir(outdir)
    # N2 Coal share of electricity
    xls = pd.ExcelFile(STATIC / "necessity" / "Electricity_generated_by_coal.xlsx")
    sheet = xls.parse(xls.sheet_names[0])
    # Expect columns: Country Code, 1990 [YR1990], ...
    sheet = sheet.rename(columns={"Country Code":"iso3"})
    sheet["iso3"] = norm_iso3(sheet["iso3"])
    # melt
    year_cols = [c for c in sheet.columns if re.match(r"^\d{4} \[YR\d{4}\]$", str(c))]
    long = sheet.melt(id_vars=["iso3"], value_vars=year_cols, var_name="year_label", value_name="coal_pct_electricity")
    long["year"] = long["year_label"].str.extract(r"^(\d{4})").astype(int)
    long["coal_pct_electricity"] = pd.to_numeric(long["coal_pct_electricity"], errors="coerce")
    long = long.dropna(subset=["coal_pct_electricity"])
    long[["iso3","year","coal_pct_electricity"]].to_csv(outdir / "coal_electricity_share.csv", index=False)

    # N3/N4 Coal consumption — per capita & trend
    xls2 = pd.ExcelFile(STATIC / "necessity" / "Coal_Consumption_by_Countries_Year_Wise.xlsx")
    cons = xls2.parse(xls2.sheet_names[0])
    cons = cons.rename(columns={"Entity":"country","Year":"year","Coal consumption - TWh":"coal_twh"})
    # Map country -> iso3 using ISO3_MAP; drop aggregates that don't map
    cons["iso3"] = cons["country"].apply(name_to_iso3)
    cons = cons.dropna(subset=["iso3","year"])
    cons["coal_twh"] = pd.to_numeric(cons["coal_twh"], errors="coerce")
    cons = cons.dropna(subset=["coal_twh"])
    cons[["iso3","year","coal_twh"]].to_csv(outdir / "coal_consumption_twh.csv", index=False)

    # N3 per capita (requires population from Necessity Data)
    ne = pd.read_excel(STATIC / "necessity" / "Necessity Energy Fulfillment.xlsx", sheet_name="Data")
    ne = ne.rename(columns={"iso_code":"iso3","year":"year","population":"pop"})
    ne["iso3"] = norm_iso3(ne["iso3"])
    pop = ne[["iso3","year","pop"]].dropna()
    cons_pc = cons.merge(pop, on=["iso3","year"], how="inner")
    cons_pc["coal_cons_pc_twh"] = pd.to_numeric(cons_pc["coal_twh"], errors="coerce") / pd.to_numeric(cons_pc["pop"], errors="coerce")
    cons_pc = cons_pc.replace([np.inf, -np.inf], np.nan).dropna(subset=["coal_cons_pc_twh"])
    cons_pc[["iso3","year","coal_cons_pc_twh"]].to_csv(outdir / "coal_cons_pc_twh.csv", index=False)

    # N4 substitutability: slope over trailing 5 years (positive slope = worse)
    cons = cons.sort_values(["iso3","year"])
    def slope_trailing(g: pd.DataFrame, window: int = 5) -> pd.DataFrame:
        ys = g["year"].values
        vals = g["coal_twh"].values
        out = []
        for i in range(len(g)):
            lo = max(0, i - window + 1)
            s = slope_linear(vals[lo:i+1], ys[lo:i+1])
            out.append(s if np.isfinite(s) else np.nan)
        g["coal_cons_slope5"] = out
        return g
    cons_sl = cons.groupby("iso3", group_keys=False).apply(slope_trailing)
    # Keep positive slope only; negatives (declines) are better
    cons_sl["coal_cons_slope5_pos"] = cons_sl["coal_cons_slope5"].clip(lower=0.0)
    cons_sl[["iso3","year","coal_cons_slope5_pos"]].to_csv(outdir / "coal_cons_slope5.csv", index=False)

def build_scarcity():
    src = STATIC / "scarcity" / "Waste_to_use_ratio.csv"
    df = pd.read_csv(src, low_memory=False)
    # Filter fossil fuels
    df = df[df["Category"].astype(str).str.lower().eq("fossil fuels")]
    # Melt years
    year_cols = [c for c in df.columns if re.fullmatch(r"\d{4}", str(c))]
    long = df.melt(id_vars=["Country","Flow name","Flow code","Flow unit"], value_vars=year_cols, var_name="year", value_name="value")
    long["year"] = pd.to_numeric(long["year"], errors="coerce").astype("Int64")
    long["value"] = pd.to_numeric(long["value"], errors="coerce")
    long = long.dropna(subset=["year"])
    # Pivot flows into columns
    piv = long.pivot_table(index=["Country","year"], columns="Flow name", values="value", aggfunc="sum").reset_index()
    # Standardize column names
    ren = {
        "Domestic Extraction": "DE",
        "Domestic Material Consumption": "DMC",
        "Domestic Material Input": "DMI",
        "Imports": "IMP",
        "Exports": "EXP",
    }
    piv = piv.rename(columns=ren)
    for c in ["DE","DMC","DMI","IMP","EXP"]:
        if c not in piv.columns:
            piv[c] = np.nan
    # Map country to iso3
    piv["iso3"] = piv["Country"].apply(name_to_iso3)
    piv = piv.dropna(subset=["iso3","year"])
    # Metrics per formulas (all as risk 0..1 where higher = worse)
    eps = 1e-9
    piv["RS1_import_reliance"] = (piv["IMP"] / np.maximum(piv["DMC"], eps)).clip(lower=0.0).clip(upper=1.0)
    piv["RS2_extraction_adequacy"] = (1.0 - (piv["DE"] / np.maximum(piv["DMC"], eps))).clip(lower=0.0).clip(upper=1.0)
    piv["RS3_trade_balance_instability"] = (np.abs(piv["IMP"] - piv["EXP"]) / np.maximum(piv["DMC"], eps)).clip(lower=0.0).clip(upper=1.0)
    piv["RS4_export_exhaustion"] = (piv["EXP"] / np.maximum(piv["DE"], eps)).clip(lower=0.0).clip(upper=1.0)
    # RS5 demand pressure: percentile rank of CAGR(DMC over 5y)
    piv = piv.sort_values(["iso3","year"])
    def compute_cagr(series: pd.Series, years: pd.Series, window: int = 5) -> List[float]:
        vals = series.values.astype(float)
        yrs = years.values.astype(int)
        out = []
        for i in range(len(vals)):
            j = np.where(yrs <= yrs[i])[0]
            j = j[j >= 0]
            j = j[j >= max(0, i - window + 1)]
            if j.size < 2:
                out.append(np.nan); continue
            v0, v1 = vals[j[0]], vals[j[-1]]
            t = yrs[j[-1]] - yrs[j[0]]
            if not np.isfinite(v0) or v0 <= 0 or t <= 0:
                out.append(np.nan); continue
            cagr = (v1 / v0) ** (1.0 / t) - 1.0
            out.append(cagr)
        return out

    piv["DMC_CAGR5"] = piv.groupby("iso3", group_keys=False).apply(lambda g: pd.Series(compute_cagr(g["DMC"], g["year"], 5), index=g.index))
    # percentile per year (across countries)
    tmp = piv[["year","iso3","DMC_CAGR5"]].copy()
    tmp["rank"] = tmp.groupby("year")["DMC_CAGR5"].rank(pct=True, method="average")
    piv["RS5_demand_pressure"] = tmp["rank"].fillna(0.0)

    # RS6 depletion momentum: rank of max(0, -slope(DE)) + max(0, slope(DMC))
    def slope_per_group(g: pd.DataFrame, col: str, window: int = 5) -> pd.Series:
        arr = g[col].values
        yrs = g["year"].values
        out = []
        for i in range(len(g)):
            lo = max(0, i - window + 1)
            s = slope_linear(arr[lo:i+1], yrs[lo:i+1])
            out.append(s if np.isfinite(s) else np.nan)
        return pd.Series(out, index=g.index)

    piv = piv.sort_values(["iso3","year"])
    piv["DE_slope5"] = piv.groupby("iso3", group_keys=False).apply(lambda g: slope_per_group(g, "DE", 5))
    piv["DMC_slope5"] = piv.groupby("iso3", group_keys=False).apply(lambda g: slope_per_group(g, "DMC", 5))
    piv["RS6_depletion_momentum_raw"] = np.maximum(0.0, -piv["DE_slope5"].fillna(0.0)) + np.maximum(0.0, piv["DMC_slope5"].fillna(0.0))
    tmp2 = piv[["year","iso3","RS6_depletion_momentum_raw"]].copy()
    tmp2["rank"] = tmp2.groupby("year")["RS6_depletion_momentum_raw"].rank(pct=True, method="average")
    piv["RS6_depletion_momentum"] = tmp2["rank"].fillna(0.0)

    # RS7 efficiency gap: (DMI - DMC)/DMC capped [0,1]
    piv["RS7_efficiency_gap"] = np.maximum(0.0, (piv["DMI"] - piv["DMC"]) / np.maximum(piv["DMC"], eps)).clip(upper=1.0)

    outdir = DERIVED / "scarcity"; ensure_dir(outdir)
    keep_cols = ["iso3","year","RS1_import_reliance","RS2_extraction_adequacy","RS3_trade_balance_instability","RS4_export_exhaustion","RS5_demand_pressure","RS6_depletion_momentum","RS7_efficiency_gap"]
    piv[keep_cols].to_csv(outdir / "scarcity_rs_metrics.csv", index=False)

def main():
    print("[ETL] Building derived datasets into data/derived/ ...")
    build_artificial_support()
    build_ecological()
    build_emissions()
    build_infrastructure()
    build_economic()
    build_necessity()
    build_scarcity()
    print("[ETL] Done.")

if __name__ == "__main__":
    main()

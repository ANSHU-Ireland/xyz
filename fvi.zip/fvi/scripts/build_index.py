# scripts/build_index.py
from __future__ import annotations

import argparse
import csv
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
import yaml

# Local RAG store & chunker
from rag.store.vectordb import VectorDB, VectorDBConfig
from rag.ingest.chunker import chunk_text, ChunkParams

# Optional PDF support (graceful fallback)
try:
    from pypdf import PdfReader  # lightweight PDF text extractor
    _PDF_OK = True
except Exception:
    _PDF_OK = False


# -------- logging --------
BASE_DIR = Path(__file__).resolve().parents[1]
RUNTIME_DIR = BASE_DIR / "runtime"
LOG_DIR = RUNTIME_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "index_build.log"

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8"), logging.StreamHandler()],
)
logger = logging.getLogger("fvi.indexer")


def find_static_data() -> List[Path]:
    """Return all relevant files under data/static/** for indexing."""
    root = BASE_DIR / "data" / "static"
    if not root.exists():
        logger.warning("Data root %s not found; nothing to index.", root)
        return []
    exts = {".csv", ".xlsx", ".xls", ".parquet", ".pdf"}
    files: List[Path] = []
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in exts:
            files.append(p)
    return files


def find_configs() -> List[Path]:
    """Return config YAMLs (formulas, weights, classification) to index."""
    cfgs: List[Path] = []
    for sub in ["config/formulas", "config"]:
        d = BASE_DIR / sub
        if d.exists():
            cfgs.extend([p for p in d.rglob("*.yaml") if p.is_file()])
    return cfgs


def read_pdf_text(path: Path, max_pages: Optional[int] = None) -> str:
    """Extract text from a PDF. If parser missing, return empty string."""
    if not _PDF_OK:
        logger.warning("pypdf not available; skipping PDF text for %s", path.name)
        return ""
    try:
        reader = PdfReader(str(path))
        pages = reader.pages[: max_pages or len(reader.pages)]
        text = "\n\n".join(p.extract_text() or "" for p in pages)
        return text
    except Exception as e:
        logger.warning("Failed to read PDF %s: %s", path, e)
        return ""


def summarize_csv(path: Path, sample_rows: int = 5, max_cols: int = 80) -> str:
    """Build a compact, human-readable summary of a CSV: columns + first few rows."""
    try:
        df = pd.read_csv(path, nrows=sample_rows)
        # dtypes preview: read with smaller chunks to avoid full load
        dtypes = df.dtypes.apply(lambda t: str(t)).to_dict()
        cols = ", ".join([f"{c}:{dtypes.get(c,'?')}" for c in df.columns[:max_cols]])
        sample = df.head(min(sample_rows, len(df))).to_csv(index=False)
        return f"{path.name} | Columns: {cols}\nSample:\n{sample}"
    except Exception as e:
        logger.warning("CSV summary failed for %s: %s", path, e)
        # fallback: first KB of raw text
        try:
            raw = path.read_text(encoding="utf-8", errors="ignore")
            return f"{path.name}\n{raw[:2000]}"
        except Exception:
            return f"{path.name} (unreadable)"


def summarize_excel(path: Path, sample_rows: int = 5) -> str:
    """Summarize the first sheet of an Excel file using pandas/openpyxl."""
    try:
        xls = pd.ExcelFile(path)
        sheet = xls.sheet_names[0]
        df = xls.parse(sheet, nrows=sample_rows)
        dtypes = df.dtypes.apply(lambda t: str(t)).to_dict()
        cols = ", ".join([f"{c}:{dtypes.get(c,'?')}" for c in df.columns])
        sample = df.head(min(sample_rows, len(df))).to_csv(index=False)
        return f"{path.name} | sheet: {sheet} | Columns: {cols}\nSample:\n{sample}"
    except Exception as e:
        logger.warning("Excel summary failed for %s: %s", path, e)
        return f"{path.name} (excel unreadable)"


def read_parquet_summary(path: Path, sample_rows: int = 5) -> str:
    try:
        df = pd.read_parquet(path, engine="auto")
        dtypes = df.dtypes.apply(lambda t: str(t)).to_dict()
        cols = ", ".join([f"{c}:{dtypes.get(c,'?')}" for c in df.columns])
        sample = df.head(min(sample_rows, len(df))).to_csv(index=False)
        return f"{path.name} | Columns: {cols}\nSample:\n{sample}"
    except Exception as e:
        logger.warning("Parquet summary failed for %s: %s", path, e)
        return f"{path.name} (parquet unreadable)"


def read_yaml_text(path: Path) -> str:
    try:
        raw = path.read_text(encoding="utf-8")
        # also provide a short normalized summary
        data = yaml.safe_load(raw)
        short = json.dumps(data, ensure_ascii=False, separators=(",", ":"))[:2000]
        return f"{path.name}\n---\n{raw}\n---\nJSON summary:\n{short}"
    except Exception as e:
        logger.warning("YAML read failed for %s: %s", path, e)
        return f"{path.name} (yaml unreadable)"


def docs_to_chunks(docs: List[Tuple[str, Dict[str, Any]]], params: ChunkParams) -> Tuple[List[str], List[Dict[str, Any]]]:
    """
    Expand doc texts to chunks and propagate metadata.
    docs: List of (text, meta)
    Returns: (chunks, chunk_metas)
    """
    all_chunks: List[str] = []
    all_meta: List[Dict[str, Any]] = []
    for text, meta in docs:
        if not text or not text.strip():
            continue
        chunks = chunk_text(text, params=params)
        for i, ck in enumerate(chunks):
            cm = dict(meta)
            cm["chunk_index"] = i
            cm["chunk_count"] = len(chunks)
            all_chunks.append(ck)
            all_meta.append(cm)
    return all_chunks, all_meta


def collect_documents() -> List[Tuple[str, Dict[str, Any]]]:
    """
    Walk through:
      - data/static/** for CSV/XLSX/Parquet/PDF
      - config/formulas/*.yaml + key YAMLs
    Produce (text, meta) tuples per file.
    """
    docs: List[Tuple[str, Dict[str, Any]]] = []

    # 1) Static datasets
    for path in find_static_data():
        rel = path.relative_to(BASE_DIR)
        parent = path.parent.name.lower()
        meta = {
            "source": str(rel).replace("\\", "/"),
            "family": "data",
            "score_folder": parent,  # e.g., artificial_support
        }
        suffix = path.suffix.lower()
        if suffix == ".csv":
            text = summarize_csv(path)
            title = f"{parent} / {path.name}"
        elif suffix in (".xlsx", ".xls"):
            text = summarize_excel(path)
            title = f"{parent} / {path.name}"
        elif suffix == ".parquet":
            text = read_parquet_summary(path)
            title = f"{parent} / {path.name}"
        elif suffix == ".pdf":
            text = read_pdf_text(path, max_pages=50)  # cap large PDFs
            title = f"{parent} / {path.name}"
        else:
            continue
        meta["title"] = title
        docs.append((text, meta))

    # 2) Configs (formulas/weights/classification)
    for path in find_configs():
        rel = path.relative_to(BASE_DIR)
        meta = {
            "source": str(rel).replace("\\", "/"),
            "family": "config",
            "title": f"config / {path.name}",
        }
        text = read_yaml_text(path)
        docs.append((text, meta))

    return docs


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Build RAG vector index (FAISS + Gemini embeddings).")
    parser.add_argument("--rebuild", action="store_true", help="Delete existing index and rebuild from scratch")
    parser.add_argument("--target-chars", type=int, default=1200, help="Chunk target size in characters")
    parser.add_argument("--overlap", type=int, default=150, help="Chunk overlap in characters")
    args = parser.parse_args(argv)

    # Ensure GEMINI_API_KEY is set
    if not os.getenv("GEMINI_API_KEY"):
        logger.error("GEMINI_API_KEY is not set; cannot build embeddings. Set it in your environment or .env.")
        return 2

    cfg = VectorDBConfig.default()
    cfg.index_dir.mkdir(parents=True, exist_ok=True)

    # Rebuild option
    if args.rebuild:
        for p in [cfg.index_dir / "faiss.index", cfg.index_dir / "meta.db"]:
            if p.exists():
                p.unlink()
        logger.info("Cleared existing index files under %s", cfg.index_dir)

    # Initialize store
    vdb = VectorDB(cfg)
    if vdb.count() > 0 and not args.rebuild:
        logger.info("Index already contains %d vectors; skipping rebuild. Use --rebuild to force.", vdb.count())
        return 0

    # Collect & chunk
    docs = collect_documents()
    if not docs:
        logger.warning("No documents found to index.")
        return 0

    params = ChunkParams(target_chars=args.target_chars, overlap_chars=args.overlap)
    chunks, metas = docs_to_chunks(docs, params)

    logger.info("Indexing %d chunks from %d documents…", len(chunks), len(docs))
    # Add in batches to avoid large memory spikes
    BATCH = 64
    added = 0
    for i in range(0, len(chunks), BATCH):
        batch_texts = chunks[i : i + BATCH]
        batch_meta = metas[i : i + BATCH]
        vdb.add_texts(batch_texts, batch_meta)
        added += len(batch_texts)
        logger.info("Indexed %d/%d chunks", added, len(chunks))

    logger.info("Done. Index at %s (meta at %s)", cfg.index_dir / "faiss.index", cfg.index_dir / "meta.db")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

<# 
  scripts/bootstrap.ps1
  Production-grade bootstrap for the FVI app (Windows).

  Responsibilities:
   - Verify environment (Python, optionally Node)
   - Create and activate .venv
   - Install Python deps (requirements.txt -> pyproject -> fallback explicit list)
   - Optional: npm install + npm run build (frontend)
   - Ensure GEMINI_API_KEY (read .env, else prompt and persist)
   - Create runtime directories
   - Pick a free port (prefers 8787)
   - Start backend (uvicorn api.main:app) and open default browser
#>

# --- Helper: robust logging ---
$repoRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)  # scripts/ -> repo
$runtimeDir = Join-Path $repoRoot "runtime"
$logDir = Join-Path $runtimeDir "logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logFile = Join-Path $logDir "bootstrap.log"

Start-Transcript -Path $logFile -Append | Out-Null
Write-Host "== FVI Bootstrap =="

function Stop-TranscriptSafe {
  try { Stop-Transcript | Out-Null } catch {}
}

function Fail($msg, $code = 1) {
  Write-Error $msg
  Stop-TranscriptSafe
  exit $code
}

# --- Helper: run external process with error handling ---
function Run($cmd, $args, $workDir = $null) {
  Write-Host ">> $cmd $($args -join ' ')" -ForegroundColor Cyan
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $cmd
  $psi.Arguments = ($args -join " ")
  if ($workDir) { $psi.WorkingDirectory = $workDir }
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.UseShellExecute = $false
  $p = New-Object System.Diagnostics.Process
  $p.StartInfo = $psi
  $p.Start() | Out-Null
  $out = $p.StandardOutput.ReadToEnd()
  $err = $p.StandardError.ReadToEnd()
  $p.WaitForExit()
  if ($out) { Write-Host $out.Trim() }
  if ($err) { Write-Host $err.Trim() -ForegroundColor DarkYellow }
  if ($p.ExitCode -ne 0) { Fail "Command failed ($cmd): exit $($p.ExitCode)" $p.ExitCode }
}

# --- 1) Ensure runtime directories ---
foreach ($d in @("indexes","duckdb","cache","logs")) {
  New-Item -ItemType Directory -Force -Path (Join-Path $runtimeDir $d) | Out-Null
}

# --- 2) Check Python availability and choose interpreter ---
$pythonExe = $null
# Prefer 'py -3' shim
$pyShim = "$env:SystemRoot\py.exe"
if (Get-Command py -ErrorAction SilentlyContinue) {
  try {
    $v = & py -3 -c "import sys;print(sys.version)"
    if ($LASTEXITCODE -eq 0) { $pythonExe = "py -3" }
  } catch {}
}
if (-not $pythonExe) {
  if (Get-Command python -ErrorAction SilentlyContinue) {
    $pythonExe = "python"
  } else {
    Fail "[ERROR] Python 3.x is required but not found. Install from https://www.python.org/downloads/ and retry."
  }
}
Write-Host "[OK] Using Python: $pythonExe"

# --- 3) Create venv if missing & install deps ---
$venvDir = Join-Path $repoRoot ".venv"
$venvBin = Join-Path $venvDir "Scripts"
if (-not (Test-Path $venvDir)) {
  Run $pythonExe @("-m","venv","`"$venvDir`"")
}

$pip = Join-Path $venvBin "pip.exe"
$python = Join-Path $venvBin "python.exe"

# Upgrade pip/setuptools/wheel
Run $pip @("install","-U","pip","setuptools","wheel")

# Prefer requirements.txt if present
$reqPath = Join-Path $repoRoot "requirements.txt"
$pyproject = Join-Path $repoRoot "pyproject.toml"

if (Test-Path $reqPath) {
  Run $pip @("install","-r","`"$reqPath`"")
} elseif (Test-Path $pyproject) {
  # Try editable install if project is PEP 517
  try {
    Run $pip @("install","-e","`"$repoRoot`"")
  } catch {
    # Fallback: install common runtime packages explicitly
    Run $pip @("install",
      "fastapi","uvicorn[standard]","python-dotenv",
      "google-generativeai",
      "pandas","numpy","pyyaml",
      "duckdb","faiss-cpu","openpyxl",
      "pydantic","python-multipart"
    )
  }
} else {
  # Minimal explicit deps
  Run $pip @("install",
    "fastapi","uvicorn[standard]","python-dotenv",
    "google-generativeai",
    "pandas","numpy","pyyaml",
    "duckdb","faiss-cpu","openpyxl",
    "pydantic","python-multipart"
  )
}

# --- 4) (Optional) Build frontend if Node is available ---
$frontendDir = Join-Path $repoRoot "frontend"
$distDir = Join-Path $frontendDir "dist"
$hasNode = $false
if (Get-Command npm -ErrorAction SilentlyContinue) { $hasNode = $true }

if ($hasNode) {
  Write-Host "[OK] Node/npm detected; building frontend"
  if (Test-Path (Join-Path $frontendDir "package-lock.json")) {
    Run "npm" @("ci") $frontendDir
  } else {
    Run "npm" @("install") $frontendDir
  }
  Run "npm" @("run","build") $frontendDir
} else {
  Write-Warning "Node.js not found. API will run; build the frontend later with npm for full UI."
}

# --- 5) Ensure GEMINI_API_KEY (.env or env var) ---
$envPath = Join-Path $repoRoot ".env"

function Get-EnvFromFile($key, $path) {
  if (-not (Test-Path $path)) { return $null }
  $line = Select-String -Path $path -Pattern "^\s*$key\s*=" -SimpleMatch -CaseSensitive | Select-Object -First 1
  if ($line) {
    $val = ($line.Line -split "=",2)[1].Trim()
    return $val
  }
  return $null
}

$gemKey = $env:GEMINI_API_KEY
if (-not $gemKey) {
  $gemKey = Get-EnvFromFile "GEMINI_API_KEY" $envPath
}
if (-not $gemKey) {
  Write-Host ""
  Write-Host "GEMINI_API_KEY not found in environment or .env."
  $gemKey = Read-Host -Prompt "Paste your GEMINI API Key (input hidden)" -AsSecureString | `
            ForEach-Object { [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($_)) }
  if (-not $gemKey) { Fail "GEMINI_API_KEY is required to run the chat agent." }
  # Persist to .env (append or create)
  $line = "GEMINI_API_KEY=$gemKey"
  if (-not (Test-Path $envPath)) {
    Set-Content -Path $envPath -Value $line -NoNewline
  } else {
    Add-Content -Path $envPath -Value "`n$line"
  }
  $env:GEMINI_API_KEY = $gemKey
}
Write-Host "[OK] GEMINI_API_KEY is set (not printed for security)."

# --- 6) Pick a port (prefer 8787, else search up to 8799) ---
function Test-PortFree($port) {
  $inUse = (Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)
  return -not $inUse
}
$port = 8787
while (-not (Test-PortFree $port) -and $port -lt 8799) { $port++ }
if (-not (Test-PortFree $port)) {
  Fail "No free port found between 8787-8799."
}
$env:PORT = "$port"
$env:HOST = "127.0.0.1"
$env:FRONTEND_DIST = (Join-Path $frontendDir "dist")

Write-Host "[OK] Using port $port."

# --- 7) (Optional) Build RAG index if script exists ---
$buildIndex = Join-Path $repoRoot "scripts\build_index.py"
if (Test-Path $buildIndex) {
  Write-Host "[i] Building RAG index..."
  Run $python @("`"$buildIndex`"")
} else {
  Write-Host "[i] No scripts/build_index.py found; skipping index build."
}

# --- 8) Start backend (Uvicorn) ---
Write-Host "[i] Starting backend (Uvicorn) on http://localhost:$port ..."
$uvicornArgs = @("-m","uvicorn","api.main:app","--host",$env:HOST,"--port",$env:PORT,"--log-level","info")
# Start without shell to keep same window; capture PID for clean exit if needed
$backend = Start-Process -FilePath $python -ArgumentList $uvicornArgs -PassThru -WorkingDirectory $repoRoot

# Open browser
Start-Process "http://localhost:$port/"

Write-Host "`n=== Running. Close this window to stop the server. ==="
Write-Host "Logs: $logFile"
# Wait until process exits
Wait-Process -Id $backend.Id

Stop-TranscriptSafe
exit 0

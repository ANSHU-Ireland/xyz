# api/main.py
from __future__ import annotations

import os
import logging
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

# Load .env if present (safe no-op if not installed)
try:
    from dotenv import load_dotenv  # type: ignore
    load_dotenv()
except Exception:
    pass

# ---- Logging ----
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("fvi.app")

# ---- FastAPI app ----
def create_app() -> FastAPI:
    app = FastAPI(
        title="FVI API",
        version=os.getenv("APP_VERSION", "1.0.0"),
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # CORS (loose by default; tighten for prod)
    allowed_origins = os.getenv("CORS_ALLOW_ORIGINS", "*")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[o.strip() for o in allowed_origins.split(",")] if allowed_origins else ["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Routers
    from api.routers import chat
    app.include_router(chat.router, prefix="/api")
    
    from api.routers import config
    app.include_router(config.router, prefix="/api")

    # Optional: add other routers as they come online
    try:
        from api.routers import scores, scenario, explain, classify, export, geo  # type: ignore
        app.include_router(scenario.router, prefix="/api")
        app.include_router(scores.router, prefix="/api")
        app.include_router(explain.router, prefix="/api")
        app.include_router(classify.router, prefix="/api")
        app.include_router(export.router, prefix="/api")
        app.include_router(geo.router, prefix="/api")
    except Exception as e:
        logger.info("Optional routers not yet available: %s", e)

    # Health endpoints
    @app.get("/healthz", tags=["ops"])
    def healthz() -> dict:
        return {"status": "ok"}

    @app.get("/readyz", tags=["ops"])
    def readyz() -> dict:
        # Basic readiness check: API key present
        ready = bool(os.getenv("GEMINI_API_KEY"))
        return {"ready": ready}

    # ---- Static frontend (Vite build) ----
    base_dir = Path(__file__).resolve().parents[1]
    dist_dir = Path(os.getenv("FRONTEND_DIST", base_dir / "frontend" / "dist"))
    index_path = dist_dir / "index.html"

    if dist_dir.exists() and index_path.exists():
        app.mount(
            "/",
            StaticFiles(directory=str(dist_dir), html=True),
            name="frontend",
        )
        spa_enabled = True
        logger.info("Serving frontend from %s", dist_dir)
    else:
        spa_enabled = False
        logger.warning(
            "Frontend build not found at %s. "
            "Run `npm install && npm run build` in ./frontend and relaunch.",
            dist_dir,
        )

        @app.get("/", include_in_schema=False)
        def placeholder_root() -> Response:
            return PlainTextResponse(
                "FVI backend is running. Frontend not built yet. "
                "Build with `npm install && npm run build` in ./frontend.",
                status_code=200,
            )

    # SPA fallback: unknown paths (not under /api) return index.html
    if spa_enabled:
        @app.middleware("http")
        async def spa_fallback(request: Request, call_next):
            path: str = request.url.path
            if path.startswith("/api") or path.startswith("/docs") or path.startswith("/redoc") or path == "/openapi.json":
                return await call_next(request)
            candidate = dist_dir / path.lstrip("/")
            if candidate.exists():
                return await call_next(request)
            # fallback to index.html for SPA routes
            return FileResponse(index_path)

    # Global error handler (avoid leaking stack traces)
    @app.exception_handler(Exception)
    async def on_error(request: Request, exc: Exception):
        logger.exception("Unhandled error: %s %s", request.method, request.url.path)
        return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})

    return app


app: FastAPI = create_app()


if __name__ == "__main__":
    # For local runs without the launcher
    import uvicorn

    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8787"))
    uvicorn.run("api.main:app", host=host, port=port, reload=False, log_level="info")

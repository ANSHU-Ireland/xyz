# api/routers/config.py
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import yaml
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
import pandas as pd

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/config", tags=["config"])

BASE_DIR = Path(__file__).resolve().parents[2]
FORMULAS_DIR = BASE_DIR / "config" / "formulas"
WEIGHTS_PATH = BASE_DIR / "config" / "weights.yaml"
CLASS_PATH = BASE_DIR / "config" / "classification.yaml"
DATA_STATIC = BASE_DIR / "data" / "static"


def _safe_yaml(path: Path) -> Dict[str, Any]:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read {path.name}: {e}")

@router.get("/scores")
def list_scores():
    """
    Return available score configs and their submetric IDs.
    Shape:
    {
      "scores": [
        {"name":"necessity","submetrics":["N1","N2",...],"file":"config/formulas/necessity.yaml"},
        ...
      ]
    }
    """
    if not FORMULAS_DIR.exists():
        raise HTTPException(status_code=404, detail="config/formulas not found")
    out: List[Dict[str, Any]] = []
    for p in sorted(FORMULAS_DIR.glob("*.yaml")):
        cfg = _safe_yaml(p)
        name = cfg.get("score") or p.stem
        subs = []
        for m in cfg.get("submetrics", []):
            mid = m.get("id")
            if mid:
                subs.append(str(mid))
        out.append({"name": name, "submetrics": subs, "file": str(p.relative_to(BASE_DIR)).replace("\\", "/")})
    return JSONResponse({"scores": out})

@router.get("/personas")
def list_personas():
    """
    Return available personas and their default alpha weights.
    Shape: {"personas":[{"name":"regular_citizen","alpha":{...}}, ...]}
    """
    if not WEIGHTS_PATH.exists():
        return JSONResponse({"personas": [{"name": "regular_citizen", "alpha": {}}]})
    cfg = _safe_yaml(WEIGHTS_PATH)
    personas = []
    for name, body in (cfg.get("personas") or {}).items():
        alpha = body.get("alpha") or {}
        personas.append({"name": name, "alpha": alpha})
    if not personas:
        personas = [{"name": "regular_citizen", "alpha": {}}]
    return JSONResponse({"personas": personas})

@router.get("/classification")
def classification():
    """
    Return thresholds for the 3-class labeling.
    Shape: {"rule_based":{"sustainable":{"max":0.33},"critical_transition":{"min":0.33,"max":0.67},"decommission":{"min":0.67}}}
    """
    if not CLASS_PATH.exists():
        # Provide sensible defaults
        return JSONResponse({"rule_based": {"sustainable": {"max": 0.33}, "critical_transition": {"min": 0.33, "max": 0.67}, "decommission": {"min": 0.67}}})
    cfg = _safe_yaml(CLASS_PATH)
    return JSONResponse(cfg)

@router.get("/years")
def years():
    """
    Return a best-effort set of available years by scanning CSV files for a 'year' column.
    Shape: {"years":[...]}
    """
    if not DATA_STATIC.exists():
        return JSONResponse({"years": []})
    years: Set[int] = set()
    # Prefer some known datasets, else fall back to any CSV with a 'year' column
    preferred = [
        DATA_STATIC / "emissions" / "annual-co2-emission.csv",
        DATA_STATIC / "artificial_support" / "coal-mining_country_emissions_v4_4_0.csv",
        DATA_STATIC / "infrastructure" / "global_coal_plant_tracker_data.csv",
    ]
    candidates = [p for p in preferred if p.exists()]
    if not candidates:
        candidates = list(DATA_STATIC.rglob("*.csv"))
    for path in candidates[:50]:  # cap to avoid huge scans
        try:
            df = pd.read_csv(path, usecols=lambda c: c.lower() in {"year", "refyear"}, low_memory=False)
            ycol = "year" if "year" in df.columns else ("refYear" if "refYear" in df.columns else None)
            if ycol:
                for v in pd.to_numeric(df[ycol], errors="coerce").dropna().astype(int).tolist():
                    if 1900 <= v <= 2100:
                        years.add(int(v))
        except Exception:
            continue
    out = sorted(years)
    return JSONResponse({"years": out})

# api/routers/export.py
from __future__ import annotations

import io
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import yaml
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

from services.data_access import DataAccess
from services.cache import get_cache, scenario_hash
from scoring.compute_scores import compute_scores_and_fvi
from scoring.normalization import renorm_weights

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/export", tags=["export"])

BASE_DIR = Path(__file__).resolve().parents[2]
FORMULAS_DIR = BASE_DIR / "config" / "formulas"
WEIGHTS_PATH = BASE_DIR / "config" / "weights.yaml"
EXPORT_DIR = Path(BASE_DIR / "runtime" / "exports")
EXPORT_DIR.mkdir(parents=True, exist_ok=True)


# ---------- Schemas ----------

class Filters(BaseModel):
    regions: Optional[List[str]] = Field(default=None)
    year: Optional[int | List[int]] = Field(default=None)

class ExportRequest(BaseModel):
    filters: Filters = Field(default_factory=Filters)
    alpha: Optional[Dict[str, float]] = None
    submetric_weights: Optional[Dict[str, Dict[str, float]]] = None
    normalization_overrides: Optional[Dict[str, Any]] = None
    format: str = Field(default="csv", pattern="^(csv|parquet)$")
    filename: Optional[str] = None  # optional base name (without extension)

class ExportResponse(BaseModel):
    filename: str
    path: str
    size_bytes: int


# ---------- Helpers ----------

def _list_scores() -> List[str]:
    return sorted([p.stem for p in FORMULAS_DIR.glob("*.yaml")])

def _default_alpha() -> Dict[str, float]:
    if WEIGHTS_PATH.exists():
        try:
            raw = yaml.safe_load(WEIGHTS_PATH.read_text(encoding="utf-8")) or {}
            a = raw.get("personas", {}).get("regular_citizen", {}).get("alpha", {})
            if a:
                # normalize to 1
                return renorm_weights(pd.Series(a)).to_dict()
        except Exception:
            pass
    names = _list_scores()
    if not names:
        return {}
    return {n: 1.0 / len(names) for n in names}

def _scores_to_frame(scores: Dict[str, pd.Series], fvi: pd.Series) -> pd.DataFrame:
    """
    Combine per-score series and FVI into a single DataFrame with columns:
      iso3, year, <score1>, <score2>, ..., FVI
    """
    if not scores and (fvi is None or fvi.empty):
        return pd.DataFrame(columns=["iso3", "year", "FVI"])
    # Align index
    idx = None
    for s in list(scores.values()) + [fvi]:
        if s is None or s.empty:
            continue
        idx = s.index if idx is None else idx.intersection(s.index)
    if idx is None or len(idx) == 0:
        return pd.DataFrame(columns=["iso3", "year", "FVI"])
    cols = {k: v.reindex(idx) for k, v in scores.items()}
    df = pd.DataFrame(cols, index=idx)
    df["FVI"] = fvi.reindex(idx)
    df = df.reset_index().rename(columns={"level_0": "iso3", "level_1": "year"})
    return df[["iso3", "year"] + sorted(scores.keys()) + ["FVI"]]


# ---------- Endpoints ----------

@router.post("/scores", response_model=ExportResponse)
def export_scores(
    req: ExportRequest,
    provider: DataAccess = Depends(lambda: DataAccess()),
):
    """
    Export per-score series and FVI for the given filters as CSV or Parquet.
    Returns a path to a file under runtime/exports/.
    """
    try:
        # Build cache key
        payload = {
            "filters": req.filters.model_dump(),
            "alpha": req.alpha or _default_alpha(),
            "submetric_weights": req.submetric_weights or {},
            "format": req.format,
        }
        key = "export:" + scenario_hash(payload)

        cache = get_cache()
        cached = cache.get(key)
        if cached and Path(cached.get("path", "")).exists():
            p = Path(cached["path"])
            return ExportResponse(filename=p.name, path=str(p), size_bytes=p.stat().st_size)

        score_names = _list_scores()
        if not score_names:
            raise HTTPException(status_code=500, detail="No score configs found under config/formulas")

        alpha = req.alpha or _default_alpha()
        scores, fvi = compute_scores_and_fvi(
            provider=provider,
            score_names=score_names,
            filters=req.filters.model_dump(),
            alpha=alpha,
            submetric_weights=req.submetric_weights,
            normalization_overrides=req.normalization_overrides,
        )
        df = _scores_to_frame(scores, fvi)
        if df.empty:
            raise HTTPException(status_code=400, detail="No data available for the given filters.")

        ts = time.strftime("%Y%m%d-%H%M%S")
        base = req.filename or f"fvi_export_{ts}"
        if req.format == "csv":
            path = EXPORT_DIR / f"{base}.csv"
            df.to_csv(path, index=False)
        else:
            path = EXPORT_DIR / f"{base}.parquet"
            try:
                df.to_parquet(path, index=False)
            except Exception as e:
                # Fallback to CSV if parquet engine missing
                logger.warning("Parquet export failed (%s); falling back to CSV.", e)
                path = EXPORT_DIR / f"{base}.csv"
                df.to_csv(path, index=False)

        out = {"filename": path.name, "path": str(path), "size_bytes": int(path.stat().st_size)}
        cache.set(key, out, ttl_seconds=600)
        return ExportResponse(**out)

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Export failed")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/download")
def download_file(filepath: str = Query(..., description="Absolute path returned by /export/scores")):
    p = Path(filepath)
    if not p.exists() or not p.is_file():
        raise HTTPException(status_code=404, detail="File not found.")
    media = "text/csv" if p.suffix.lower() == ".csv" else "application/octet-stream"
    return FileResponse(p, media_type=media, filename=p.name)

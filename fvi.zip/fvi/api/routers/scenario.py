# api/routers/scenario.py
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from services.scenario_store import ScenarioStore, Scope
from scoring.normalization import renorm_weights

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/scenario", tags=["scenario"])

# Singleton store
_STORE: Optional[ScenarioStore] = None

def _store() -> ScenarioStore:
    global _STORE
    if _STORE is None:
        _STORE = ScenarioStore()
    return _STORE


# ---------- Schemas ----------

class ScenarioMethod(BaseModel):
    aggregation: str = "weighted_mean"
    normalization: str = "minmax"

class Filters(BaseModel):
    regions: Optional[List[str]] = Field(default=None)
    year: Optional[int | List[int]] = Field(default=None)

class ScenarioCreate(BaseModel):
    persona: str = "regular_citizen"
    filters: Filters = Field(default_factory=Filters)
    alpha: Dict[str, float] = Field(default_factory=dict)
    sub_weights: Dict[str, Dict[str, float]] = Field(default_factory=dict)
    method: ScenarioMethod = Field(default_factory=ScenarioMethod)

class ScenarioOut(BaseModel):
    scenario_id: str
    persona: str
    filters: Dict[str, Any]
    alpha: Dict[str, float]
    sub_weights: Dict[str, Dict[str, float]]
    method: Dict[str, Any]
    created_at: float
    updated_at: float
    pending: Dict[str, Dict[str, Any]]

class ScenarioPatch(BaseModel):
    persona: Optional[str] = None
    filters: Optional[Filters] = None
    alpha: Optional[Dict[str, float]] = None
    sub_weights: Optional[Dict[str, Dict[str, float]]] = None
    method: Optional[ScenarioMethod] = None

class ProposalIn(BaseModel):
    scope: Scope
    targets: List[Dict[str, Any]]  # see store docstring for shapes

class ProposalOut(BaseModel):
    change_id: str
    scope: Scope
    preview: Dict[str, Any]

class CommitIn(BaseModel):
    change_id: str


# ---------- Endpoints ----------

@router.post("", response_model=ScenarioOut)
def create_scenario(body: ScenarioCreate, store: ScenarioStore = Depends(_store)) -> ScenarioOut:
    sc = store.create(
        persona=body.persona,
        filters=body.filters.model_dump(),
        alpha=body.alpha,
        sub_weights=body.sub_weights,
        method=body.method.model_dump(),
    )
    return ScenarioOut(**sc.__dict__)

@router.get("/{scenario_id}", response_model=ScenarioOut)
def get_scenario(scenario_id: str, store: ScenarioStore = Depends(_store)) -> ScenarioOut:
    sc = store.get(scenario_id)
    if not sc:
        raise HTTPException(status_code=404, detail="scenario not found")
    return ScenarioOut(**sc.__dict__)

@router.patch("/{scenario_id}", response_model=ScenarioOut)
def patch_scenario(scenario_id: str, body: ScenarioPatch, store: ScenarioStore = Depends(_store)) -> ScenarioOut:
    sc = store.update(
        scenario_id,
        persona=body.persona,
        filters=(body.filters.model_dump() if body.filters is not None else None),
        alpha=body.alpha,
        sub_weights=body.sub_weights,
        method=(body.method.model_dump() if body.method is not None else None),
    )
    return ScenarioOut(**sc.__dict__)

@router.post("/{scenario_id}/propose_weight_update", response_model=ProposalOut)
def propose_weight_update(scenario_id: str, body: ProposalIn, store: ScenarioStore = Depends(_store)) -> ProposalOut:
    try:
        res = store.propose_weight_update(scenario_id, scope=body.scope, targets=body.targets)
        return ProposalOut(change_id=res["change_id"], scope=res["scope"], preview=res["preview"])
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.exception("propose_weight_update failed")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{scenario_id}/commit_weight_update", response_model=ScenarioOut)
def commit_weight_update(scenario_id: str, body: CommitIn, store: ScenarioStore = Depends(_store)) -> ScenarioOut:
    try:
        sc = store.commit_weight_update(scenario_id, change_id=body.change_id)
        return ScenarioOut(**sc.__dict__)
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception("commit_weight_update failed")
        raise HTTPException(status_code=500, detail=str(e))


# ---------- Agent helpers (used by services/rag_agent.py) ----------

def propose_weight_update_for_agent(payload: Mapping[str, Any]) -> Dict[str, Any]:
    scenario_id = payload.get("scenario_id")
    scope = payload.get("scope")
    targets = payload.get("targets") or []
    if not scenario_id or not scope:
        raise ValueError("scenario_id and scope are required")
    store = _store()
    res = store.propose_weight_update(scenario_id, scope=scope, targets=targets)
    return {"change_id": res["change_id"], "preview": res["preview"], "scope": res["scope"]}

def commit_weight_update_for_agent(payload: Mapping[str, Any]) -> Dict[str, Any]:
    scenario_id = payload.get("scenario_id")
    change_id = payload.get("change_id")
    if not scenario_id or not change_id:
        raise ValueError("scenario_id and change_id are required")
    store = _store()
    sc = store.commit_weight_update(scenario_id, change_id=change_id)
    return {
        "scenario_id": sc.scenario_id,
        "alpha": sc.alpha,
        "sub_weights": sc.sub_weights,
        "updated_at": sc.updated_at,
    }

# api/routers/classify.py
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from services.data_access import DataAccess
from scoring.classify import classify_series
from scoring.compute_scores import load_score_cfg

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/classify", tags=["classify"])


# ---------- Schemas ----------

class Filters(BaseModel):
    regions: Optional[List[str]] = Field(default=None, description="ISO3 country codes")
    year: Optional[int | List[int]] = Field(default=None, description="Year or [start, end]")

class ClassifyRequest(BaseModel):
    filters: Filters = Field(default_factory=Filters)
    alpha: Optional[Dict[str, float]] = None
    submetric_weights: Optional[Dict[str, Dict[str, float]]] = None
    normalization_overrides: Optional[Dict[str, Any]] = None

class ClassPoint(BaseModel):
    iso3: str
    year: int
    fvi: float
    label: str
    p_sustainable: float
    p_critical_transition: float
    p_decommission: float

class ClassifyResponse(BaseModel):
    results: List[ClassPoint]
    meta: Dict[str, Any]


# ---------- Endpoint ----------

@router.post("", response_model=ClassifyResponse)
def classify(
    req: ClassifyRequest,
    provider: DataAccess = Depends(lambda: DataAccess()),
) -> ClassifyResponse:
    try:
        score_names = [p.stem for p in (Path(__file__).resolve().parents[2] / "config" / "formulas").glob("*.yaml")]
        alpha = req.alpha or {}  # will default internally
        df = classify_series(
            provider=provider,
            score_names=score_names,
            filters=req.filters.model_dump(),
            alpha=alpha,
            submetric_weights=req.submetric_weights,
            normalization_overrides=req.normalization_overrides,
        )
        points = []
        for (iso3, year), row in df.reset_index().iterrows():
            points.append(
                ClassPoint(
                    iso3=row["iso3"],
                    year=int(row["year"]),
                    fvi=row["fvi"],
                    label=row["label"],
                    p_sustainable=row["p_sustainable"],
                    p_critical_transition=row["p_critical_transition"],
                    p_decommission=row["p_decommission"],
                )
            )
        return ClassifyResponse(results=points, meta={"count": len(points)})
    except Exception as e:
        logger.exception("Classification failed")
        raise HTTPException(status_code=500, detail=str(e))


# ----- Agent helper -----

def classify_for_agent(payload: Mapping[str, Any]) -> Dict[str, Any]:
    filters = payload.get("filters") or {}
    req = ClassifyRequest(filters=Filters(**filters))
    res = classify(req)  # type: ignore
    # Return only the first point for brevity
    pt = res.results[0] if res.results else None
    return pt.model_dump() if pt else {}

# api/routers/geo.py
from __future__ import annotations

import json
import logging
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/geo", tags=["geo"])

BASE_DIR = Path(__file__).resolve().parents[2]
REGIONS_PATH = BASE_DIR / "config" / "regions.geojson"


@lru_cache(maxsize=1)
def _load_regions() -> Dict[str, Any]:
    if not REGIONS_PATH.exists():
        raise FileNotFoundError(f"regions.geojson not found at {REGIONS_PATH}")
    try:
        text = REGIONS_PATH.read_text(encoding="utf-8")
        data = json.loads(text)
        # Minimal validation
        if data.get("type") != "FeatureCollection":
            raise ValueError("regions.geojson must be a GeoJSON FeatureCollection")
        return data
    except Exception as e:
        raise RuntimeError(f"Failed to load regions.geojson: {e}") from e


def _iso_name_from_props(props: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    """
    Try common property names to get (iso3, name).
    """
    iso = (
        props.get("iso3")
        or props.get("ISO3")
        or props.get("ISO_A3")
        or props.get("ADM0_A3")
        or props.get("ADM0_A3_US")
        or props.get("SOV_A3")
    )
    if iso:
        iso = str(iso).upper().strip()
    name = (
        props.get("name")
        or props.get("NAME")
        or props.get("ADMIN")
        or props.get("COUNTRY")
        or props.get("SOVEREIGNT")
    )
    name = str(name).strip() if name else None
    return iso, name


@router.get("/regions")
def regions():
    """
    Returns the full regions GeoJSON for client-side rendering.
    """
    try:
        data = _load_regions()
        return JSONResponse(data)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception("Failed to serve regions")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/iso-index")
def iso_index():
    """
    Returns a compact ISO3 → name mapping derived from regions.geojson.
    Useful for dropdowns and legends.
    """
    try:
        data = _load_regions()
        out: Dict[str, str] = {}
        for feat in data.get("features", []):
            if not isinstance(feat, dict):
                continue
            props = feat.get("properties") or {}
            iso, name = _iso_name_from_props(props)
            if iso:
                out[iso] = name or iso
        return JSONResponse(out)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception("/geo/iso-index error")
        raise HTTPException(status_code=500, detail=str(e))

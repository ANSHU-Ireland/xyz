# api/routers/chat.py
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from services.rag_agent import AgentRequest, chat as agent_chat

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/chat", tags=["chat"])


class ChatRequest(BaseModel):
    session_id: str = Field(..., description="Ephemeral session ID from frontend")
    message: str
    persona: Optional[str] = "regular_citizen"
    scenario_id: Optional[str] = None
    filters: Optional[Dict[str, Any]] = None


class ChatResponse(BaseModel):
    text: str
    citations: list[dict]
    tool_calls: list[dict]
    tool_results: list[dict]
    state: dict


@router.post("", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    try:
        ar = AgentRequest(
            session_id=req.session_id,
            message=req.message,
            persona=req.persona or "regular_citizen",
            scenario_id=req.scenario_id,
            filters=req.filters or {},
        )
        res = agent_chat(ar)
        return ChatResponse(
            text=res.text,
            citations=res.citations,
            tool_calls=res.tool_calls,
            tool_results=res.tool_results,
            state=res.state,
        )
    except Exception as e:
        logger.exception("Chat failed")
        raise HTTPException(status_code=500, detail=str(e))

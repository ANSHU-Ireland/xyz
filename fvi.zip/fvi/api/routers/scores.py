# api/routers/scores.py
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

import pandas as pd
import yaml
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from scoring.compute_scores import compute_scores_and_fvi, load_score_cfg
from services.data_access import DataAccess
from scoring.normalization import renorm_weights

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/scores", tags=["scores"])

BASE_DIR = Path(__file__).resolve().parents[2]
FORMULAS_DIR = BASE_DIR / "config" / "formulas"
WEIGHTS_PATH = BASE_DIR / "config" / "weights.yaml"


# ---------- Schemas ----------

class Filters(BaseModel):
    regions: Optional[List[str]] = Field(default=None, description="ISO3 country codes")
    year: Optional[int | List[int]] = Field(default=None, description="Year or [start, end]")

class ScoresRequest(BaseModel):
    scenario_id: Optional[str] = None
    filters: Filters = Field(default_factory=Filters)
    alpha: Optional[Dict[str, float]] = None
    submetric_weights: Optional[Dict[str, Dict[str, float]]] = None
    normalization_overrides: Optional[Dict[str, Any]] = None

class SeriesPoint(BaseModel):
    iso3: str
    year: int
    value: float

class ScoreSeries(BaseModel):
    score: str
    series: List[SeriesPoint]

class ScoresResponse(BaseModel):
    scores: List[ScoreSeries]
    fvi: List[SeriesPoint]
    coverage: Dict[str, float]  # per-score % non-null
    meta: Dict[str, Any]


# ---------- Helpers ----------

def _list_score_names() -> List[str]:
    return sorted([p.stem for p in FORMULAS_DIR.glob("*.yaml")])

def _load_default_alpha() -> Dict[str, float]:
    if not WEIGHTS_PATH.exists():
        names = _list_score_names()
        if not names:
            return {}
        return {n: 1.0 / len(names) for n in names}
    with open(WEIGHTS_PATH, "r", encoding="utf-8") as f:
        w = yaml.safe_load(f) or {}
    alpha = (
        w.get("personas", {})
         .get("regular_citizen", {})
         .get("alpha", {})
    )
    if not alpha:
        names = _list_score_names()
        alpha = {n: 1.0 / len(names) for n in names}
    return alpha

def _series_to_points(s: pd.Series) -> List[SeriesPoint]:
    if s is None or s.empty:
        return []
    points: List[SeriesPoint] = []
    for (iso3, year), val in s.dropna().items():
        points.append(SeriesPoint(iso3=str(iso3), year=int(year), value=float(val)))
    return points

def _pct_nonnull(s: pd.Series) -> float:
    if s is None or len(s) == 0:
        return 0.0
    return float(100.0 * s.notna().mean())


# ---------- Endpoints ----------

@router.post("", response_model=ScoresResponse)
def get_scores(req: ScoresRequest, provider: DataAccess = Depends(lambda: DataAccess())) -> ScoresResponse:
    try:
        score_names = _list_score_names()
        if not score_names:
            raise HTTPException(status_code=500, detail="No score configs found under config/formulas")

        alpha = renorm_weights(pd.Series(req.alpha or _load_default_alpha())).to_dict()
        scores_dict, fvi = compute_scores_and_fvi(
            provider=provider,
            score_names=score_names,
            filters=req.filters.model_dump(),
            alpha=alpha,
            submetric_weights=req.submetric_weights,
            normalization_overrides=req.normalization_overrides,
        )

        # Coverage per score
        coverage = {k: _pct_nonnull(v) for k, v in scores_dict.items()}

        return ScoresResponse(
            scores=[
                ScoreSeries(score=k, series=_series_to_points(v))
                for k, v in scores_dict.items()
            ],
            fvi=_series_to_points(fvi),
            coverage=coverage,
            meta={"alpha": alpha, "scores": score_names},
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to compute scores")
        raise HTTPException(status_code=500, detail=str(e))


# ---------- Agent helpers (for RAG tools) ----------

def get_scores_for_agent(payload: Mapping[str, Any]) -> Dict[str, Any]:
    """
    Lightweight adapter used by services/rag_agent.py tool calls.
    """
    filters = payload.get("filters") or {}
    req = ScoresRequest(
        scenario_id=payload.get("scenario_id"),
        filters=Filters(**filters),
        alpha=None,  # use defaults unless the scenario service injects
        submetric_weights=None,
        normalization_overrides=None,
    )
    # Call the same path as the endpoint (bypassing HTTP)
    res = get_scores(req)  # type: ignore
    return {
        "scores": [dict(score=s.score, series=[p.model_dump() for p in s.series]) for s in res.scores],
        "fvi": [p.model_dump() for p in res.fvi],
        "coverage": res.coverage,
        "meta": res.meta,
    }


# ---------- /api/explain (inline explanation for now) ----------

class ExplainRequest(BaseModel):
    scenario_id: Optional[str] = None
    filters: Filters = Field(default_factory=Filters)
    alpha: Optional[Dict[str, float]] = None
    submetric_weights: Optional[Dict[str, Dict[str, float]]] = None

class Contribution(BaseModel):
    id: str
    contribution: float

class ScoreBreakdown(BaseModel):
    score: str
    score_value: float
    alpha: float
    contributions: List[Contribution]  # submetric-level

class ExplainResponse(BaseModel):
    region: str
    year: int
    fvi: float
    scores: List[ScoreBreakdown]


@router.post("/explain", response_model=ExplainResponse)
def explain(req: ExplainRequest, provider: DataAccess = Depends(lambda: DataAccess())) -> ExplainResponse:
    """
    Linear contribution breakdown:
      - For each score k: S_k = Σ_j w_kj * m_kj
      - FVI = Σ_k α_k * S_k
    We report α_k, S_k, and α_k * w_kj * m_kj contributions per submetric.
    """
    try:
        score_names = _list_score_names()
        alpha = renorm_weights(pd.Series(req.alpha or _load_default_alpha())).reindex(score_names).fillna(0.0)

        # Build all normalized submetrics again (so we can compute sub-level contributions)
        # Reuse compute_scores logic, but return normalized submetric frames:
        sm_frames: Dict[str, pd.DataFrame] = {}
        scores_values: Dict[str, pd.Series] = {}

        from scoring.compute_scores import ScoreEngine, load_score_cfg
        engine = ScoreEngine(provider)

        # Collect submetric weights
        sm_weights_map: Dict[str, Dict[str, float]] = {}
        for name in score_names:
            cfg = load_score_cfg(name)
            # submetric weights: request override OR defaults
            w = (req.submetric_weights or {}).get(name, {})
            for sm in cfg.submetrics:
                w.setdefault(sm.id, float(sm.weight_default))
            sm_weights_map[name] = w

            # fetch normalized submetrics
            sm_norm: Dict[str, pd.Series] = {}
            for sm in cfg.submetrics:
                raw = provider.submetric_series(name, sm.id, cfg={"source": sm.source, "column": sm.column, "transform": sm.transform, "direction": sm.direction}, filters=req.filters.model_dump())
                from scoring.normalization import NormConfig, normalize_series
                norm = normalize_series(raw, direction=sm.direction, cfg=NormConfig(method=cfg.normalization))
                sm_norm[sm.id] = norm
            df = _align_columns(sm_norm)
            sm_frames[name] = df
            # compute S_k
            from scoring.normalization import renorm_weights, weighted_mean
            w_ser = renorm_weights(pd.Series(sm_weights_map[name])).reindex(df.columns).fillna(0.0)
            scores_values[name] = weighted_mean(df, w_ser).rename(name)

        # Choose a single (region, year) to report: prefer explicit, else first common
        idx = None
        for s in scores_values.values():
            idx = s.index if idx is None else idx.intersection(s.index)
        if idx is None or len(idx) == 0:
            raise HTTPException(status_code=400, detail="No overlapping data for explanation under provided filters")

        # Pick first index unless user specified a single region/year
        if req.filters.regions and len(req.filters.regions) == 1 and isinstance(req.filters.year, int):
            target = (req.filters.regions[0], int(req.filters.year))
        else:
            target = idx[0]  # first available (iso3, year)

        iso3, year = str(target[0]), int(target[1])

        # Assemble response
        scores_out: List[ScoreBreakdown] = []
        fvi_val = 0.0
        for name in score_names:
            s_val = float(scores_values[name].get(target, float("nan")))
            a_k = float(alpha.get(name, 0.0))
            fvi_val += a_k * (s_val if np.isfinite(s_val) else 0.0)

            df = sm_frames[name]
            if target not in df.index:
                contribs = []
            else:
                row = df.loc[target]  # submetric values m_kj
                w_ser = renorm_weights(pd.Series(sm_weights_map[name])).reindex(df.columns).fillna(0.0)
                contrib_vals = (a_k * w_ser * row).fillna(0.0).to_dict()
                contribs = [Contribution(id=k, contribution=float(v)) for k, v in sorted(contrib_vals.items(), key=lambda kv: -kv[1])]

            scores_out.append(ScoreBreakdown(score=name, score_value=s_val, alpha=a_k, contributions=contribs))

        return ExplainResponse(region=iso3, year=year, fvi=fvi_val, scores=scores_out)

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to build explanation")
        raise HTTPException(status_code=500, detail=str(e))


# Agent helper

def get_explanation_for_agent(payload: Mapping[str, Any]) -> Dict[str, Any]:
    filters = payload.get("filters") or {}
    req = ExplainRequest(filters=Filters(**filters))
    res = explain(req)  # type: ignore
    return res.model_dump()


# ----- local helpers -----

def _align_columns(series_dict: Mapping[str, pd.Series]) -> pd.DataFrame:
    if not series_dict:
        return pd.DataFrame()
    common_idx = None
    for s in series_dict.values():
        common_idx = s.index if common_idx is None else common_idx.intersection(s.index)
    if common_idx is None or len(common_idx) == 0:
        return pd.DataFrame()
    cols = {k: v.reindex(common_idx) for k, v in series_dict.items()}
    return pd.DataFrame(cols, index=common_idx)

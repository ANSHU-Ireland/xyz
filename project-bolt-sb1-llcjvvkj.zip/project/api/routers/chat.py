from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import os
import google.generativeai as genai

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    conversation_id: str

class ChatResponse(BaseModel):
    response: str
    citations: Optional[List[str]] = None
    conversation_id: str

# Configure Gemini
GEMINI_API_KEY = "AIzaSyCbXYrPJz7gbgzsiU2sAmyeHl0EEP-zo4o"
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

@router.post("/chat", response_model=ChatResponse)
async def chat_with_assistant(request: ChatRequest):
    """Chat with the FVI Assistant using RAG and Gemini Flash 2.0."""
    try:
        if not GEMINI_API_KEY:
            # Return mock response if no API key
            return generate_mock_response(request.message, request.conversation_id)
        
        # Initialize Gemini model
        model = genai.GenerativeModel('gemini-2.0-flash-exp')
        
        # Enhanced system prompt with FVI context
        system_prompt = f"""
        You are an expert assistant for the Fossil Fuel Vulnerability Index (FVI) Dashboard. 
        You help users understand FVI data, scoring methodologies, and country-specific analyses.

        Key Information:
        - FVI measures countries' vulnerability to fossil fuel risks across 7 themes
        - Themes: Artificial Support, Ecological, Emissions, Infrastructure, Economic, Necessity, Scarcity
        - Scale: 0 (least vulnerable) to 1 (most vulnerable)
        - Classifications: Sustainable (0.0-0.3), Critical Transition (0.3-0.7), Decommission (0.7-1.0)
        
        User Query: {request.message}
        
        Provide helpful, accurate information about FVI data and methodologies. 
        If you're unsure about specific data points, acknowledge limitations and focus on explaining concepts.
        """
        
        # Generate response
        response = model.generate_content(system_prompt)
        
        # Mock citations for demo
        citations = [
            "FVI Methodology Documentation v2.1",
            "Theme-specific Scoring Guidelines",
            "Country Assessment Database"
        ]
        
        return ChatResponse(
            response=response.text,
            citations=citations,
            conversation_id=request.conversation_id
        )
        
    except Exception as e:
        print(f"Chat error: {e}")
        # Fallback to mock response
        return generate_mock_response(request.message, request.conversation_id)

def generate_mock_response(message: str, conversation_id: str) -> ChatResponse:
    """Generate mock response for demo purposes."""
    message_lower = message.lower()
    
    if any(word in message_lower for word in ['fvi', 'vulnerability', 'index']):
        response = """The Fossil Fuel Vulnerability Index (FVI) is a comprehensive assessment tool that measures countries' exposure to risks associated with fossil fuel dependence. It evaluates vulnerability across seven key themes:

1. **Artificial Support** - Government policies and subsidies
2. **Ecological** - Environmental impact and degradation
3. **Emissions** - Carbon footprint and climate contributions
4. **Infrastructure** - Dependence on fossil fuel infrastructure
5. **Economic** - Financial exposure to fossil fuel markets
6. **Necessity** - Energy security and dependency
7. **Scarcity** - Resource availability and depletion risks

The FVI score ranges from 0 (least vulnerable) to 1 (most vulnerable), with countries classified as Sustainable, Critical Transition, or Decommission based on their scores."""
        
    elif any(word in message_lower for word in ['artificial support', 'policy', 'government']):
        response = """The Artificial Support theme evaluates government policies, regulations, and subsidies related to fossil fuel dependency. Key components include:

- **Policy Strength Index (AS1)**: Measures the strength of coal phase-out commitments and timelines
- **Emissions-Weighted Support (AS2)**: Considers mining emissions in relation to policy support

Countries with stronger phase-out policies and reduced subsidies score better (lower vulnerability) in this theme. This theme accounts for 15% of the default FVI weighting."""
        
    elif any(word in message_lower for word in ['methodology', 'calculate', 'scoring']):
        response = """FVI scores are calculated through a multi-step process:

1. **Data Collection**: Raw data gathered from multiple international sources
2. **Normalization**: Each metric normalized using min-max scaling (0-1 range)
3. **Theme Aggregation**: Sub-metrics combined into theme scores using weighted averages
4. **FVI Calculation**: Seven theme scores combined using configurable weights
5. **Classification**: Final scores classified into sustainability categories

Default theme weights: Artificial Support (15%), Ecological (15%), Emissions (15%), Infrastructure (15%), Economic (15%), Necessity (15%), Scarcity (10%). Users can adjust these weights for scenario analysis."""
        
    else:
        response = """I'm here to help you understand the FVI Dashboard and its data. You can ask me about:

- **Country Analysis**: Specific country vulnerability assessments
- **Theme Explanations**: Details about the seven FVI themes
- **Methodology**: How scores are calculated and normalized  
- **Classifications**: Understanding sustainability categories
- **Data Sources**: Information about underlying datasets
- **Trends**: Historical patterns and projections

What would you like to explore?"""
    
    citations = [
        "FVI Technical Documentation",
        "Scoring Methodology Guide", 
        "Theme Assessment Framework"
    ]
    
    return ChatResponse(
        response=response,
        citations=citations,
        conversation_id=conversation_id
    )
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Dict, Any

router = APIRouter()

class ConfigResponse(BaseModel):
    themes: List[str]
    default_weights: Dict[str, float]
    personas: List[Dict[str, Any]]
    available_years: List[int]
    classification_thresholds: Dict[str, Dict[str, float]]

@router.get("/config", response_model=ConfigResponse)
async def get_config():
    """Get dashboard configuration including themes, weights, and personas."""
    return ConfigResponse(
        themes=[
            "artificial_support",
            "ecological", 
            "emissions",
            "infrastructure",
            "economic",
            "necessity",
            "scarcity"
        ],
        default_weights={
            "artificial_support": 0.15,
            "ecological": 0.15,
            "emissions": 0.15,
            "infrastructure": 0.15,
            "economic": 0.15,
            "necessity": 0.15,
            "scarcity": 0.10
        },
        personas=[
            {
                "name": "Climate Policy Analyst",
                "weights": {
                    "artificial_support": 0.25,
                    "ecological": 0.20,
                    "emissions": 0.25,
                    "infrastructure": 0.10,
                    "economic": 0.10,
                    "necessity": 0.05,
                    "scarcity": 0.05
                }
            },
            {
                "name": "Energy Security Expert", 
                "weights": {
                    "artificial_support": 0.10,
                    "ecological": 0.05,
                    "emissions": 0.10,
                    "infrastructure": 0.25,
                    "economic": 0.20,
                    "necessity": 0.25,
                    "scarcity": 0.05
                }
            },
            {
                "name": "Economic Transition Planner",
                "weights": {
                    "artificial_support": 0.20,
                    "ecological": 0.10,
                    "emissions": 0.15,
                    "infrastructure": 0.15,
                    "economic": 0.30,
                    "necessity": 0.05,
                    "scarcity": 0.05
                }
            }
        ],
        available_years=list(range(2020, 2025)),
        classification_thresholds={
            "sustainable": {"min": 0.0, "max": 0.3},
            "critical_transition": {"min": 0.3, "max": 0.7}, 
            "decommission": {"min": 0.7, "max": 1.0}
        }
    )

@router.get("/config/themes")
async def get_themes():
    """Get list of FVI themes."""
    return {
        "themes": [
            {
                "id": "artificial_support",
                "name": "Artificial Support",
                "description": "Government policies and regulatory support for fossil fuel transition"
            },
            {
                "id": "ecological", 
                "name": "Ecological Impact",
                "description": "Environmental degradation and ecosystem damage from fossil fuel extraction"
            },
            {
                "id": "emissions",
                "name": "Emissions Profile", 
                "description": "Carbon emissions and climate change contributions"
            },
            {
                "id": "infrastructure",
                "name": "Infrastructure Dependence",
                "description": "Physical asset dependence on fossil fuel infrastructure"
            },
            {
                "id": "economic",
                "name": "Economic Exposure",
                "description": "Financial vulnerability to fossil fuel market fluctuations"
            },
            {
                "id": "necessity",
                "name": "Energy Necessity",
                "description": "Dependence on fossil fuels for energy security"
            },
            {
                "id": "scarcity",
                "name": "Resource Scarcity", 
                "description": "Availability and depletion risks of fossil fuel resources"
            }
        ]
    }
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

router = APIRouter()

class GeoFeature(BaseModel):
    type: str = "Feature"
    properties: Dict[str, Any]
    geometry: Dict[str, Any]

class GeoResponse(BaseModel):
    type: str = "FeatureCollection"
    features: List[GeoFeature]

@router.get("/geo/regions", response_model=GeoResponse)
async def get_regions():
    """Get GeoJSON data for world regions with FVI scores."""
    # Mock GeoJSON data for demo
    features = []
    
    countries = [
        {"iso3": "USA", "name": "United States", "fvi": 0.45},
        {"iso3": "CHN", "name": "China", "fvi": 0.72}, 
        {"iso3": "IND", "name": "India", "fvi": 0.58},
        {"iso3": "DEU", "name": "Germany", "fvi": 0.28},
        {"iso3": "JPN", "name": "Japan", "fvi": 0.42},
        {"iso3": "GBR", "name": "United Kingdom", "fvi": 0.35},
        {"iso3": "FRA", "name": "France", "fvi": 0.31},
        {"iso3": "CAN", "name": "Canada", "fvi": 0.52}, 
        {"iso3": "AUS", "name": "Australia", "fvi": 0.67},
        {"iso3": "BRA", "name": "Brazil", "fvi": 0.48}
    ]
    
    for country in countries:
        # Simplified geometry - in production this would be actual country boundaries
        feature = GeoFeature(
            properties={
                "iso3": country["iso3"],
                "name": country["name"],
                "fvi": country["fvi"],
                "classification": "sustainable" if country["fvi"] < 0.3 else "critical_transition" if country["fvi"] < 0.7 else "decommission"
            },
            geometry={
                "type": "Polygon",
                "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 1], [0, 0]]]  # Placeholder geometry
            }
        )
        features.append(feature)
    
    return GeoResponse(features=features)

@router.get("/geo/bounds")
async def get_map_bounds():
    """Get geographical bounds for map display."""
    return {
        "bounds": {
            "north": 85,
            "south": -85, 
            "east": 180,
            "west": -180
        },
        "center": {
            "lat": 0,
            "lng": 0
        },
        "zoom": 2
    }
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any, Tuple
import random

router = APIRouter()

class ScoreRequest(BaseModel):
    regions: Optional[List[str]] = None
    year_range: Optional[Tuple[int, int]] = None
    weights: Optional[Dict[str, float]] = None

class CountryScore(BaseModel):
    iso3: str
    name: str
    fvi: float
    classification: str
    year: int
    themes: Dict[str, float]

class ScoreResponse(BaseModel):
    countries: List[CountryScore]
    coverage: Dict[str, Any]

class ExplainRequest(BaseModel):
    iso3: str
    year: int

class ExplainResponse(BaseModel):
    country: str
    iso3: str
    year: int
    fvi: float
    classification: str
    themes: Dict[str, float]
    weights: Dict[str, float]
    methodology: str

@router.post("/scores", response_model=ScoreResponse)
async def get_scores(request: ScoreRequest):
    """Get FVI scores for countries with optional filtering and weight overrides."""
    try:
        # Default weights
        default_weights = {
            "artificial_support": 0.15,
            "ecological": 0.15,
            "emissions": 0.15,
            "infrastructure": 0.15,
            "economic": 0.15,
            "necessity": 0.15,
            "scarcity": 0.10
        }
        
        weights = request.weights or default_weights
        year_range = request.year_range or (2024, 2024)
        
        # Mock country data
        countries_data = [
            {"iso3": "USA", "name": "United States"},
            {"iso3": "CHN", "name": "China"},
            {"iso3": "IND", "name": "India"},
            {"iso3": "DEU", "name": "Germany"},
            {"iso3": "JPN", "name": "Japan"},
            {"iso3": "GBR", "name": "United Kingdom"},
            {"iso3": "FRA", "name": "France"},
            {"iso3": "CAN", "name": "Canada"},
            {"iso3": "AUS", "name": "Australia"},
            {"iso3": "BRA", "name": "Brazil"},
            {"iso3": "RUS", "name": "Russia"},
            {"iso3": "MEX", "name": "Mexico"},
            {"iso3": "KOR", "name": "South Korea"},
            {"iso3": "IDN", "name": "Indonesia"},
            {"iso3": "TUR", "name": "Turkey"}
        ]
        
        countries = []
        for country in countries_data:
            # Generate theme scores
            themes = {
                "artificial_support": random.uniform(0.1, 0.9),
                "ecological": random.uniform(0.1, 0.9),
                "emissions": random.uniform(0.1, 0.9),
                "infrastructure": random.uniform(0.1, 0.9),
                "economic": random.uniform(0.1, 0.9),
                "necessity": random.uniform(0.1, 0.9),
                "scarcity": random.uniform(0.1, 0.9)
            }
            
            # Calculate weighted FVI
            fvi = sum(themes[theme] * weights[theme] for theme in themes.keys())
            
            # Classify
            if fvi < 0.3:
                classification = "sustainable"
            elif fvi < 0.7:
                classification = "critical_transition"
            else:
                classification = "decommission"
            
            countries.append(CountryScore(
                iso3=country["iso3"],
                name=country["name"],
                fvi=fvi,
                classification=classification,
                year=year_range[1],
                themes=themes
            ))
        
        coverage = {
            "total_countries": len(countries),
            "data_completeness": 0.95,
            "year_range": year_range
        }
        
        return ScoreResponse(countries=countries, coverage=coverage)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/scores/explain", response_model=ExplainResponse)
async def explain_score(request: ExplainRequest):
    """Get detailed explanation of FVI score for a specific country and year."""
    try:
        # Mock data for explanation
        themes = {
            "artificial_support": random.uniform(0.1, 0.9),
            "ecological": random.uniform(0.1, 0.9),
            "emissions": random.uniform(0.1, 0.9),
            "infrastructure": random.uniform(0.1, 0.9),
            "economic": random.uniform(0.1, 0.9),
            "necessity": random.uniform(0.1, 0.9),
            "scarcity": random.uniform(0.1, 0.9)
        }
        
        weights = {
            "artificial_support": 0.15,
            "ecological": 0.15,
            "emissions": 0.15,
            "infrastructure": 0.15,
            "economic": 0.15,
            "necessity": 0.15,
            "scarcity": 0.10
        }
        
        fvi = sum(themes[theme] * weights[theme] for theme in themes.keys())
        
        if fvi < 0.3:
            classification = "sustainable"
        elif fvi < 0.7:
            classification = "critical_transition"
        else:
            classification = "decommission"
        
        country_names = {
            "USA": "United States",
            "CHN": "China",
            "IND": "India",
            "DEU": "Germany",
            "JPN": "Japan"
        }
        
        methodology = f"""
        FVI Score Calculation for {request.iso3}:
        
        The FVI score is computed as a weighted average of seven theme scores:
        {chr(10).join([f'• {theme.replace("_", " ").title()}: {themes[theme]:.3f} × {weights[theme]:.2f} = {themes[theme] * weights[theme]:.3f}' for theme in themes.keys()])}
        
        Total FVI Score: {fvi:.3f}
        Classification: {classification.replace('_', ' ').title()}
        
        Each theme score is normalized between 0-1, where higher values indicate greater vulnerability.
        """
        
        return ExplainResponse(
            country=country_names.get(request.iso3, request.iso3),
            iso3=request.iso3,
            year=request.year,
            fvi=fvi,
            classification=classification,
            themes=themes,
            weights=weights,
            methodology=methodology.strip()
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
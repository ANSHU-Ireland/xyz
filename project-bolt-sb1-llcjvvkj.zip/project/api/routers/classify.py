from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

class ClassificationResponse(BaseModel):
    iso3: str
    year: int
    fvi: float
    label: str
    probabilities: dict
    thresholds: dict

@router.get("/classify", response_model=ClassificationResponse)
async def classify_country(
    iso3: str = Query(..., description="ISO3 country code"),
    year: int = Query(..., description="Year for classification")
):
    """Classify a country's FVI score into sustainability categories."""
    try:
        # Mock FVI calculation
        import random
        fvi = random.uniform(0.1, 0.9)
        
        # Classification thresholds
        thresholds = {
            "sustainable": {"min": 0.0, "max": 0.3},
            "critical_transition": {"min": 0.3, "max": 0.7},
            "decommission": {"min": 0.7, "max": 1.0}
        }
        
        # Hard classification
        if fvi < 0.3:
            label = "sustainable"
        elif fvi < 0.7:
            label = "critical_transition"
        else:
            label = "decommission"
        
        # Soft probabilities (triangular membership functions)
        def triangular_membership(x, center, width):
            return max(0, 1 - abs(x - center) / width)
        
        probabilities = {
            "sustainable": triangular_membership(fvi, 0.15, 0.3),
            "critical_transition": triangular_membership(fvi, 0.5, 0.4),
            "decommission": triangular_membership(fvi, 0.85, 0.3)
        }
        
        # Normalize probabilities
        total_prob = sum(probabilities.values())
        if total_prob > 0:
            probabilities = {k: v/total_prob for k, v in probabilities.items()}
        
        return ClassificationResponse(
            iso3=iso3,
            year=year,
            fvi=fvi,
            label=label,
            probabilities=probabilities,
            thresholds=thresholds
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
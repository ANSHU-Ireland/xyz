from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional, Tuple, List
import json
import csv
import io

router = APIRouter()

class ExportRequest(BaseModel):
    format: str  # csv, json, parquet
    year_range: Optional[Tuple[int, int]] = None
    regions: Optional[List[str]] = None
    include_themes: bool = True
    include_metadata: bool = True

@router.post("/export")
async def export_data(request: ExportRequest):
    """Export FVI data in various formats."""
    try:
        # Mock data for export
        data = [
            {
                "iso3": "USA",
                "country": "United States", 
                "year": 2024,
                "fvi": 0.45,
                "classification": "critical_transition",
                "artificial_support": 0.42,
                "ecological": 0.38,
                "emissions": 0.55,
                "infrastructure": 0.48,
                "economic": 0.51,
                "necessity": 0.44,
                "scarcity": 0.37
            },
            {
                "iso3": "CHN",
                "country": "China",
                "year": 2024, 
                "fvi": 0.72,
                "classification": "decommission",
                "artificial_support": 0.68,
                "ecological": 0.81,
                "emissions": 0.89,
                "infrastructure": 0.75,
                "economic": 0.62,
                "necessity": 0.71,
                "scarcity": 0.58
            },
            {
                "iso3": "DEU",
                "country": "Germany",
                "year": 2024,
                "fvi": 0.28,
                "classification": "sustainable", 
                "artificial_support": 0.22,
                "ecological": 0.31,
                "emissions": 0.35,
                "infrastructure": 0.28,
                "economic": 0.25,
                "necessity": 0.32,
                "scarcity": 0.23
            }
        ]
        
        # Filter data based on request
        if request.year_range:
            data = [d for d in data if request.year_range[0] <= d["year"] <= request.year_range[1]]
        
        if request.regions:
            data = [d for d in data if d["iso3"] in request.regions]
        
        # Remove theme columns if not requested
        if not request.include_themes:
            theme_cols = ["artificial_support", "ecological", "emissions", "infrastructure", "economic", "necessity", "scarcity"]
            for item in data:
                for col in theme_cols:
                    item.pop(col, None)
        
        # Export based on format
        if request.format.lower() == "csv":
            return export_csv(data)
        elif request.format.lower() == "json":
            return export_json(data, request.include_metadata)
        elif request.format.lower() == "parquet":
            # For demo, return JSON with parquet-like structure
            return export_json(data, request.include_metadata)
        else:
            raise HTTPException(status_code=400, detail="Unsupported format")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def export_csv(data):
    """Export data as CSV."""
    if not data:
        raise HTTPException(status_code=400, detail="No data to export")
    
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=data[0].keys())
    writer.writeheader()
    writer.writerows(data)
    
    output.seek(0)
    return StreamingResponse(
        io.BytesIO(output.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=fvi_export.csv"}
    )

def export_json(data, include_metadata=True):
    """Export data as JSON."""
    result = {
        "data": data,
        "count": len(data)
    }
    
    if include_metadata:
        result["metadata"] = {
            "export_timestamp": "2024-01-15T10:30:00Z",
            "version": "1.0.0",
            "description": "FVI Dashboard export",
            "themes": [
                "artificial_support", "ecological", "emissions", 
                "infrastructure", "economic", "necessity", "scarcity"
            ],
            "classification_thresholds": {
                "sustainable": {"min": 0.0, "max": 0.3},
                "critical_transition": {"min": 0.3, "max": 0.7},
                "decommission": {"min": 0.7, "max": 1.0}
            }
        }
    
    json_str = json.dumps(result, indent=2)
    return StreamingResponse(
        io.BytesIO(json_str.encode()),
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=fvi_export.json"}
    )
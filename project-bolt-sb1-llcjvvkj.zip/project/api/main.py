from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os
from pathlib import Path

from .routers import scores, classify, chat, config, geo, export

app = FastAPI(title="FVI Dashboard API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(scores.router, prefix="/api")
app.include_router(classify.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(config.router, prefix="/api")
app.include_router(geo.router, prefix="/api")
app.include_router(export.router, prefix="/api")

# Serve frontend static files
frontend_dist = Path("dist")
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory="dist", html=True), name="static")

@app.get("/")
async def root():
    if frontend_dist.exists():
        return FileResponse("dist/index.html")
    return {"message": "FVI Dashboard API is running. Build the frontend to serve the full application."}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "FVI Dashboard API"}
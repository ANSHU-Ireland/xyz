import React, { useMemo } from 'react';
import { CountryData } from '../pages/DashboardPage';

interface MapProps {
  data: CountryData[];
  selectedCountry: string;
  onCountrySelect: (country: string) => void;
}

export const Map: React.FC<MapProps> = ({ data, selectedCountry, onCountrySelect }) => {
  const countryMap = useMemo(() => {
    return data.reduce((acc, country) => {
      acc[country.iso3] = country;
      return acc;
    }, {} as Record<string, CountryData>);
  }, [data]);

  const getCountryColor = (fvi: number) => {
    if (fvi < 0.3) return '#10B981'; // green - sustainable
    if (fvi < 0.7) return '#F59E0B'; // yellow - critical transition
    return '#EF4444'; // red - decommission
  };

  const countries = [
    { id: 'USA', name: 'United States', x: 150, y: 120, width: 120, height: 80 },
    { id: 'CHN', name: 'China', x: 400, y: 140, width: 100, height: 70 },
    { id: 'IND', name: 'India', x: 380, y: 180, width: 60, height: 50 },
    { id: 'DEU', name: 'Germany', x: 290, y: 100, width: 30, height: 25 },
    { id: 'JPN', name: 'Japan', x: 480, y: 130, width: 40, height: 30 },
    { id: 'GBR', name: 'United Kingdom', x: 270, y: 90, width: 25, height: 30 },
    { id: 'FRA', name: 'France', x: 275, y: 110, width: 30, height: 35 },
    { id: 'CAN', name: 'Canada', x: 140, y: 60, width: 140, height: 50 },
    { id: 'AUS', name: 'Australia', x: 430, y: 260, width: 80, height: 60 },
    { id: 'BRA', name: 'Brazil', x: 200, y: 220, width: 70, height: 80 }
  ];

  return (
    <div className="w-full h-96 bg-slate-800/50 rounded-lg overflow-hidden relative">
      <svg viewBox="0 0 600 350" className="w-full h-full">
        {/* Ocean background */}
        <rect width="600" height="350" fill="#1e293b" />
        
        {/* Countries */}
        {countries.map(country => {
          const countryData = countryMap[country.id];
          const isSelected = selectedCountry === country.id;
          const color = countryData ? getCountryColor(countryData.fvi) : '#64748b';
          
          return (
            <g key={country.id}>
              <rect
                x={country.x}
                y={country.y}
                width={country.width}
                height={country.height}
                fill={color}
                stroke={isSelected ? '#ffffff' : '#475569'}
                strokeWidth={isSelected ? 3 : 1}
                rx={4}
                className="cursor-pointer transition-all duration-200 hover:stroke-white hover:stroke-2"
                onClick={() => onCountrySelect(country.id)}
              />
              <text
                x={country.x + country.width / 2}
                y={country.y + country.height / 2}
                textAnchor="middle"
                dominantBaseline="middle"
                fill="white"
                fontSize="10"
                fontWeight="bold"
                className="pointer-events-none"
              >
                {country.id}
              </text>
            </g>
          );
        })}
      </svg>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-black/50 rounded-lg p-3">
        <h4 className="text-white text-sm font-semibold mb-2">FVI Classification</h4>
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-500 rounded"></div>
            <span className="text-white text-xs">Sustainable (0.0-0.3)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-yellow-500 rounded"></div>
            <span className="text-white text-xs">Critical Transition (0.3-0.7)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-red-500 rounded"></div>
            <span className="text-white text-xs">Decommission (0.7-1.0)</span>
          </div>
        </div>
      </div>

      {/* Selected Country Info */}
      {selectedCountry && countryMap[selectedCountry] && (
        <div className="absolute top-4 right-4 bg-black/50 rounded-lg p-3">
          <h4 className="text-white font-semibold">{countryMap[selectedCountry].name}</h4>
          <p className="text-blue-200 text-sm">FVI: {countryMap[selectedCountry].fvi.toFixed(2)}</p>
          <p className="text-xs text-gray-300 capitalize">
            {countryMap[selectedCountry].classification.replace('_', ' ')}
          </p>
        </div>
      )}
    </div>
  );
};
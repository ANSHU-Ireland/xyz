import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, ExternalLink } from 'lucide-react';
import { LoadingSpinner } from './LoadingSpinner';
import { apiClient } from '../services/apiClient';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  citations?: string[];
  timestamp: Date;
}

export const ChatPanel: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Hello! I\'m your FVI Assistant. I can help you understand the Fossil Fuel Vulnerability Index data, explain scoring methodologies, and analyze country-specific trends. What would you like to know?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await apiClient.chat({
        message: input.trim(),
        conversation_id: 'demo-session'
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response.response,
        citations: response.citations,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Chat error:', error);
      
      // Mock response for demo
      const mockResponse = generateMockResponse(input.trim());
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: mockResponse.content,
        citations: mockResponse.citations,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateMockResponse = (query: string): { content: string; citations?: string[] } => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('fvi') || lowerQuery.includes('vulnerability')) {
      return {
        content: 'The Fossil Fuel Vulnerability Index (FVI) is a comprehensive metric that assesses countries\' exposure to fossil fuel risks across seven key themes: Artificial Support, Ecological impact, Emissions, Infrastructure dependence, Economic exposure, Energy Necessity, and Resource Scarcity. Each theme contributes to the overall FVI score, which ranges from 0 (least vulnerable) to 1 (most vulnerable). Countries are classified into three categories: Sustainable (0.0-0.3), Critical Transition (0.3-0.7), and Decommission (0.7-1.0).',
        citations: ['FVI Methodology Documentation', 'Scoring Framework Configuration']
      };
    }
    
    if (lowerQuery.includes('artificial support') || lowerQuery.includes('policy')) {
      return {
        content: 'The Artificial Support theme measures government policy strength and regulatory frameworks for coal phase-out. It includes two sub-metrics: AS1 (Policy Strength Index) based on coal exit timelines and commitments, and AS2 (Emissions-Weighted Support) which considers mining emissions normalized by policy support. Countries with stronger phase-out policies score better in this theme.',
        citations: ['Coal Phase-out Timeline Data', 'Mining Emissions Database']
      };
    }
    
    if (lowerQuery.includes('usa') || lowerQuery.includes('united states')) {
      return {
        content: 'The United States shows mixed performance across FVI themes. While it has moderate artificial support policies and relatively advanced infrastructure, it faces challenges in emissions and economic dependency on fossil fuels. The US has significant coal mining operations and high per-capita consumption, contributing to elevated vulnerability scores in certain areas.',
        citations: ['US Energy Policy Assessment', 'Coal Infrastructure Database']
      };
    }

    if (lowerQuery.includes('methodology') || lowerQuery.includes('calculate')) {
      return {
        content: 'FVI scores are calculated using a weighted aggregation of seven theme scores. Each theme contains multiple sub-metrics that are normalized using min-max scaling and then aggregated. The default weights are: Artificial Support (15%), Ecological (15%), Emissions (15%), Infrastructure (15%), Economic (15%), Necessity (15%), and Scarcity (10%). Users can adjust these weights for scenario analysis.',
        citations: ['Normalization Framework', 'Aggregation Methodology', 'Weight Configuration Guide']
      };
    }
    
    return {
      content: 'I can help you understand various aspects of the FVI data. You can ask about specific countries, scoring methodologies, theme interpretations, or data sources. Try asking about a specific country\'s performance, how scores are calculated, or what drives vulnerability in different themes.',
      citations: ['FVI User Guide', 'Data Documentation']
    };
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map(message => (
          <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex items-start space-x-2 max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse space-x-reverse' : 'flex-row'}`}>
              <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${message.type === 'user' ? 'bg-blue-600' : 'bg-gray-600'}`}>
                {message.type === 'user' ? (
                  <User className="w-4 h-4 text-white" />
                ) : (
                  <Bot className="w-4 h-4 text-white" />
                )}
              </div>
              <div className={`rounded-lg p-3 ${message.type === 'user' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-800'}`}>
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                {message.citations && message.citations.length > 0 && (
                  <div className="mt-2 pt-2 border-t border-gray-300">
                    <p className="text-xs text-gray-600 mb-1">Sources:</p>
                    <div className="space-y-1">
                      {message.citations.map((citation, index) => (
                        <div key={index} className="flex items-center space-x-1 text-xs text-gray-600">
                          <ExternalLink className="w-3 h-3" />
                          <span>{citation}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="flex items-start space-x-2">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-gray-100 rounded-lg p-3">
                <LoadingSpinner size="sm" />
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t border-gray-200 p-4">
        <div className="flex space-x-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask about FVI data, scoring, or specific countries..."
            className="flex-1 resize-none border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows={2}
            disabled={isLoading}
          />
          <button
            onClick={handleSendMessage}
            disabled={!input.trim() || isLoading}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white p-2 rounded-lg transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-xs text-gray-500 mt-1">
          Powered by Gemini Flash 2.0 • Press Enter to send
        </p>
      </div>
    </div>
  );
};
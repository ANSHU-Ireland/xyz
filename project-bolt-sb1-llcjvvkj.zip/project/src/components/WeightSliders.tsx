import React from 'react';
import { WeightConfig } from '../pages/DashboardPage';

interface WeightSlidersProps {
  weights: WeightConfig;
  onChange: (weights: WeightConfig) => void;
}

export const WeightSliders: React.FC<WeightSlidersProps> = ({ weights, onChange }) => {
  const themes = [
    { key: 'artificial_support', label: 'Artificial Support', description: 'Policy and regulatory support' },
    { key: 'ecological', label: 'Ecological', description: 'Environmental impact' },
    { key: 'emissions', label: 'Emissions', description: 'Carbon footprint' },
    { key: 'infrastructure', label: 'Infrastructure', description: 'Physical asset dependence' },
    { key: 'economic', label: 'Economic', description: 'Financial exposure' },
    { key: 'necessity', label: 'Necessity', description: 'Energy dependency' },
    { key: 'scarcity', label: 'Scarcity', description: 'Resource availability' }
  ] as const;

  const handleWeightChange = (key: keyof WeightConfig, value: number) => {
    const newWeights = { ...weights, [key]: value };
    
    // Normalize weights to sum to 1
    const total = Object.values(newWeights).reduce((sum, w) => sum + w, 0);
    if (total > 0) {
      Object.keys(newWeights).forEach(k => {
        newWeights[k as keyof WeightConfig] = newWeights[k as keyof WeightConfig] / total;
      });
    }
    
    onChange(newWeights);
  };

  const resetToDefault = () => {
    const defaultWeights: WeightConfig = {
      artificial_support: 0.15,
      ecological: 0.15,
      emissions: 0.15,
      infrastructure: 0.15,
      economic: 0.15,
      necessity: 0.15,
      scarcity: 0.10
    };
    onChange(defaultWeights);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <p className="text-blue-200 text-sm">Adjust theme weights for scenario analysis</p>
        <button
          onClick={resetToDefault}
          className="text-xs text-blue-300 hover:text-white transition-colors"
        >
          Reset to Default
        </button>
      </div>

      {themes.map(theme => (
        <div key={theme.key} className="space-y-2">
          <div className="flex justify-between items-center">
            <div>
              <label className="text-white text-sm font-medium">
                {theme.label}
              </label>
              <p className="text-blue-200 text-xs">{theme.description}</p>
            </div>
            <span className="text-white text-sm font-mono bg-white/10 px-2 py-1 rounded">
              {(weights[theme.key] * 100).toFixed(1)}%
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={weights[theme.key]}
            onChange={(e) => handleWeightChange(theme.key, parseFloat(e.target.value))}
            className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
          />
        </div>
      ))}

      <div className="mt-4 p-3 bg-blue-900/30 rounded-lg">
        <p className="text-blue-200 text-xs">
          Total weight: {(Object.values(weights).reduce((sum, w) => sum + w, 0) * 100).toFixed(1)}%
        </p>
        <p className="text-blue-300 text-xs mt-1">
          Weights are automatically normalized to sum to 100%
        </p>
      </div>
    </div>
  );
};
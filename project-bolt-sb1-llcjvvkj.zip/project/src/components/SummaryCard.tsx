import React from 'react';
import { TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { CountryData } from '../pages/DashboardPage';

interface SummaryCardProps {
  country: CountryData;
  year: number;
}

export const SummaryCard: React.FC<SummaryCardProps> = ({ country, year }) => {
  const getClassificationColor = (classification: string) => {
    switch (classification) {
      case 'sustainable': return 'text-green-400';
      case 'critical_transition': return 'text-yellow-400';
      case 'decommission': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getClassificationIcon = (classification: string) => {
    switch (classification) {
      case 'sustainable': return <TrendingDown className="w-6 h-6 text-green-400" />;
      case 'critical_transition': return <AlertTriangle className="w-6 h-6 text-yellow-400" />;
      case 'decommission': return <TrendingUp className="w-6 h-6 text-red-400" />;
      default: return null;
    }
  };

  // Find top contributing themes
  const sortedThemes = Object.entries(country.themes)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 3);

  const bottomThemes = Object.entries(country.themes)
    .sort(([,a], [,b]) => a - b)
    .slice(0, 2);

  return (
    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20 md:col-span-3">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-2xl font-bold text-white">{country.name}</h3>
          <p className="text-blue-200">FVI Analysis for {year}</p>
        </div>
        <div className="flex items-center space-x-3">
          {getClassificationIcon(country.classification)}
          <div className="text-right">
            <div className="text-3xl font-bold text-white">{country.fvi.toFixed(2)}</div>
            <p className={`text-sm capitalize ${getClassificationColor(country.classification)}`}>
              {country.classification.replace('_', ' ')}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top Risk Areas */}
        <div>
          <h4 className="text-sm font-semibold text-white mb-3">Highest Risk Areas</h4>
          <div className="space-y-2">
            {sortedThemes.map(([theme, score], index) => (
              <div key={theme} className="flex items-center justify-between">
                <span className="text-blue-200 text-sm capitalize">
                  {index + 1}. {theme.replace('_', ' ')}
                </span>
                <div className="flex items-center space-x-2">
                  <div className="w-12 h-2 bg-white/20 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-red-400 rounded-full"
                      style={{ width: `${score * 100}%` }}
                    />
                  </div>
                  <span className="text-white text-sm w-8 text-right">
                    {score.toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Best Performing Areas */}
        <div>
          <h4 className="text-sm font-semibold text-white mb-3">Best Performing Areas</h4>
          <div className="space-y-2">
            {bottomThemes.map(([theme, score], index) => (
              <div key={theme} className="flex items-center justify-between">
                <span className="text-blue-200 text-sm capitalize">
                  {index + 1}. {theme.replace('_', ' ')}
                </span>
                <div className="flex items-center space-x-2">
                  <div className="w-12 h-2 bg-white/20 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-green-400 rounded-full"
                      style={{ width: `${score * 100}%` }}
                    />
                  </div>
                  <span className="text-white text-sm w-8 text-right">
                    {score.toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
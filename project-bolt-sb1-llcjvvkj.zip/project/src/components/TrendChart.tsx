import React, { useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { CountryData } from '../pages/DashboardPage';

interface TrendChartProps {
  selectedCountry: string;
  data: CountryData[];
}

export const TrendChart: React.FC<TrendChartProps> = ({ selectedCountry, data }) => {
  const chartData = useMemo(() => {
    // Generate historical data for the selected country
    const years = [2020, 2021, 2022, 2023, 2024];
    const selectedCountryData = data.find(c => c.iso3 === selectedCountry);
    
    if (!selectedCountryData) return [];

    return years.map(year => {
      // Simulate historical trend with some variation
      const baseFvi = selectedCountryData.fvi;
      const variation = (Math.random() - 0.5) * 0.1;
      const yearOffset = (2024 - year) * 0.02; // Slight improvement over time
      
      return {
        year,
        fvi: Math.max(0, Math.min(1, baseFvi + variation - yearOffset)),
        artificial_support: Math.max(0, Math.min(1, selectedCountryData.themes.artificial_support + variation)),
        ecological: Math.max(0, Math.min(1, selectedCountryData.themes.ecological + variation)),
        emissions: Math.max(0, Math.min(1, selectedCountryData.themes.emissions + variation)),
      };
    });
  }, [selectedCountry, data]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg border">
          <p className="font-semibold">{`Year: ${label}`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {`${entry.dataKey.replace('_', ' ')}: ${entry.value.toFixed(3)}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  if (chartData.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-white/60">
        <p>No data available for selected country</p>
      </div>
    );
  }

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
          <XAxis 
            dataKey="year" 
            stroke="#e2e8f0"
            tick={{ fill: '#e2e8f0' }}
          />
          <YAxis 
            domain={[0, 1]}
            stroke="#e2e8f0"
            tick={{ fill: '#e2e8f0' }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            wrapperStyle={{ color: '#e2e8f0' }}
          />
          <Line 
            type="monotone" 
            dataKey="fvi" 
            stroke="#3b82f6" 
            strokeWidth={3}
            name="Overall FVI"
            dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
          />
          <Line 
            type="monotone" 
            dataKey="artificial_support" 
            stroke="#10b981" 
            strokeWidth={2}
            name="Artificial Support"
            dot={{ fill: '#10b981', strokeWidth: 2, r: 3 }}
          />
          <Line 
            type="monotone" 
            dataKey="ecological" 
            stroke="#f59e0b" 
            strokeWidth={2}
            name="Ecological"
            dot={{ fill: '#f59e0b', strokeWidth: 2, r: 3 }}
          />
          <Line 
            type="monotone" 
            dataKey="emissions" 
            stroke="#ef4444" 
            strokeWidth={2}
            name="Emissions"
            dot={{ fill: '#ef4444', strokeWidth: 2, r: 3 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
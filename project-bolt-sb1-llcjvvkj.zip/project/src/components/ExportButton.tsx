import React, { useState } from 'react';
import { Download, FileText, Database } from 'lucide-react';
import { apiClient } from '../services/apiClient';

export const ExportButton: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [showOptions, setShowOptions] = useState(false);

  const handleExport = async (format: 'csv' | 'json' | 'parquet') => {
    try {
      setIsExporting(true);
      const response = await apiClient.exportData({
        format,
        year_range: [2020, 2024],
        include_themes: true
      });
      
      // Create download link
      const blob = new Blob([response.data], { 
        type: format === 'csv' ? 'text/csv' : 'application/json' 
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `fvi_data_${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      setShowOptions(false);
    } catch (error) {
      console.error('Export failed:', error);
      // Mock download for demo
      const mockData = JSON.stringify({
        export_date: new Date().toISOString(),
        data_format: format,
        message: "This is a demo export. In production, this would contain the full FVI dataset."
      }, null, 2);
      
      const blob = new Blob([mockData], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `fvi_demo_export.${format}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      setShowOptions(false);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setShowOptions(!showOptions)}
        disabled={isExporting}
        className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white px-4 py-2 rounded-lg transition-colors"
      >
        <Download className="w-4 h-4" />
        <span>{isExporting ? 'Exporting...' : 'Export Data'}</span>
      </button>

      {showOptions && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
          <div className="py-1">
            <button
              onClick={() => handleExport('csv')}
              className="flex items-center space-x-2 w-full px-4 py-2 text-left text-gray-700 hover:bg-gray-50"
            >
              <FileText className="w-4 h-4" />
              <span>Export as CSV</span>
            </button>
            <button
              onClick={() => handleExport('json')}
              className="flex items-center space-x-2 w-full px-4 py-2 text-left text-gray-700 hover:bg-gray-50"
            >
              <Database className="w-4 h-4" />
              <span>Export as JSON</span>
            </button>
            <button
              onClick={() => handleExport('parquet')}
              className="flex items-center space-x-2 w-full px-4 py-2 text-left text-gray-700 hover:bg-gray-50"
            >
              <Database className="w-4 h-4" />
              <span>Export as Parquet</span>
            </button>
          </div>
        </div>
      )}

      {showOptions && (
        <div 
          className="fixed inset-0 z-0" 
          onClick={() => setShowOptions(false)}
        />
      )}
    </div>
  );
};
interface ScoreRequest {
  regions?: string[];
  year_range?: [number, number];
  weights?: Record<string, number>;
}

interface ScoreResponse {
  countries: Array<{
    iso3: string;
    name: string;
    fvi: number;
    classification: string;
    year: number;
    themes: Record<string, number>;
  }>;
  coverage: {
    total_countries: number;
    data_completeness: number;
  };
}

interface ChatRequest {
  message: string;
  conversation_id: string;
}

interface ChatResponse {
  response: string;
  citations?: string[];
  conversation_id: string;
}

interface ExportRequest {
  format: 'csv' | 'json' | 'parquet';
  year_range?: [number, number];
  include_themes?: boolean;
}

class ApiClient {
  private baseUrl = '/api';

  async getScores(params: ScoreRequest): Promise<ScoreResponse> {
    const response = await fetch(`${this.baseUrl}/scores`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch scores');
    }

    return response.json();
  }

  async chat(params: ChatRequest): Promise<ChatResponse> {
    const response = await fetch(`${this.baseUrl}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      throw new Error('Failed to send chat message');
    }

    return response.json();
  }

  async exportData(params: ExportRequest): Promise<{ data: string }> {
    const response = await fetch(`${this.baseUrl}/export`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      throw new Error('Failed to export data');
    }

    const data = await response.text();
    return { data };
  }

  async getClassification(iso3: string, year: number) {
    const response = await fetch(`${this.baseUrl}/classify?iso3=${iso3}&year=${year}`);
    
    if (!response.ok) {
      throw new Error('Failed to get classification');
    }

    return response.json();
  }

  async getGeoData() {
    const response = await fetch(`${this.baseUrl}/geo/regions`);
    
    if (!response.ok) {
      throw new Error('Failed to get geo data');
    }

    return response.json();
  }
}

export const apiClient = new ApiClient();
import React, { useState, useEffect } from 'react';
import { Map } from '../components/Map';
import { TrendChart } from '../components/TrendChart';
import { SummaryCard } from '../components/SummaryCard';
import { WeightSliders } from '../components/WeightSliders';
import { ExportButton } from '../components/ExportButton';
import { ChatPanel } from '../components/ChatPanel';
import { Settings, MessageCircle, X } from 'lucide-react';
import { apiClient } from '../services/apiClient';

export interface CountryData {
  iso3: string;
  name: string;
  fvi: number;
  classification: 'sustainable' | 'critical_transition' | 'decommission';
  year: number;
  themes: {
    artificial_support: number;
    ecological: number;
    emissions: number;
    infrastructure: number;
    economic: number;
    necessity: number;
    scarcity: number;
  };
}

export interface WeightConfig {
  artificial_support: number;
  ecological: number;
  emissions: number;
  infrastructure: number;
  economic: number;
  necessity: number;
  scarcity: number;
}

export const DashboardPage: React.FC = () => {
  const [selectedCountry, setSelectedCountry] = useState<string>('USA');
  const [selectedYear, setSelectedYear] = useState<number>(2024);
  const [countryData, setCountryData] = useState<CountryData[]>([]);
  const [weights, setWeights] = useState<WeightConfig>({
    artificial_support: 0.15,
    ecological: 0.15,
    emissions: 0.15,
    infrastructure: 0.15,
    economic: 0.15,
    necessity: 0.15,
    scarcity: 0.10
  });
  const [showSettings, setShowSettings] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, [weights, selectedYear]);

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      const data = await apiClient.getScores({
        year_range: [2020, 2024],
        weights: weights
      });
      setCountryData(data.countries || []);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      // Use mock data for demo
      setCountryData(generateMockData());
    } finally {
      setIsLoading(false);
    }
  };

  const generateMockData = (): CountryData[] => {
    const countries = [
      { iso3: 'USA', name: 'United States' },
      { iso3: 'CHN', name: 'China' },
      { iso3: 'IND', name: 'India' },
      { iso3: 'DEU', name: 'Germany' },
      { iso3: 'JPN', name: 'Japan' },
      { iso3: 'GBR', name: 'United Kingdom' },
      { iso3: 'FRA', name: 'France' },
      { iso3: 'CAN', name: 'Canada' },
      { iso3: 'AUS', name: 'Australia' },
      { iso3: 'BRA', name: 'Brazil' }
    ];

    return countries.map(country => {
      const baseScore = Math.random() * 0.8 + 0.1;
      const themes = {
        artificial_support: Math.random() * 0.9 + 0.1,
        ecological: Math.random() * 0.9 + 0.1,
        emissions: Math.random() * 0.9 + 0.1,
        infrastructure: Math.random() * 0.9 + 0.1,
        economic: Math.random() * 0.9 + 0.1,
        necessity: Math.random() * 0.9 + 0.1,
        scarcity: Math.random() * 0.9 + 0.1
      };

      const fvi = Object.entries(themes).reduce((sum, [key, value]) => {
        return sum + (value * weights[key as keyof WeightConfig]);
      }, 0);

      let classification: 'sustainable' | 'critical_transition' | 'decommission';
      if (fvi < 0.3) classification = 'sustainable';
      else if (fvi < 0.7) classification = 'critical_transition';
      else classification = 'decommission';

      return {
        ...country,
        fvi,
        classification,
        year: selectedYear,
        themes
      };
    });
  };

  const selectedCountryData = countryData.find(c => c.iso3 === selectedCountry);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-sm border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div>
              <h1 className="text-2xl font-bold text-white">FVI Dashboard</h1>
              <p className="text-blue-200">Fossil Fuel Vulnerability Index Analytics</p>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(Number(e.target.value))}
                className="bg-white/10 text-white border border-white/20 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {[2020, 2021, 2022, 2023, 2024].map(year => (
                  <option key={year} value={year} className="bg-slate-800">{year}</option>
                ))}
              </select>
              <button
                onClick={() => setShowSettings(!showSettings)}
                className="p-2 text-white hover:bg-white/10 rounded-lg transition-colors"
              >
                <Settings className="w-5 h-5" />
              </button>
              <button
                onClick={() => setShowChat(!showChat)}
                className="p-2 text-white hover:bg-white/10 rounded-lg transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
              </button>
              <ExportButton />
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {selectedCountryData && (
                <SummaryCard 
                  country={selectedCountryData} 
                  year={selectedYear}
                />
              )}
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <h3 className="text-lg font-semibold text-white mb-2">Global Average</h3>
                <div className="text-3xl font-bold text-blue-300">
                  {countryData.length > 0 ? 
                    (countryData.reduce((sum, c) => sum + c.fvi, 0) / countryData.length).toFixed(2) : 
                    '0.45'
                  }
                </div>
                <p className="text-sm text-blue-200">FVI Score</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <h3 className="text-lg font-semibold text-white mb-2">Coverage</h3>
                <div className="text-3xl font-bold text-green-300">{countryData.length}</div>
                <p className="text-sm text-blue-200">Countries Analyzed</p>
              </div>
            </div>

            {/* Map */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
              <h2 className="text-xl font-semibold text-white mb-4">Global FVI Distribution</h2>
              <Map 
                data={countryData}
                selectedCountry={selectedCountry}
                onCountrySelect={setSelectedCountry}
              />
            </div>

            {/* Trend Chart */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
              <h2 className="text-xl font-semibold text-white mb-4">FVI Trends</h2>
              <TrendChart
                selectedCountry={selectedCountry}
                data={countryData}
              />
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Weight Configuration */}
            {showSettings && (
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <h2 className="text-xl font-semibold text-white mb-4">Score Weights</h2>
                <WeightSliders
                  weights={weights}
                  onChange={setWeights}
                />
              </div>
            )}

            {/* Country Details */}
            {selectedCountryData && (
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <h2 className="text-xl font-semibold text-white mb-4">
                  {selectedCountryData.name} Details
                </h2>
                <div className="space-y-3">
                  {Object.entries(selectedCountryData.themes).map(([theme, score]) => (
                    <div key={theme} className="flex justify-between items-center">
                      <span className="text-blue-200 capitalize">
                        {theme.replace('_', ' ')}
                      </span>
                      <div className="flex items-center space-x-2">
                        <div className="w-16 h-2 bg-white/20 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-green-400 to-red-400 rounded-full"
                            style={{ width: `${score * 100}%` }}
                          />
                        </div>
                        <span className="text-white text-sm w-12 text-right">
                          {score.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Chat Panel */}
      {showChat && (
        <div className="fixed inset-y-0 right-0 w-96 bg-white/95 backdrop-blur-sm shadow-2xl border-l border-white/20 z-50">
          <div className="flex items-center justify-between p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-800">FVI Assistant</h2>
            <button
              onClick={() => setShowChat(false)}
              className="p-1 hover:bg-gray-100 rounded"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          <ChatPanel />
        </div>
      )}
    </div>
  );
};
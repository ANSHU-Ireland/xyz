import React, { useState, useEffect } from 'react';
import { DashboardPage } from './pages/DashboardPage';
import { LoadingSpinner } from './components/LoadingSpinner';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate initial data loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <LoadingSpinner size="lg" />
          <h1 className="text-3xl font-bold text-white mt-6 mb-2">FVI Dashboard</h1>
          <p className="text-blue-200">Loading comprehensive vulnerability analytics...</p>
        </div>
      </div>
    );
  }

  return <DashboardPage />;
}

export default App;